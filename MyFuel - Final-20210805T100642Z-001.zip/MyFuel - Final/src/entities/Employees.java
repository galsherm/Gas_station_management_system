package entities;

import java.io.Serializable;

/**
 * The Class Employees.
 */
public class Employees implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	private String ID;
	
	/** The first name. */
	private String firstName;
	
	/** The sur name. */
	private String surName;
	
	/** The username. */
	private String username;
	
	/** The password. */
	private String password;
    
    /** The role. */
    private String role;
    
    /** The is connected. */
    private Boolean isConnected;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The credit cardnum. */
	private String creditCardnum;
	
	/** The credit card CVV. */
	private String creditCardCVV;
	
	/** The credit cardexpire date. */
	private String creditCardexpireDate;
	
	/** The email. */
	private String email;
	
	/** The num of cars. */
	private String numOfCars;
	
	/** The purchase plan. */
	private String purchasePlan;
	
	/** The id ok. */

	public static String idOk = "NULL";
	
	/**
	 * Gets the id ok.
	 *
	 * @return the id ok
	 */
	public static String getIdOk() {
		return idOk;
	}
	
	/**
	 * Sets the id ok.
	 *
	 * @param idOk the new id ok
	 */
	public static void setIdOk(String idOk) {
		Employees.idOk = idOk;
	}
	
	/**
	 * Gets the num of cars.
	 *
	 * @return the num of cars
	 */
	public String getNumOfCars() {
		return numOfCars;
	}
	
	/**
	 * Sets the num of cars.
	 *
	 * @param numOfCars the new num of cars
	 */
	public void setNumOfCars(String numOfCars) {
		this.numOfCars = numOfCars;
	}
	
	/**
	 * Gets the purchase plan.
	 *
	 * @return the purchase plan
	 */
	public String getPurchasePlan() {
		return purchasePlan;
	}
	
	/**
	 * Sets the purchase plan.
	 *
	 * @param purchasePlan the new purchase plan
	 */
	public void setPurchasePlan(String purchasePlan) {
		this.purchasePlan = purchasePlan;
	}
	
	/**
	 * Instantiates a new employees.
	 *
	 * @param iD the i D
	 * @param firstName the first name
	 * @param surName the sur name
	 * @param username the username
	 * @param password the password
	 * @param role the role
	 * @param email the email
	 * @param isConnected the is connected
	 * @param phoneNumber the phone number
	 * @param creditCardnum the credit cardnum
	 * @param creditCardCVV the credit card CVV
	 * @param creditCardexpireDate the credit cardexpire date
	 * @param numOfCars the num of cars
	 * @param purchasePlan the purchase plan
	 */
	public Employees(String iD, String firstName, String surName, String username, String password, String role,
			String email,Boolean isConnected, String phoneNumber, String creditCardnum, String creditCardCVV,
			String creditCardexpireDate,  String numOfCars, String purchasePlan) {
		super();
		ID = iD;
		this.firstName = firstName;
		this.surName = surName;
		this.username = username;
		this.password = password;
		this.role = role;
		this.isConnected = isConnected;
		this.phoneNumber = phoneNumber;
		this.creditCardnum = creditCardnum;
		this.creditCardCVV = creditCardCVV;
		this.creditCardexpireDate = creditCardexpireDate;
		this.email = email;
		this.numOfCars = numOfCars;
		this.purchasePlan = purchasePlan;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getID() {
		return ID;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param iD the new id
	 */
	public void setID(String iD) {
		ID = iD;
	}
	
	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * Gets the sur name.
	 *
	 * @return the sur name
	 */
	public String getSurName() {
		return surName;
	}
	
	/**
	 * Sets the sur name.
	 *
	 * @param surName the new sur name
	 */
	public void setSurName(String surName) {
		this.surName = surName;
	}
	
	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	
	/**
	 * Sets the username.
	 *
	 * @param username the new username
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	
	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	
	/**
	 * Sets the role.
	 *
	 * @param role the new role
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	/**
	 * Gets the checks if is connected.
	 *
	 * @return the checks if is connected
	 */
	public Boolean getIsConnected() {
		return isConnected;
	}
	
	/**
	 * Sets the checks if is connected.
	 *
	 * @param isConnected the new checks if is connected
	 */
	public void setIsConnected(Boolean isConnected) {
		this.isConnected = isConnected;
	}
	
	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	/**
	 * Gets the credit cardnum.
	 *
	 * @return the credit cardnum
	 */
	public String getCreditCardnum() {
		return creditCardnum;
	}
	
	/**
	 * Sets the credit cardnum.
	 *
	 * @param creditCardnum the new credit cardnum
	 */
	public void setCreditCardnum(String creditCardnum) {
		this.creditCardnum = creditCardnum;
	}
	
	/**
	 * Gets the credit card CVV.
	 *
	 * @return the credit card CVV
	 */
	public String getCreditCardCVV() {
		return creditCardCVV;
	}
	
	/**
	 * Sets the credit card CVV.
	 *
	 * @param creditCardCVV the new credit card CVV
	 */
	public void setCreditCardCVV(String creditCardCVV) {
		this.creditCardCVV = creditCardCVV;
	}
	
	/**
	 * Gets the credit cardexpire date.
	 *
	 * @return the credit cardexpire date
	 */
	public String getCreditCardexpireDate() {
		return creditCardexpireDate;
	}
	
	/**
	 * Sets the credit cardexpire date.
	 *
	 * @param creditCardexpireDate the new credit cardexpire date
	 */
	public void setCreditCardexpireDate(String creditCardexpireDate) {
		this.creditCardexpireDate = creditCardexpireDate;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
 }