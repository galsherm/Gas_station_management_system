package entities;

/**
 * The Class clients.
 */
public class clients {

	/** The subscription. */
	private String ID,firstName, surname, phoneNum,subscription;
	
	/**
	 * Gets the subscription.
	 *
	 * @return the subscription
	 */
	public String getSubscription() {
		return subscription;
	}

	/**
	 * Sets the subscription.
	 *
	 * @param subscription the new subscription
	 */
	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	/**
	 * Instantiates a new clients.
	 *
	 * @param ID the id
	 * @param firstName the first name
	 * @param surname the surname
	 * @param phoneNum the phone num
	 */
	public clients(String ID, String firstName, String surname, String phoneNum)
	{
		this.ID = ID;
		this.firstName = firstName;
		this.surname = surname;
		this.phoneNum = phoneNum;

	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getID()
	{
		return ID;
	}
	
	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName()
	{
		return firstName;
	}
	
	/**
	 * Gets the surname.
	 *
	 * @return the surname
	 */
	public String getSurname()
	{
		return surname;
	}
	
	/**
	 * Gets the phone num.
	 *
	 * @return the phone num
	 */
	public String getPhoneNum()
	{
		return phoneNum;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param ID the new id
	 */
	public void setID(String ID)
	{
		this.ID = ID;
	}
	
	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	
	/**
	 * Sets the surname.
	 *
	 * @param surname the new surname
	 */
	public void setSurname(String surname)
	{
		this.surname = surname;
	}
	
	/**
	 * Sets the phone num.
	 *
	 * @param phoneNum the new phone num
	 */
	public void setPhoneNum(String phoneNum)
	{
		this.phoneNum = phoneNum;
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	public String toString(){
		return String.format("%s %s %s\n",firstName,surname,phoneNum);
	}
}
