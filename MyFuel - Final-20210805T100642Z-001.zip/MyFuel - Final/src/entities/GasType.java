package entities;
// TODO: Auto-generated Javadoc
/**
 * *.
 * This class define an entity of fuel .
 * There are 4 types of fuels and the maximum amount of fuel liters: fuel_95,soler,fuel_mini_bike,fuel_home_heating,maximum_fuel.
 * @author Noy Maman
 * 
 *
 */
public class GasType {
	/**
	 * This function is a constructor of the entities.
	 * This function gets Strings of fuel type names.
	 * @param fuel_95 Type of fuel in our station.
	 * @param soler Type of fuel in our station.
	 * @param fuel_mini_bike Type of fuel in our station.
	 * @param fuel_home_heating Type of fuel in our station.
	 */
	public GasType(String fuel_95, String soler, String fuel_mini_bike, String fuel_home_heating) {
		super();
		this.fuel_95 = fuel_95;
		this.soler = soler;
		this.fuel_mini_bike = fuel_mini_bike;
		this.fuel_home_heating = fuel_home_heating;
	}
	/**
	 * fuel variables declarations.
	 */
	public String fuel_95;
	
	/** The soler. */
	public String soler;
	
	/** The fuel mini bike. */
	public String fuel_mini_bike;
	
	/** The fuel home heating. */
	public String fuel_home_heating;
	
	/** The maximum fuel. */
	public String maximumFuel;
	
	/**
	 * This function returns fuel type.
	 * @return Fuel type fuel_95.
	 */
	public String getFuel_95() {
		return fuel_95;
	}
	/**
	 * This function gets fuel type fuel_95.
	 * This function sets the fuel type to fuel_95.
	 * @param fuel_95 Fuel type.
	 */
	public void setFuel_95(String fuel_95) {
		this.fuel_95 = fuel_95;
	}
	/**
	 * This function returns fuel type.
	 * @return Fuel type soler.
	 */
	public String getSoler() {
		return soler;
	}
	/**
	 * This function gets fuel type soler.
	 * This function sets the fuel type to soler.
	 * @param soler Fuel type.
	 */
	public void setSoler(String soler) {
		this.soler = soler;
	}
	/**
	 * This function returns fuel type.
	 * @return Fuel type fuel_mini_bike.
	 */
	public String getFuel_mini_bike() {
		return fuel_mini_bike;
	}
	/**
	 * This function gets fuel type fuel_mini_bike.
	 * This function sets the fuel type to fuel_mini_bike.
	 * @param fuel_mini_bike Fuel type.
	 */
	public void setFuel_mini_bike(String fuel_mini_bike) {
		this.fuel_mini_bike = fuel_mini_bike;
	}
	/**
	 * This function returns fuel type.
	 * @return Fuel type fuel_home_heating.
	 */
	public String getFuel_homeheating() {
		return fuel_home_heating;
	}
	/**
	 * This function gets fuel type fuel_homeheating.
	 * This function sets the fuel type to fuel_homeheating.
	 * @param fuel_homeheating Fuel type.
	 */
	public void setFuel_homeheating(String fuel_homeheating) {
		this.fuel_home_heating = fuel_homeheating;
	}
	/**
	 * This function returns the maximum amount of fuel liters..
	 * @return maximum amount of fuel liters.
	 */
	public String getMaximumFuel() {
		return maximumFuel;
	}
	/**
	 * This function gets Amount of Fuel liters.
	 * This function sets maximumFuel type to maximumFuel.
	 * @param maximumFuel Amount of Fuel liters.
	 */
	public void setMaximumFuel(String maximumFuel) {
		this.maximumFuel = maximumFuel;
	}


	
	
	
	

}
