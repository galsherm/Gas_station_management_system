package client;
import javafx.application.Application;
import javafx.stage.Stage;
import logic.NFC;
import gui.Login_Page_Boundary;

/**
	 * The Class ClientUI.
	 */
	public class ClientUI extends Application {
		
		/** The chat. */
		public static ClientController chat;

		/**
		 * The main method.
		 *
		 * @param args the arguments
		 * @throws Exception the exception
		 */
		public static void main( String args[] ) throws Exception
		   { 
			    launch(args);  

		   } // end main
		 
		/**
		 * Start.
		 *
		 * @param primaryStage the primary stage
		 * @throws Exception the exception
		 */
		@Override
		public void start(Stage primaryStage) throws Exception {
			 chat = ClientController.createClientIfNotExist("localhost", 5555);
			initNFC();
							  		
			Login_Page_Boundary login = new Login_Page_Boundary(); // create StudentFrame
			 
			login.start(primaryStage);
		}
		
		/**
		 * Inits the NFC.
		 */
		private static void initNFC() {
			Thread t1 = new Thread(new NFC());
			t1.start();
		}
	}
