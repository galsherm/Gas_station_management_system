// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;
/**
 * Import libraries.
 */
import ocsf.client.*;
import entities.Employees;
import entities.clients;
import gui.Login_Page_Boundary;
import gui.MyFile;
import gui.Network_Manager_Boundary;
import logic.NFC;
import logic.SqlAction;
import logic.alertClass;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class overrides some of the methods defined in the abstract superclass
 * in order to give more functionality to the client.
 *This class responsible for communication between the server and the client/handling instant message.
 * @author Noy Maman.
 * @author Liran Hersh.
 * @author Asaf Darmon.
 * @author Gal Sherman.
 * @author Karin Azulay.
 * @version 11.01
 */
public class ChatClient extends AbstractClient {

/**
 * The msgg.
 *
 */
	
	
	public static ArrayList<String> msgg = new ArrayList<String>();
	
	/** The renwall. */
	public static ArrayList<String> renwall = new ArrayList<String>();
	
	/** The supllier renwall. */
	public static ArrayList<String> supllierRenwall = new ArrayList<String>();
	
	/** The ret. */
	public static ArrayList<String> ret = new ArrayList<String>();
	
	/** The full mon sub price. */
	public static double fullMonSubPrice = 0;
	
	/** The supplied. */
	public static boolean supplied;
	
	/** The check. */
	public static boolean check = false;
	
	/** The c 1. */
	public static clients c1 = new clients(null, null, null, null);
	
	/** The emp. */
	Employees emp = new Employees(null, null, null, null, null, null, null, null, null, null, null, null, null, null);
	
	/** The await response. */
	public static boolean awaitResponse = false;
	
	/** The check is connected. */
	SqlAction checkIsConnected = new SqlAction();
	// Connection con = checkIsConnected.conn;

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the chat client.
	 *
	 * @param host     The server to connect to.
	 * @param port     The port number to connect on.
	 * @throws IOException Signals that an I/O exception has occurred.
	 * 
	 */
	public ChatClient(String host, int port) throws IOException {
		super(host, port); // Call the superclass constructor
	}
	
	/**
   * This method handles all data that comes in from the server.
   * This function is divided to cases that take care of various cases.
   * @param msg The message from the server.
   */
  @SuppressWarnings("unchecked")
public void handleMessageFromServer(Object msg) 
  {
	  awaitResponse = false;
	  try {
			closeConnection();
		} catch (IOException e) {
			e.printStackTrace();
		}
	  ArrayList<String> al = new ArrayList<String>(); //string to send to client
	  if(msg instanceof String) {
		 switch(msg.toString()) {
		 	 
		 case "Password Not Correct":
			 alertClass.alertMessage("Password Not Correct");
			 break;
		 case "UserName Not Correct":
			 alertClass.alertMessage("UserName Not Correct");
			 break;
		 case "Already Connected":
			 alertClass.alertMessage("Already Connected");
			 break;
		 case "Id Ok":
			 Employees.setIdOk("OK");
			 break;
		 case "Id Wrong":
			 Employees.setIdOk("Wrong");
			 break;
		 case "Id Good":
			 NFC.NFCID = "Good";
			 break;
		 case "Id Not Good":
			 NFC.NFCID = "Id Not Good";
			 break;	
		 case "File Not Succeeded":
			alertClass.alertMessage("File Not Succeeded");
			break;
		 }
	  }
	  else
		  if(msg instanceof Employees) {
			 emp = (Employees)msg;
			 System.out.println(emp.getRole());
				 if(emp.getIsConnected().equals(false)) {
					 switch(emp.getRole()) {
		    			case "Marketing Representative": //open marketing representative main page!
		    				Login_Page_Boundary.loginUser = emp.getRole();
		    				break;
		    			case "Station Manager":
		    				Login_Page_Boundary.loginUser = emp.getRole();
		    				break;
		    			case "Network Manager":
		    				Login_Page_Boundary.loginUser = emp.getRole();
		    				break;
		    			case "Client":
		    				Login_Page_Boundary.loginUser = emp.getRole();
		    				break;
		    			case "Supplier":
		    				Login_Page_Boundary.loginUser = emp.getRole();
		    				break;
		    			case "Marketing Manager":
		    				Login_Page_Boundary.loginUser = emp.getRole();
		    				break;		    				
		    			default:
		    				System.out.println("Error");
		    				break;
				 	}
				 } //closing isConnected if
		  }else if (msg instanceof List) { // for the first time, msg contains the list
			  al = (ArrayList<String>)msg;
				if(!(al.get(0) instanceof String)){		//if msg is instance of MyFile!			
					Network_Manager_Boundary.funcFiles((ArrayList<MyFile>)msg);
						alertClass.alertMessage("Files Succeeded");
				}else { //if msg instance of list!						
				switch (al.get(0)) {
				case "Need":
					al.remove(0);
					renwall = al;
				break;
				
				case "Approve":
					al.remove(0);
					supllierRenwall = al;
					break;
				case "Not Approve":
					al.remove(0);
					supllierRenwall = al;
					break;
					
				case "Supplied":
					supplied = true;				
					break;
					
				case "Correct":
					ret = al;
					break;
				case "Error":
					ret = al;
					break;
					
				case "Check New Price":
					al.remove(0);
					msgg = al;
					break;
				case "Marketing_Manager_Page_ReportCampain":
					ret = al;
					break;
				case "StationManager_InventoryThreshold":
					al.clear();
					al.add("success update!!");
					msgg.clear();
					msgg = al;
					break;
				case "StationManager_ShowData_CheckInventory":
					al.remove(0);
					msgg = al;
					break;
				case "StationManager_ShowData_CheckPurchases":
					msgg = al;
					break;

				case "StationManager_ShowData_checkIncoming":
					msgg = al;
					break;
				case "Server_sendrenwelInventoryMessage":
						msgg = al;
					break;		
				case "Marketing_Manager_Page_ReportChar":
					al.remove(0);//"Marketing_Manager_Page_ReportChar"
					ret = al;
				case "0": 
					c1.setFirstName(al.get(1));
					c1.setSurname(al.get(2));
					c1.setPhoneNum(al.get(3));
					break;
					
				case "1":
					c1.setFirstName(al.get(1));
					break;					
				case "2":
					c1.setFirstName(al.get(1));
					break;
				case "3":
					check = Boolean.parseBoolean(al.get(3));
					break;
					
				case "4":
					ret = (ArrayList<String>)msg;
					break;
				case "5":
					ret = (ArrayList<String>)msg;
					break;
				case "6":
					ret = (ArrayList<String>)msg;
					break;
				case "7":
					ret = (ArrayList<String>)msg;
					break;
				case "8":						
					c1.setSubscription(al.get(1));//change
					break;
				case "9":
					ret = (ArrayList<String>)msg;
					ret.remove(0);
					break;
				case "Analitical_System_Msg":
					ret = (ArrayList<String>)msg;
					ret.remove(0);
					break;
				case "fuelingCalculate":
					al.remove(0);
					fullMonSubPrice = Double.parseDouble(al.get(0));
					break;
				default:
				break;
				}
				}
				}
	  awaitResponse = false;
		
  }

	/**
	 * This method handles all data coming from the client UI.
	 *
	 * @param message The message from the UI.
	 */

	public void handleMessageFromClientUI(Object message) {
		try {
			openConnection();
			awaitResponse = true;
			sendToServer(message);
			// wait for response
			while (awaitResponse) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Could not send message to server: Terminating client." + e);
			quit();
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}

