package client;
// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 
/**
 * Import libraries.
 */
import java.io.*;



/**
 * This class constructs the UI for a chat client.  It implements the
 * chat interface in order to activate the display() method.
 * Warning: Some of the code here is cloned in ServerConsole 
 *
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Dr Timothy C. Lethbridge  
 * @author Dr Robert Lagani&egrave;re
 * @version July 2000
 */
public class ClientController
{
	
	/** The singletone instance. */
	private static ClientController singletoneInstance = null;
  
  /**
   * The default port to connect on.
   */
  final public static int DEFAULT_PORT = 5555;
  
  //Instance variables **********************************************
  
  /**
   * The instance of the client that created this ConsoleChat.
   */
  public ChatClient client;
  
  //Constructors ****************************************************
  
  /**
   * Instantiates a new client controller.
   *
   * @param host the host
   * @param port the port
   */
  private ClientController(String host, int port)  
  {		    

	  try {
		  client= new ChatClient(host, port);
	} catch (IOException e) {
		System.out.println("Connection refused: connect");
	}
  }
  
  /**
   * Creates the client if not exist.
   *
   * @param host the host
   * @param port the port
   * @return the client controller
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static ClientController createClientIfNotExist(String host, int port) throws IOException
	{
		if (singletoneInstance == null)
			singletoneInstance = new ClientController(host, port);
		return singletoneInstance;
	}

  /**
   * Constructs an instance of the ClientConsole UI.
   *
   * @param message the message
   */


  
  //Instance methods ************************************************
  
  /**
   * This method waits for input from the console.  Once it is 
   * received, it sends it to the client's message handler.
   * @param message the message
   */
  
  public void accept(Object message) 
  {
    try
    {
        client.handleMessageFromClientUI(message);
    } 
    catch (Exception ex) 
    {
      System.out.println
        ("Unexpected error while reading from console!");
    }
  }
  
  //Class methods ***************************************************
  
  /**
   * This method is responsible for the creation of the Client UI.
   *
   * @param args[0] The host to connect to.
   */
}
