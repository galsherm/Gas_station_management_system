package gui;

import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.text.Text;

/**
 * The Class Supplier_Page_Boundary.
 */
public class Supplier_Page_Boundary implements Initializable{
	
	/** The supplier user name. */
	public static String supplierUserName;
	
	/** The Station managerapproval. */
	public static String StationManagerapproval = "";
	
	/** The exit. */
	boolean exit = false;

    /** The Report title. */
    @FXML
    private Text ReportTitle;

    /** The Order details. */
    @FXML
    private Text OrderDetails;

    /** The Order details area. */
    @FXML
    private TextArea OrderDetailsArea;

    /** The Order status. */
    @FXML
    private Text OrderStatus;

    /** The Order status area. */
    @FXML
    private TextArea OrderStatusArea;

    /** The Updateinventory. */
    @FXML
    private Button Updateinventory;

    /** The Supply page 1. */
    @FXML
    private Button SupplyPage1;
    

    /** The Disconnect button. */
    @FXML
    private Button Disconnect1;


    /**
     * Updateinventory function.
     *
     * @param event the event
     */
    @FXML
    void UpdateinventoryFunction(ActionEvent event) {
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("SupplyPage_Updating_Inventory");
    	Login_Page_Boundary.clientController.client.handleMessageFromClientUI(al);
    }
    
    /**
     * Handle disconnect button.
     *
     * @param event the event
     */
    @FXML
    void handleDisconnectButton(ActionEvent event) {
		Platform.runLater(() -> {
        	Alert alert = new Alert(AlertType.CONFIRMATION);
        	alert.setTitle("Before You GO");
        	alert.setContentText("Are You Sure?");

        	Optional<ButtonType> result = alert.showAndWait();
        	if (result.get() == ButtonType.CANCEL){
        	    alert.close();  
        	}
        	else {
        		Login_Page_Boundary.handleSignOut("Supplier");	
        		((Node) (event.getSource())).getScene().getWindow().hide();  
        	}
        });	
    }

    
	/**
	 * Initialize.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Thread t1 = new Thread(new Runnable() {
			ArrayList<String> renewal = new ArrayList<String>();
				@Override
				public void run() {
					
					while(!exit) {
						
						try {
							Thread.sleep(10000);
							checkRenewal();	
							exit = true;
						} catch (InterruptedException e) {
							e.printStackTrace();
						}										
					}
				}

				private void checkRenewal() {
					renewal.clear();
					renewal.add("Check Approval");
					ClientUI.chat.client.handleMessageFromClientUI(renewal);
					if(!ChatClient.supllierRenwall.toString().equals("Not Approve")) {
						ArrayList<String> al = new ArrayList<String>();
						Platform.runLater(()->{	
							
							Alert alert = new Alert(AlertType.WARNING, ChatClient.supllierRenwall.toString() + "\n", ButtonType.OK, ButtonType.NO,

									ButtonType.CANCEL);
							alert.setTitle("Approval");
							alert.setHeaderText("Station manager accept\nPlease supply the following:");
							Optional<ButtonType> result = alert.showAndWait();

							if (result.get() == ButtonType.OK) {
								al.clear();
								al.add("Update Renewal");
								al.addAll(ChatClient.supllierRenwall);			
								ClientUI.chat.client.handleMessageFromClientUI(al);	
								al.clear();
							}

						});
					}
				}
		});
		if(!exit)
			t1.start();
	}
}

