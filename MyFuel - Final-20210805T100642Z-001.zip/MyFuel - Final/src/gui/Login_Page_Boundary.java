package gui;
	
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import org.controlsfx.control.Notifications;

import client.ClientController;
import client.ClientUI;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * The Class Login_Page_Boundary.
 */
public class Login_Page_Boundary extends Application implements Initializable{	
	
	/** The var array. */
	private static ArrayList<String> varArray;
	
	/** The user name. */
	@FXML private TextField userName;
	
	/** The user password. */
	@FXML private PasswordField userPassword;  
    
    /** The client controller. */
    public static ClientController clientController;
    
    /** The login user. */
    public static String loginUser = "";
    
    /** The root. */
    Parent root;
    
    /**
     * Check if the client exist.
     */
    @FXML
    public void checkClient() {
    	
		varArray = new ArrayList<>();
		varArray.add("Verify");
		varArray.add(userName.getText());
		varArray.add(userPassword.getText());
		ClientUI.chat.client.handleMessageFromClientUI(varArray);  
		
		switch(loginUser) {
		case "Marketing Representative": //open marketing representative main page!					
				try {
					System.out.println("Marketing");
					root = FXMLLoader.load(Marketing_Representative_Page.class.getResource("Marketing_Representative_Page.fxml"));
					Scene Scene = new Scene(root);
					Stage marketingStage = new Stage();
					Scene.getStylesheets().add("MarketingRepresentative.css");
					marketingStage.setScene(Scene);
					marketingStage.setTitle("Marketing Representative Main Page");
					marketingStage.show();
		        	Notifications approval = Notifications.create().title("Welcome")
					.text("Logged as Marketing Representative").hideAfter(Duration.seconds(5))
					.position(Pos.BOTTOM_RIGHT);
				approval.darkStyle();
				approval.showInformation();
						marketingStage.setOnCloseRequest(evt->{
				        	
				        	evt.consume();
				        	Alert alert = new Alert(AlertType.CONFIRMATION);
				        	alert.setTitle("Before You GO");
				        	alert.setContentText("Are You Sure?");

				        	Optional<ButtonType> result = alert.showAndWait();
				        	if (result.get() == ButtonType.CANCEL){
				        	    alert.close();  
				        	}
				        	else {
				        		handleSignOut("Marketing Representative");		        	
				        		marketingStage.close();	 
				        	}  
				        });	
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				Marketing_Representative_Page.marketingUserName = userName.getText();
				break;
				
		case "Station Manager":
				try {
					root = FXMLLoader.load(StationManagerBoundry.class.getResource("StationManagerPage.fxml"));
					Scene Scene = new Scene(root);
					Stage stationManager = new Stage();
					Scene.getStylesheets().add("MarketingRepresentative.css");
					stationManager.setScene(Scene);
					stationManager.setTitle("Station Manager Main Page");					
					stationManager.show();
					Notifications approval = Notifications.create().title("Welcome")
							.text("Logged as Station Manager").hideAfter(Duration.seconds(5))
							.position(Pos.BOTTOM_RIGHT);
					approval.darkStyle();
					approval.showInformation();
					stationManager.setOnCloseRequest(evt->{  			        	
			        	evt.consume();
			        	Alert alert = new Alert(AlertType.CONFIRMATION);
			        	alert.setTitle("Before You GO");
			        	alert.setContentText("Are You Sure?");

			        	Optional<ButtonType> result = alert.showAndWait();
			        	if (result.get() == ButtonType.CANCEL){
			        	    alert.close();  
			        	}
			        	else {
			        		handleSignOut("Station Manager");		        	
			        		stationManager.close();	
			        	}
			        });			
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				StationManagerBoundry.stationManagerUserName = userName.getText();
			break;
		case "Network Manager":			
			try {
				root = FXMLLoader.load(getClass().getResource("Network_Manager_Boundary.fxml"));
				Stage networkManager = new Stage();
				Scene Scene = new Scene(root);
				Scene.getStylesheets().add("MarketingRepresentative.css");
				networkManager.setScene(Scene);				
				networkManager.show();
				Notifications approval = Notifications.create().title("Welcome")
						.text("Logged as Network Manager").hideAfter(Duration.seconds(5))
						.position(Pos.BOTTOM_RIGHT);
				approval.darkStyle();
				approval.showInformation();
				networkManager.setOnCloseRequest(evt->{  			        	
		        	evt.consume();
		        	Alert alert = new Alert(AlertType.CONFIRMATION);
		        	alert.setTitle("Before You GO");
		        	alert.setContentText("Are You Sure?");

		        	Optional<ButtonType> result = alert.showAndWait();
		        	if (result.get() == ButtonType.CANCEL){
		        	    alert.close();  
		        	}
		        	else {
		        		handleSignOut("Network Manager");		        	
		        		networkManager.close();	
		        	}
		        });			
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			Network_Manager_Boundary.networkManagerUserName = userName.getText();
			break;
		case "Client":
			try {
				root = FXMLLoader.load(HomeFuelingController.class.getResource("HomeFueilng.fxml"));				
				Scene Scene = new Scene(root);
				Scene.getStylesheets().add("MarketingRepresentative.css");
				Stage homeFueling = new Stage();
				homeFueling.setScene(Scene);
				homeFueling.setTitle("Main Order Page");
				homeFueling.show();
				Notifications approval = Notifications.create().title("Welcome").text("Logged as Client")
						.hideAfter(Duration.seconds(5)).position(Pos.BOTTOM_RIGHT);
				approval.darkStyle();
				approval.showInformation();
				homeFueling.setOnCloseRequest(evt->{
			        	
			        	evt.consume();
			        	Alert alert = new Alert(AlertType.CONFIRMATION);
			        	alert.setTitle("Before You GO");
			        	alert.setContentText("Are You Sure?");

			        	Optional<ButtonType> result = alert.showAndWait();
			        	if (result.get() == ButtonType.CANCEL){
			        	    alert.close();  
			        	}
			        	else {
			        		handleSignOut("Client");		        	
			        		homeFueling.close();
			        	}	
				});
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			HomeFuelingController.clientUserName = userName.getText();
			break;
		case "Supplier":
			try {
				root = FXMLLoader.load(Supplier_Page_Boundary.class.getResource("Supplier_Page_Boundary.fxml"));
				Stage supplier = new Stage();
				Scene Scene = new Scene(root);
				Scene.getStylesheets().add("MarketingRepresentative.css");
				supplier.setScene(Scene);				
				supplier.show();
				Notifications approval = Notifications.create().title("Welcome").text("Logged as Supplier")
						.hideAfter(Duration.seconds(5)).position(Pos.BOTTOM_RIGHT);
				approval.darkStyle();
				approval.showInformation();
				supplier.setOnCloseRequest(evt->{
			        	
			        	evt.consume();
			        	Alert alert = new Alert(AlertType.CONFIRMATION);
			        	alert.setTitle("Before You GO");
			        	alert.setContentText("Are You Sure?");

			        	Optional<ButtonType> result = alert.showAndWait();
			        	if (result.get() == ButtonType.CANCEL){
			        	    alert.close();  
			        	}
			        	else {
			        		handleSignOut("Supplier");		        	
			        		supplier.close();
			        	}	
				});
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			Supplier_Page_Boundary.supplierUserName = userName.getText();
			break;
		case "Marketing Manager":
			try {
				root = FXMLLoader.load(getClass().getResource("Marketing_Manager_Boundary.fxml"));
				Scene Scene = new Scene(root);
				Scene.getStylesheets().add("MarketingRepresentative.css");
				Stage marketingManager = new Stage();
				marketingManager.setScene(Scene);
				marketingManager.setTitle("Marketing Manager Page");
				marketingManager.show();
				Notifications approval = Notifications.create().title("Welcome").text("Logged as Marketing Manager")
						.hideAfter(Duration.seconds(5)).position(Pos.BOTTOM_RIGHT);
				approval.darkStyle();
				approval.showInformation();
				marketingManager.setOnCloseRequest(evt->{
			        	
			        	evt.consume();
			        	Alert alert = new Alert(AlertType.CONFIRMATION);
			        	alert.setTitle("Before You GO");
			        	alert.setContentText("Are You Sure?");

			        	Optional<ButtonType> result = alert.showAndWait();
			        	if (result.get() == ButtonType.CANCEL){
			        	    alert.close();  
			        	}
			        	else {
			        		handleSignOut("Marketing Manager");		        	
			        		marketingManager.close();
			        	}	
				});
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
			Marketing_Manager_Boundary.marketingManagerUserName = userName.getText();
			break;
			
		default:
			System.out.println("Error");
			break;
	}		
    }

    
    /**
     * Handle sign out' closes the screens.
     *
     * @param role the role
     */
    public static void handleSignOut(String role) {
    			switch(role) {
    			case "Marketing Representative": //open marketing representative main page!
    		   		varArray = new ArrayList<>();
    		   		varArray.add("disconnect");
    		   		varArray.add(Marketing_Representative_Page.marketingUserName);   		   		
    		   		ClientUI.chat.client.handleMessageFromClientUI(varArray);   	    		
    	    		break;

    			case "Station Manager":
    		   		varArray = new ArrayList<>();
    		   		varArray.add("disconnect");
    		   		varArray.add(StationManagerBoundry.stationManagerUserName);   		   		
    		   		ClientUI.chat.client.handleMessageFromClientUI(varArray); 
    				break;
    			case "Network Manager":
    		   		varArray = new ArrayList<>();
    		   		varArray.add("disconnect");
    		   		varArray.add(Network_Manager_Boundary.networkManagerUserName);   		   		
    		   		ClientUI.chat.client.handleMessageFromClientUI(varArray); 
    				break;
    			case "Client":
    		   		varArray = new ArrayList<>();
    		   		varArray.add("disconnect");
    		   		varArray.add(HomeFuelingController.clientUserName);   		   		
    		   		ClientUI.chat.client.handleMessageFromClientUI(varArray);
    				break;
    			case "Supplier":
    		   		varArray = new ArrayList<>();
    		   		varArray.add("disconnect");
    		   		varArray.add(Supplier_Page_Boundary.supplierUserName);   		   		
    		   		ClientUI.chat.client.handleMessageFromClientUI(varArray);
    				break;
    			case "Marketing Manager":
    		   		varArray = new ArrayList<>();
    		   		varArray.add("disconnect");
    		   		varArray.add(Marketing_Manager_Boundary.marketingManagerUserName);   		   		
    		   		ClientUI.chat.client.handleMessageFromClientUI(varArray);
    		   		break;
    				
    			default:
    				System.out.println("Error");
    				break;
    		}
    		}
    	
	    /**
	     * Ask help pressed.
	     */
	    public void askHelpPressed() {
    			
    			Alert alert = new Alert(AlertType.INFORMATION);
    			alert.setTitle("Information Dialog");
    			alert.setHeaderText("Attention!");
    			alert.setContentText("Please sign in as marketing representative.");

    			alert.showAndWait();		
    		}

    
	/**
	 * Initialize.
	 *
	 * @param location the location
	 * @param resources the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		final Tooltip userNameTooltip = new Tooltip();
		final Tooltip userPasswordTooltip = new Tooltip();
		userNameTooltip.setText("Please enter user name");
		userPasswordTooltip.setText("Please enter password");	
		userName.setTooltip(userNameTooltip);
		userPassword.setTooltip(userPasswordTooltip);
	}
	
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		launch(args);
	}
	
	/**
	 * Start.
	 *
	 * @param stage the stage
	 * @throws Exception the exception
	 */
	@Override
	public void start(Stage stage) throws Exception {
	
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("Login_Page_Boundary.fxml"));
			Scene Scene = new Scene(root);
			Stage loginPage = new Stage();
	        loginPage.setScene(Scene);
	        loginPage.show();
	        loginPage.setOnCloseRequest(evt->{
	        	
	        	evt.consume();
	        	Alert alert = new Alert(AlertType.CONFIRMATION);
	        	alert.setTitle("Before You GO");
	        	alert.setContentText("Are You Sure?");

	        	Optional<ButtonType> result = alert.showAndWait();
	        	if (result.get() == ButtonType.CANCEL){
	        	    alert.close();  
	        	}
	        	else {
	        		loginPage.close();	        	
	        }
	        });
		} catch (IOException e) {
			e.printStackTrace();
		}
}
}
