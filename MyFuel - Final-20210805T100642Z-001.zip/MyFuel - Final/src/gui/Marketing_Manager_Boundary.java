package gui;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import client.ChatClient;
import client.ClientUI;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.util.Callback;

/**
 * The Class Marketing_Manager_Boundary that can do 3 action in his part.
 */
public class Marketing_Manager_Boundary implements Initializable {
	
	/** The marketing manager user name. */
	public static String marketingManagerUserName;
	//public static String StationManagerapproval = "";
	

    /** The Back to update rate. */
	@FXML
    private Text BackToUpdateRate;

	/** The marketing manager page. */
	@FXML
	private AnchorPane marketingmanagerpage;

	/** The setting rate btn. */
	@FXML
	private Button settingRateBtn;

	/**
	 * Per choose.
	 *
	 * @param event the event
	 */
	@FXML
	void perChoose(ActionEvent event) {
		startDate.setVisible(true);
		SDateTxt.setVisible(true);
	}

	/**
	 * S time choose.
	 *
	 * @param event the event
	 */
	@FXML
	void STimeChoose(ActionEvent event) {
		endTime.setVisible(true);
		EtimeTxt.setVisible(true);
	}

	/**
	 * E time choose.
	 *
	 * @param event the event
	 */
	@FXML
	void ETimeChoose(ActionEvent event) {
		purpose.setVisible(true);
		putposeTxt.setVisible(true);
		updatebtn.setVisible(true);
	}

	/** The discount txt. */
	@FXML
	private Text discountTxt;

	/** The putpose txt. */
	@FXML
	private Text putposeTxt;

	/** The Start date txt. */
	@FXML
	private Text SDateTxt;

	/** The End date txt. */
	@FXML
	private Text EDateTxt;

	/** The End time txt. */
	@FXML
	private Text EtimeTxt;

	/** The Start time txt. */
	@FXML
	private Text StimeTxt;

	/** The comments. */
	@FXML
	private TextArea comments;

	/** The start date. */
	@FXML
	private DatePicker startDate;

	/**
	 * End date func.
	 *
	 * @param event the event
	 */
	@FXML
	void endDateFunc(ActionEvent event) {
		startTime.setVisible(true);
		StimeTxt.setVisible(true);
	}

	/**
	 * Start date func.
	 *
	 * @param event the event
	 */
	@FXML
	void startDateFunc(ActionEvent event) {
		endDate.setVisible(true);
		EDateTxt.setVisible(true);
	}

	/**
	 * Fuel type choose.
	 *
	 * @param event the event
	 */
	@FXML
	void fuelTypeChoose(ActionEvent event) {
		discount.setVisible(true);
		discountTxt.setVisible(true);
	}

	/**
	 * Gets the day cell factory.
	 *
	 * @return the day cell factory
	 */
	private Callback<DatePicker, DateCell> getDayCellFactory() {

		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {

			@Override
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						// Disable Monday, Tueday, Wednesday.
						if (item.isBefore(LocalDate.now())) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}
					}
				};

			}

		};
		return dayCellFactory;
	}

	/** The end date. */
	@FXML
	private DatePicker endDate;

	/** The successfuly window. */
	@FXML
	private ToolBar successfulyWindow;

	/** The end btn. */
	@FXML
	private Button endBtn;
	
	/** The start time. */
	@FXML
	private ComboBox<String> startTime;

	/** The end time. */
	@FXML
	private ComboBox<String> endTime;

	/** The character report field. */
	@FXML
	private TextArea character;
	
	/** The sales btn. */
	@FXML
	private Button salesbtn;

	/** The report btn. */
	@FXML
	private Button reportbtn;

	/** The setting rate page. */
	@FXML
	private AnchorPane settingratepage;

	/** The sending rate window. */
	@FXML
	private AnchorPane sendingRateWindow;

	/** The back. */
	@FXML
	private Button back;

	/** The send rate btn. */
	@FXML
	private Button sendRateBtn;

	/** The back btn cng prc. */
	@FXML
	private Button backBtnCngPrc;

	/** The back btn cng prc 1. */
	@FXML
	private Button backBtnCngPrc1;
	  
  	/** The disconnect btn. */
  	@FXML
	    private Button disconnectbtn;

	/** The sendbtn. */
	@FXML
	private Button sendbtn;
    
    /** The backarrow. */
    @FXML
    private Button backarrow;
  

    /** The back navigationreport. */
    @FXML
    private Button backNavigationreport;
	
	/** The updatebtn. */
	@FXML
	private Button updatebtn;

	/** The typeoffuel. */
	@FXML
	private ComboBox<String> typeoffuel;

	/** The salespage. */
	@FXML
	private AnchorPane salespage;
	 
 	/** The back navigationsale. */
 	@FXML
	    private Button backNavigationsale;
	
	/** The typeoffuel 1. */
	@FXML
	private ComboBox<String> typeoffuel1;

	/** The reportpage. */
	@FXML
	private AnchorPane reportpage;

	/** The commentbtn. */
	@FXML
	private Button commentbtn;

	/** The update window. */
	@FXML
	private AnchorPane updateWindow;

	/**
	 * Send rate func.
	 *
	 * @param event the event
	 */
	@FXML
	void sendRateFunc(ActionEvent event) {
		sendingRateWindow.setVisible(true);
		settingratepage.setVisible(false);

		typeoffuel.setValue("Choose gas type");
		newPrice.clear();
	}

	/** The gas type choose. */
	@FXML
	private ComboBox<String> gasTypeChoose;

	/**
	 * Back btn cngfunc.
	 *
	 * @param event the event
	 */
	@FXML
	void backBtnCngfunc(ActionEvent event) {
		updateWindow.setVisible(false);
		settingratepage.setVisible(true);
	}

	/**
	 * Back btn cngfunc 1.
	 *
	 * @param event the event
	 */
	@FXML
	void backBtnCngfunc1(ActionEvent event) {
		sendingRateWindow.setVisible(false);
		settingratepage.setVisible(true);
	}

	/**
	 * Updatebtnsql.
	 *
	 * @param event the event
	 */
	@FXML
	void updatebtnsql(ActionEvent event) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("Marketing_Manager_Page_updateprice");
		list.add(gasTypeChoose.getValue());


		ClientUI.chat.client.handleMessageFromClientUI(list);
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("confirmation window");
		alert.setHeaderText("update price");
		alert.setContentText("after press this button and confirmation of the network manager the price will be update");
		alert.showAndWait();
		return;

	}

	/** The upbtn. */
	@FXML
	private Button upbtn;

	/** The new price. */
	@FXML
	private TextField newPrice;

	/** The discount. */
	@FXML
	private ComboBox<String> discount;
	
	/** The purpose. */
	@FXML
	private TextArea purpose;
	
	/** The characterbtn. */
	@FXML
	private Button characterbtn;
	
	/** The al. */
	public ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object

	/** The gas type. */
	ObservableList<String> gasType = FXCollections.observableArrayList("Fuel_95", "Soler", "Fuel_mini_bike",
			"Fuel_Home_Heating");

	/**
	 * Choose com.
	 *
	 * @param event the event
	 */
	@FXML
	void chooseCom(ActionEvent event) {

		upbtn.setVisible(true);

	}

	/**
	 * Backbtn.
	 *
	 * @param event the event
	 */
	@FXML
	void backbtn(ActionEvent event) {
		settingratepage.setVisible(false);
		reportpage.setVisible(false);
		salespage.setVisible(false);
		marketingmanagerpage.setVisible(true);


		newPrice.clear();
		typeoffuel.setValue(null);
		typeoffuel1.setValue(null);
		comments.clear();
		character.clear();
		purpose.clear();
	}

	/**
	 * Btn setting rate.
	 *
	 * @param event the event
	 */
	@FXML
	void btnSettingRate(ActionEvent event) {
		settingratepage.setVisible(true);
		reportpage.setVisible(false);
		salespage.setVisible(false);
	}

	/**
	 * Btncharacter.
	 *
	 * @param event the event
	 */
	@FXML
	void btncharacter(ActionEvent event) {
		
		 ArrayList<Object>list = new ArrayList<Object>();
		list.add("Marketing_Manager_Page_ReportChar");
		ClientUI.chat.client.handleMessageFromClientUI(list);
		list.add(ChatClient.ret.toString());
		ArrayList<String> bl = new ArrayList<String>();
		bl.add(" List of all clients sorted by activity level(From low to high):\n\n");
		bl.add(ChatClient.ret.toString());
		String formattedString = bl.toString()
			    .replace(",", "")  //remove the commas
			    .replace("[", "")  //remove the right bracket
			    .replace("]", "")  //remove the left bracket
			    .trim(); //remove trailing spaces from partially initialized arrays
		character.setText(formattedString);
	
	}

	/**
	 * Btncomment.
	 *
	 * @param event the event
	 */
	@FXML
	void btncomment(ActionEvent event) {

		ArrayList<String> list = new ArrayList<String>();
		list.add("Marketing_Manager_Page_ReportCampain");
		ClientUI.chat.client.handleMessageFromClientUI(list);
		list.add(ChatClient.ret.toString());
		String formattedString = list.toString()
			    .replace("Marketing_Manager_Page_ReportCampain","")
			    .replace("[", "")  //remove the right bracket
			    .replace("]", "")  //remove the left bracket
			    .replace(",", "")  //remove the left bracket
			    .replace("{", "\n")  //remove the left bracket
			    .replace("}", "\n")  //remove the left bracket
			    .replace("=", " purchase ")  //remove the left bracket
			    .trim(); //remove trailing spaces from partially initialized arrays*/
		comments.setText(formattedString);
	
	}

	/**
	 * Btnreport.
	 *
	 * @param event the event
	 */
	@FXML
	void btnreport(ActionEvent event) {// ���� ���
		marketingmanagerpage.setVisible(false);
		reportpage.setVisible(true);
		settingratepage.setVisible(false);
		salespage.setVisible(false);
		reportpage.setVisible(true);
	}

	/** The time list. */
	ObservableList<String> timeList = FXCollections.observableArrayList("00:00", "01:00", "02:00", "03:00", "04:00",
			"05:00", "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00",
			"17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00");
	
	/** The per list. */
	ObservableList<String> perList = FXCollections.observableArrayList(percentage());

	/**
	 * Percentage.
	 *
	 * @return the array list
	 */
	public ArrayList<String> percentage() {
		ArrayList<String> per = new ArrayList<String>();

		for (int i = 1; i < 101; i++)
			per.add(Integer.toString(i) + "%");

		return per;
	}

	/**
	 * Btnsales.
	 *
	 * @param event the event
	 */
	@FXML
	void btnsales(ActionEvent event) {// ���� ���
		settingratepage.setVisible(false);
		reportpage.setVisible(false);
		salespage.setVisible(true);

		Callback<DatePicker, DateCell> dayCellFactory = this.getDayCellFactory();
		startDate.setDayCellFactory(dayCellFactory);


		endDate.setDayCellFactory(dayCellFactory);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");

		startTime.setValue(LocalTime.now().format(dtf).toString());
		startTime.setItems(timeList);

		endTime.setValue("Choose time");
		endTime.setItems(timeList);

		discount.setValue("Choose precentage");
		discount.setItems(perList);

		startDate.setVisible(false);
		SDateTxt.setVisible(false);
		endDate.setVisible(false);
		EDateTxt.setVisible(false);
		startTime.setVisible(false);
		endTime.setVisible(false);
		EtimeTxt.setVisible(false);
		purpose.setVisible(false);
		putposeTxt.setVisible(false);
		updatebtn.setVisible(false);
		StimeTxt.setVisible(false);
		discountTxt.setVisible(false);
		discount.setVisible(false);

	}

	/**
	 * Btnsend.
	 *
	 * @param event the event
	 */
	@FXML
	void btnsend(ActionEvent event) {

		List<String> bl = new ArrayList<String>();
		double fuelPrice = 0;
		// if (!typeoffuel.getSelectionModel().isEmpty()) {
		bl.add("Marketing_Manager_Page_sendtonetworkmanager");
		bl.add((String) typeoffuel.getValue());
		if (typeoffuel.getValue().equals("Choose gas type")) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error window");
			alert.setHeaderText("Attention!");
			alert.setContentText("Please choose type of gas.");
			alert.showAndWait();
			return;
		} else if (newPrice.getText().equals("")) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error window");
			alert.setHeaderText("Attention!");
			alert.setContentText("You didn't put price!");
			alert.showAndWait();
			return;
		}
		fuelPrice = Double.parseDouble(newPrice.getText());
		bl.add(String.valueOf(fuelPrice));

		ClientUI.chat.client.handleMessageFromClientUI(bl);
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("confirmation window");
		alert.setHeaderText("send message");
		alert.setContentText("You send the message and now we wait to confirmation");
		alert.showAndWait();
		return;
		
	}

	/**
	 * Btnupdate.
	 *
	 * @param event the event
	 */
	@FXML
	void btnupdate(ActionEvent event) {
		updateWindow.setVisible(true);
		settingratepage.setVisible(false);
		gasTypeChoose.setValue("Choose gas type");
		gasTypeChoose.setItems(gasType);
		upbtn.setVisible(false);
	}

	/**
	 * Updatebtnforsale.
	 *
	 * @param event the event
	 */
	@FXML
	void updatebtnforsale(ActionEvent event) {
		List<String> bl = new ArrayList<String>();
		double discountpre = 0;
		if (!purpose.getText().equals("")) {

			bl.add("Marketing_Manager_Page_addtodiscount");
			bl.add((String) typeoffuel1.getValue());

			String str = discount.getValue(), strGet;
			strGet = str.replace(str.substring(str.length() - 1), "");
			discountpre = Double.parseDouble(strGet);
			bl.add(String.valueOf(discountpre));

			bl.add((String) purpose.getText());
			bl.add(startDate.getValue().toString());
			bl.add(endDate.getValue().toString());
			bl.add(startTime.getValue().toString());
			bl.add(endTime.getValue().toString());

			ClientUI.chat.client.handleMessageFromClientUI(bl);
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("confirmation window");
			alert.setHeaderText("the sale update");
			alert.setContentText("Details Updated");
			alert.showAndWait();
			return;
		} else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error window");
			alert.setHeaderText("Attention!");
			alert.setContentText("Please write propose!");
			alert.showAndWait();
			return;
		}

	}

	/**
	 * Initialize.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		typeoffuel.setItems(gasType);
		typeoffuel1.setItems(gasType);

	}

    /**
     * Back navigationreport.
     *
     * @param event the event
     */
    @FXML
    void backNavigationreport(ActionEvent event) {
    	settingratepage.setVisible(false);
		reportpage.setVisible(true);
		salespage.setVisible(false);
		marketingmanagerpage.setVisible(false);
    }


    /**
     * Back navigationsale.
     *
     * @param event the event
     */
    @FXML
    
    void backNavigationsale(ActionEvent event) {
    	settingratepage.setVisible(false);
		reportpage.setVisible(false);
		salespage.setVisible(true);
		marketingmanagerpage.setVisible(false);
    }
    
    /**
     * Handle disconnect button.
     *
     * @param event the event
     */
    public void handleDisconnectButton(ActionEvent event) {

		Platform.runLater(() -> {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Before You GO");
			alert.setContentText("Are You Sure?");

			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.CANCEL) {
				alert.close();
			} else {
				Login_Page_Boundary.handleSignOut("Marketing Manager");
				((Node) (event.getSource())).getScene().getWindow().hide();
			}
		});
	}
	}
