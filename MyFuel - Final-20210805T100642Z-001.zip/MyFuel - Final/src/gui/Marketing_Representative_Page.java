package gui;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;

import client.ChatClient;
import client.ClientUI;
import entities.Employees;

/**
 * The Class Marketing_Representative_Page that implements Initializable.
 */
public class Marketing_Representative_Page implements Initializable {

	/** The marketing user name. */
	public static String marketingUserName;
	
	/** The marketing stage. */
	static Stage marketingStage;

	/** The menu pane. */
	@FXML
	private AnchorPane menuPane = new AnchorPane();
	
	/** The add client btn. */
	@FXML
	private Button addClientBtn = new Button();
	
	/** The adjust client plan. */
	@FXML
	private Button adjustClientPlan = new Button();
	
	/** The Watch. */
	@FXML
	private Label Watch = new Label();
	
	/** The Customer rateing text area. */
	@FXML
	private TextArea CustomerRateingTextArea;

	/** The add client pane. */
	@FXML
	private AnchorPane addClientPane = new AnchorPane();
	
	/** The client id. */
	@FXML
	private TextField clientId;
	
	/** The client first name. */
	@FXML
	private TextField clientFirstName;
	
	/** The client last name. */
	@FXML
	private TextField clientLastName;
	
	/** The client user name. */
	@FXML
	private TextField clientUserName;
	
	/** The client password. */
	@FXML
	private PasswordField clientPassword;
	
	/** The client phone number. */
	@FXML
	private TextField clientPhoneNumber;
	
	/** The number choice box. */
	@FXML
	private ChoiceBox<String> numberChoiceBox = new ChoiceBox<String>();

	/** The full phone number. */
	private String fullPhoneNumber;
	
	/** The client email. */
	@FXML
	private TextField clientEmail;
	
	/** The payment details. */
	@FXML
	private Button paymentDetails = new Button();
	
	/** The back add client. */
	@FXML
	private Button backAddClient = new Button();
	
	/** The client sign up. */
	@FXML
	private Label clientSignUp = new Label();

	/** The enter credit pane. */
	@FXML
	private AnchorPane enterCreditPane = new AnchorPane();
	
	/** The client credit CVV. */
	@FXML
	private TextField clientCreditCVV;
	
	/** The client credit expire. */
	@FXML
	private DatePicker clientCreditExpire;
	
	/** The client credit number. */
	@FXML
	private TextField clientCreditNumber;
	
	/** The next add car. */
	@FXML
	private Button nextAddCar = new Button();

	/** The car list. */
	List<String> carList = new ArrayList<String>();
	
	/** The attach vehicle yes. */
	@FXML
	private RadioButton attachVehicleYes = new RadioButton();
	
	/** The attach vehicle no. */
	@FXML
	private RadioButton attachVehicleNo = new RadioButton();
	
	/** The add vehicle. */
	@FXML
	final ToggleGroup addVehicle = new ToggleGroup();
	
	/** The number of cars pane. */
	@FXML
	private AnchorPane numberOfCarsPane = new AnchorPane();
	
	/** The num of cars. */
	@FXML
	private TextField numOfCars = new TextField();
	
	/** The ok num of cars. */
	@FXML
	private Button okNumOfCars = new Button();
	
	/** The car license pane. */
	@FXML
	private AnchorPane carLicensePane = new AnchorPane();
	
	/** The firstcar number text field. */
	@FXML
	TextField firstcarNumberTextField = new TextField();
	
	/** The secondcar number text field. */
	@FXML
	TextField secondcarNumberTextField = new TextField();
	
	/** The thirdcar number text field. */
	@FXML
	TextField thirdcarNumberTextField = new TextField();

	/** The car number. */
	String carNumber;

	/** The car numbers pane. */
	@FXML
	private AnchorPane carNumbersPane = new AnchorPane();
	
	/** The car number text area. */
	@FXML
	private TextArea carNumberTextArea = new TextArea();
	
	/** The plus add carbtn. */
	@FXML
	private Button plusAddCarbtn = new Button();
	
	/** The finish registration. */
	@FXML
	private Button finishRegistration = new Button();
	
	/** The purchase plan. */
	@FXML
	private Button purchasePlan = new Button();
	
	/** The finish registration 2. */
	@FXML
	private Button finishRegistration2 = new Button();

	/** The i. */
	private int i = 0;

	/** The client type pane. */
	@FXML
	private AnchorPane clientTypePane = new AnchorPane();
	
	/** The client type. */
	@FXML
	private ChoiceBox<String> clientType = new ChoiceBox<String>();
	
	/** The back client type. */
	@FXML
	private Button backClientType = new Button();
	
	/** The finish message area. */
	@FXML
	private TextArea finishMessageArea = new TextArea();

	/** The new client. */
	List<Object> newClient = new ArrayList<Object>();

	/** The error alert. */
	Alert errorAlert = new Alert(AlertType.ERROR);

	/** The nav add client button. */
	@FXML
	private Button navAddClientBtn = new Button();
	
	/** The navigation arrow. */
	@FXML
	private Button navigationArrow = new Button();
	
	/** The back purchase plan. */
	@FXML
	private Button backPurchasePlan = new Button();

	/** The adjust pane. */
	@FXML
	private AnchorPane adjustPane = new AnchorPane();
	
	/** The adjust client id. */
	@FXML
	private TextField adjustClientId = new TextField();
	
	/** The check ID. */
	@FXML
	private Button checkID = new Button();
	
	/** The set purchase plan 2. */
	@FXML
	private Button setPurchasePlan2 = new Button();
	
	/** The client type 2. */
	@FXML
	private ChoiceBox<String> clientType2 = new ChoiceBox<String>();
	
	/** The adjust plan text. */
	@FXML
	private TextArea adjustPlanText = new TextArea();

	/**
	 * Initialize function all.
	 *
	 * @param location the location
	 * @param resources the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		LocalDate localDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String formattedString = localDate.format(formatter);
		Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
			LocalTime currentTime = LocalTime.now();
			Watch.setText((LocalDate.now().getDayOfWeek() + " " + formattedString + " " + currentTime.getHour() + ":"
					+ (currentTime.getMinute()) + ":" + currentTime.getSecond()));
		}), new KeyFrame(Duration.seconds(1)));
		clock.setCycleCount(Animation.INDEFINITE);
		clock.play();
		Callback<DatePicker, DateCell> dayCellFactory = this.getDayCellFactory();
		clientCreditExpire.setDayCellFactory(dayCellFactory);
		clientCreditExpire.setValue(localDate);
		menuPane.setVisible(true);
		enterCreditPane.setVisible(false);
		clientSignUp.setVisible(false);
		navigationArrow.setVisible(false);
		navAddClientBtn.setText("");
		navAddClientBtn.setVisible(false);
		adjustPane.setVisible(false);
		addClientPane.setVisible(false);
		clientTypePane.setVisible(false);
		clientType.getItems().add("Regular Monthly Subscription Single Vehicle");
		clientType.getItems().add("Regular Monthly Subscription Several Vehicle");
		clientType.getItems().add("Ocassionaly Client");
		clientType.getItems().add("Full Monthly Subscription Single Vehicle");
		clientType2.setValue("Regular Monthly Subscription Single Vehicle");
		clientType2.getItems().add("Regular Monthly Subscription Single Vehicle");
		clientType2.getItems().add("Regular Monthly Subscription Several Vehicle");
		clientType2.getItems().add("Ocassionaly Client");
		clientType2.getItems().add("Full Monthly Subscription Single Vehicle");
		attachVehicleNo.setToggleGroup(addVehicle);
		attachVehicleYes.setToggleGroup(addVehicle);
		CustomerRateingTextArea.setVisible(false);
		numberChoiceBox.getItems().addAll("050", "052", "053", "054", "055", "058");
		carNumberTextArea.setVisible(false);

		addClientBtn.setOnAction(e -> {
			/*
			 * Opens after clicking on Add Client button on the menu page
			 */
			paymentDetails.setVisible(true);
			CustomerRateingTextArea.setVisible(false);
			clientSignUp.setVisible(true);
			menuPane.setVisible(false);
			adjustPane.setVisible(false);
			addClientPane.setVisible(true);
			navAddClientBtn.setText("Add Client");
			navAddClientBtn.setVisible(true);
			navigationArrow.setVisible(true);
		});

		paymentDetails.setOnAction(e -> {
			/*
			 * Activated when Payment Details pressed on the add client page
			 */

			clientCreditExpire.setValue(LocalDate.now());
			if (clientId.getText().isEmpty() || clientFirstName.getText().isEmpty()
					|| clientLastName.getText().isEmpty() || clientUserName.getText().isEmpty()
					|| clientPassword.getText().isEmpty() || clientEmail.getText().isEmpty()
		) {

				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Please fill up all fields!");
				errorAlert.showAndWait();
			} else if (!checkIfIDCorrect(clientId.getText())) {

				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("ID Not Correct");
				errorAlert.showAndWait();
			} else if (!checkUserFullName(clientFirstName.getText())) {

				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Type first name without any numbers!");
				errorAlert.showAndWait();
			} else if (!checkUserFullName(clientLastName.getText())) {

				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Type last name without any numbers!");
				errorAlert.showAndWait();
			} else if (!checkPhoneNumber(numberChoiceBox.getSelectionModel().getSelectedItem(),
					clientPhoneNumber.getText())) {

				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Please enter a correct phone number.");
				errorAlert.showAndWait();
			} else if(!isValid(clientEmail.getText())){				
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Email not correct!");
				errorAlert.showAndWait();
				
			}
			else {
				newClient = new ArrayList<Object>();
				newClient.add("Verify Id");
				newClient.add(clientId.getText());
				ClientUI.chat.client.handleMessageFromClientUI(newClient);
				if (Employees.getIdOk().equals("OK")) { // Not Good! Id Already exist when trying to add
					errorAlert.setTitle("ERROR Window");
					errorAlert.setHeaderText("Attention!");
					errorAlert.setContentText("Id Exist!");
					errorAlert.showAndWait();
				} else {
					addClientPane.setVisible(true);
					clientTypePane.setVisible(false);
					enterCreditPane.setVisible(true);
				}

			}
		});

		nextAddCar.setOnAction(e -> {
			/*
			 * Activated when next Pressed on the Payment Details page
			 */
			finishRegistration2.setVisible(false);
			carLicensePane.setVisible(false);
			purchasePlan.setVisible(false);
			if (clientCreditNumber.getText().isEmpty() || clientCreditCVV.getText().isEmpty()
					|| clientCreditExpire.getValue().equals(LocalDate.now())) {
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Please fill up all fields!");
				errorAlert.showAndWait();
			} else if (!checkCardNumber(clientCreditNumber.getText())) {
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Credit card number incorrect!");
				errorAlert.showAndWait();
			} else if (!checkCVV(clientCreditCVV.getText())) {
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Please enter 3 digits CVV");
				errorAlert.showAndWait();
			} else {
				numberOfCarsPane.setVisible(true);
				carNumbersPane.setVisible(false);
			}
		});

		attachVehicleYes.setOnAction(e -> {
			/*
			 * Activated when next pressed on "YES" when "Add Vehicle" asked
			 */
			finishRegistration2.setVisible(false);
			finishRegistration.setVisible(false);
			purchasePlan.setVisible(true);
			carNumbersPane.setVisible(true);
			purchasePlan.setDisable(true);
			carNumberTextArea.setVisible(false);
		});

		attachVehicleNo.setOnAction(e -> {
			/*
			 * Activated when next pressed on "NO" when "Add Vehicle" asked
			 */
			finishRegistration2.setVisible(true);
			purchasePlan.setVisible(false);
			finishRegistration.setVisible(true);
			numOfCars.setText("");
			carLicensePane.setVisible(false);
			carNumbersPane.setVisible(false);
		});

		okNumOfCars.setOnAction(e -> {
			/*
			 * sending to server all of client information and after that, let the marketing
			 * representative add car numbers
			 */
			carLicensePane.setVisible(true);
			finishMessageArea.clear();
			carList.clear();
			carList.add("Add Car");
			carList.add((String) newClient.get(1));
		});

		plusAddCarbtn.setOnAction(e -> {
			/*
			 * Activate when "ADD CAR" pressed when adding new car license. for each
			 * vehicle, add to the table "vehicles" in the DB
			 */
			if (!checkCarNumber(firstcarNumberTextField.getText(), secondcarNumberTextField.getText(), thirdcarNumberTextField.getText())) {
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Please enter a correct car number");
				errorAlert.showAndWait();
			} else {
				i++;
				if (i == Integer.parseInt(numOfCars.getText())) {
					i = 0;
					numOfCars.setDisable(true);
					okNumOfCars.setDisable(true);
					firstcarNumberTextField.setDisable(true);
					secondcarNumberTextField.setDisable(true);
					thirdcarNumberTextField.setDisable(true);
					plusAddCarbtn.setDisable(true);
					purchasePlan.setDisable(false);
				}
				carNumberTextArea.setVisible(true);
				carNumberTextArea
						.setText("Vehicle number: " + carNumber + "\n" + "Added succesffuly");
				firstcarNumberTextField.setText("");
				secondcarNumberTextField.setText("");
				thirdcarNumberTextField.setText("");
			}
		});

		backAddClient.setOnAction(e -> {
			/*
			 * In any second, Marketing representative can press "Back" to return to main
			 * menu
			 */
			carNumbersPane.setDisable(false);
			clientTypePane.setVisible(false);
			clientSignUp.setVisible(false);
			enterCreditPane.setVisible(false);
			addClientPane.setVisible(false);
			paymentDetails.setVisible(false);
			clientCreditExpire.setValue(LocalDate.now());
			menuPane.setVisible(true);
			carLicensePane.setVisible(false);
			if (attachVehicleYes.isSelected() || attachVehicleNo.isSelected()) {
				attachVehicleYes.setSelected(false);
				attachVehicleNo.setSelected(false);
			}
			navigationArrow.setVisible(false);
			navAddClientBtn.setVisible(false);
			numberOfCarsPane.setVisible(false);
			carNumberTextArea.setText("");
			clientUserName.setText("");
			clientPassword.setText("");
			clientFirstName.setText("");
			clientLastName.setText("");
			clientId.setText("");
			clientEmail.setText("");
			clientCreditNumber.setText("");
			clientCreditCVV.setText("");
			numOfCars.setText("");
			finishMessageArea.clear();
			numberChoiceBox.setValue(null);

		});

		purchasePlan.setOnAction(e -> {
			/*
			 * Activated when clicking on "Purchase Plan" button, opens a new window to
			 * adjust purchase plan
			 */
			finishMessageArea.clear();
			finishRegistration.setVisible(true);
			numberOfCarsPane.setVisible(false);
			enterCreditPane.setVisible(false);
			clientTypePane.setVisible(true);
			addClientPane.setVisible(false);
			//clientType.setValue("Regular Monthly Subscription Single Vehicle");
		});

		clientType.setOnAction(e -> {
			/*
			 * Adjust client plan
			 */
			finishRegistration.setVisible(true);
			finishMessageArea.setText("Client Id: " + clientId.getText() + "\n\n"
					+ "Client Purchase Plan That Chosen:\n" + "**" + clientType.getValue() + "**");

		});

		backClientType.setOnAction(e -> {
			/*
			 * Any second, marketing representative can click on "Back" and change client
			 * details
			 */
			enterCreditPane.setVisible(true);
			paymentDetails.setVisible(true);
			numberOfCarsPane.setVisible(true);
			clientTypePane.setVisible(false);
			addClientPane.setVisible(true);

		});

		adjustClientPlan.setOnAction(e -> {
			CustomerRateingTextArea.setVisible(false);
			checkID.setVisible(true);
			adjustPane.setVisible(true);
			addClientPane.setVisible(false);
			navAddClientBtn.setText("Adjust Client Plan");
			navAddClientBtn.setVisible(true);
			setPurchasePlan2.setDisable(true);
			clientType2.setValue("Regular Monthly Subscription Single Vehicle");
			clientType2.setDisable(true);
			navigationArrow.setVisible(true);
			menuPane.setVisible(false);
			adjustPlanText.setVisible(false);

		});

		checkID.setOnAction(e -> {
			checkClientId();
		});

		setPurchasePlan2.setOnAction(e -> {

			newClient.removeAll(newClient);
			newClient.add("Purchase Plan");
			newClient.add(adjustClientId.getText());
			adjustPlanText.setVisible(true);
			newClient.add(clientType2.getValue());
			adjustPlanText.setText("Purchase Plan: " + "\n" + clientType2.getValue() + "\n" + "Changed Successfuly.");
			ClientUI.chat.client.handleMessageFromClientUI(newClient);
		});

		backPurchasePlan.setOnAction(e -> {
			adjustClientId.setText("");
			adjustPane.setVisible(false);
			menuPane.setVisible(true);
			navigationArrow.setVisible(false);
			navAddClientBtn.setVisible(false);
		});
	}

	/**
	 * Press check customer rating.
	 *
	 * @param event the event
	 */
	@FXML
	void pressCheckCustomerRating(ActionEvent event) {
		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object
		al.add("CheckCustomerRating");
		ClientUI.chat.client.handleMessageFromClientUI(al);
		AnaliticalMSG();
	}

	/**
	 * Analitical system MSG.
	 */
	public void AnaliticalMSG() {
		CustomerRateingTextArea.setVisible(true);
		int i;
		String res = "";
		for (i = 0; i < ChatClient.ret.size() - 1; i += 2)
			res += "ID:" + " " + ChatClient.ret.get(i) + "\n" + "Rate:" + " " + ChatClient.ret.get(i + 1) + "\n";
		CustomerRateingTextArea.setText("The Rate of Customers: \n" + res);
		ChatClient.ret.clear();

	}

	/**
	 * Handle disconnect button.
	 *
	 * @param event the event
	 */
	public void handleDisconnectButton(ActionEvent event) {

		Platform.runLater(() -> {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Before You GO");
			alert.setContentText("Are You Sure?");

			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.CANCEL) {
				alert.close();
			} else {
				Login_Page_Boundary.handleSignOut("Marketing Representative");
				((Node) (event.getSource())).getScene().getWindow().hide();
			}
		});
	}

	/**
	 * Sets the client purchase plan.
	 */
	public void setClientPurchasePlan() {
		/*
		 * Create new list and add to the table the type of the client.
		 */
		newClient.clear();
		newClient.add("Purchase Plan");
		newClient.add(clientId.getText());
		newClient.add(clientType.getValue());
		ClientUI.chat.client.handleMessageFromClientUI(newClient);
	}

	/**
	 * Finish registration pressed.
	 */
	public void finishRegistrationPressed() {
		/*
		 * Finish client registration
		 */
		addClient();
		addVehicle.getSelectedToggle().setSelected(false);
		clientTypePane.setVisible(false);
		clientSignUp.setVisible(false);
		enterCreditPane.setVisible(false);
		paymentDetails.setVisible(false);
		menuPane.setVisible(true);
		navigationArrow.setVisible(false);
		navAddClientBtn.setVisible(false);
		numberOfCarsPane.setVisible(false);
		adjustPane.setVisible(false);
		addClientPane.setVisible(false);
		clientUserName.setText("");
		clientPassword.setText("");
		clientFirstName.setText("");
		clientLastName.setText("");
		clientId.setText("");
		clientEmail.setText("");
		clientCreditNumber.setText("");
		clientCreditCVV.setText("");
		numOfCars.setText("");
		carLicensePane.setVisible(false);
		Employees.idOk = "NULL";

	}

	/**
	 * Adds the client.
	 */
	public void addClient() {

		if (attachVehicleNo.isSelected()) {
			newClient = new ArrayList<Object>();
			newClient.add("Add");
			newClient.add(clientId.getText());
			newClient.add(clientFirstName.getText());
			newClient.add(clientLastName.getText());
			newClient.add(clientUserName.getText());
			newClient.add(clientPassword.getText());
			newClient.add("Client");
			newClient.add(clientEmail.getText());
			newClient.add(false);
			newClient.add(fullPhoneNumber);
			newClient.add(clientCreditNumber.getText());
			newClient.add(clientCreditCVV.getText());
			newClient
					.add(clientCreditExpire.getValue().getMonthValue() + "/" + clientCreditExpire.getValue().getYear());
			if (numOfCars.getText().isEmpty())
				newClient.add("0");
			else
				newClient.add(numOfCars.getText());
			ClientUI.chat.client.handleMessageFromClientUI(newClient);
		} else {
			ClientUI.chat.client.handleMessageFromClientUI(carList);
			newClient = new ArrayList<Object>();
			newClient.add("Add");
			newClient.add(clientId.getText());
			newClient.add(clientFirstName.getText());
			newClient.add(clientLastName.getText());
			newClient.add(clientUserName.getText());
			newClient.add(clientPassword.getText());
			newClient.add("Client");
			newClient.add(clientEmail.getText());
			newClient.add(false);
			newClient.add(fullPhoneNumber);
			newClient.add(clientCreditNumber.getText());
			newClient.add(clientCreditCVV.getText());
			newClient
					.add(clientCreditExpire.getValue().getMonthValue() + "/" + clientCreditExpire.getValue().getYear());
			newClient.add(numOfCars.getText());
			ClientUI.chat.client.handleMessageFromClientUI(newClient);
			setClientPurchasePlan();
		}
	}

	/**
	 * Check client id.
	 */
	public void checkClientId() {

		newClient.removeAll(newClient);
		newClient.add("Verify Id");
		newClient.add(adjustClientId.getText());
		ClientUI.chat.client.handleMessageFromClientUI(newClient);
		if (Employees.getIdOk().equals("OK")) {
			setPurchasePlan2.setDisable(false);
			clientType2.setDisable(false);
		} else {
			errorAlert.setTitle("ERROR Window");
			errorAlert.setHeaderText("Attention!");
			errorAlert.setContentText("No such Id, Try Again");
			errorAlert.showAndWait();
		}

	}

	/**
	 * Check if ID correct.
	 *
	 * @param ID the id
	 * @return true, if successful
	 */
	public boolean checkIfIDCorrect(String ID) {
		String regex = "\\d+";
		if(!ID.matches(regex))
			return false;			

		int sum = 0, id, arr[] = new int[9], arr2[] = { 1, 2, 1, 2, 1, 2, 1, 2, 1 }, cal;
		if (ID.length() != 9) {
			return false;
		}
		id = Integer.parseInt(ID);
		for (int i = 0; i < 9; i++) {
			arr[i] = id % 10;
			id /= 10;
		}

		for (int i = 0; i < 9; i++) {
			cal = (arr[i] * arr2[i]);
			if (cal > 9) {
				sum += cal % 10;
				cal /= 10;
				sum += cal;
			} else {
				sum += cal;
			}
		}

		if ((sum % 10) == 0)
			return true;
		else
			return false;
	}

	/**
	 * Check user full name.
	 *
	 * @param Name the name
	 * @return the boolean
	 */
	public Boolean checkUserFullName(String Name) {
		char[] chars = Name.toCharArray();
		for (char c : chars)
			if (Character.isDigit(c))
				return false;
		if(!Name.matches("[a-zA-Z]*"))
			return false;
		return true;
	}

	/**
	 * Check phone number.
	 *
	 * @param phoneArea the phone area
	 * @param phoneNumberTxt the phone number txt
	 * @return true, if successful
	 */
	private boolean checkPhoneNumber(String phoneArea, String phoneNumberTxt) {
		
		String regex = "\\d+";
		if(!phoneArea.matches(regex))
			return false;	
		if(!phoneNumberTxt.matches(regex))
			return false;	

		fullPhoneNumber = phoneArea + phoneNumberTxt;

		// Function to check if phone number is correct
		if (fullPhoneNumber.length() > 10 || fullPhoneNumber.length() < 10)
			return false;
		char[] chars = fullPhoneNumber.toCharArray();
		for (char c : chars)
			if (Character.isLetter(c))
				return false;
		return true;
	}

	/**
	 * Check card number.
	 *
	 * @param cardNumber the card number
	 * @return true, if successful
	 */
	public boolean checkCardNumber(String cardNumber) {
		// this function checks if the credit card number ok
		String regex = "\\d+";
		if(!cardNumber.matches(regex))
			return false;	
		if (cardNumber.length() > 19 || cardNumber.length() < 8)
			return false;
		char[] chars = cardNumber.toCharArray();
		for (char c : chars)
			if (Character.isLetter(c))
				return false;
		return true;

	}

	/**
	 * Check CVV.
	 *
	 * @param CVV the cvv
	 * @return true, if successful
	 */
	public boolean checkCVV(String CVV) {
		// Function to check if phone number is correct
		String regex = "\\d+";
		if(!CVV.matches(regex))
			return false;	
		if (CVV.length() > 3 || CVV.length() < 3)
			return false;
		char[] chars = CVV.toCharArray();
		for (char c : chars)
			if (Character.isLetter(c))
				return false;
		return true;
	}

	/**
	 * Check car number.
	 *
	 * @param firstcarNumber the firstcar number
	 * @param secondcarNumber the secondcar number
	 * @param thirdcarNumber the thirdcar number
	 * @return true, if successful
	 */
	public boolean checkCarNumber(String firstcarNumber,String secondcarNumber,String thirdcarNumber) {
		
		char[] chars;
		int carLength = 8;	
		if(firstcarNumber.length() > 3 || firstcarNumber.length() < 2)
			return false;
	      carLength -= firstcarNumber.length();
	if(secondcarNumber.length() > 3 || secondcarNumber.length() < 2)
			return false;
      	carLength -= secondcarNumber.length();
      	if(carLength != 3)
      		return false;
      if(thirdcarNumber.length() > 3 || thirdcarNumber.length() < 2)
    	  return false;   
		 chars = firstcarNumber.toCharArray();
		for (char c : chars)
			if (Character.isLetter(c))
				return false;
		 chars = secondcarNumber.toCharArray();
		for (char c : chars)
			if (Character.isLetter(c))
				return false;
		 chars = thirdcarNumber.toCharArray();
		for (char c : chars)
			if (Character.isLetter(c))
				return false;
      carNumber = firstcarNumber + "-" + secondcarNumber + "-" + thirdcarNumber;
      carList.add(carNumber);
      return true;
	}
	
/**
 * Checks if is valid.
 *
 * @param email the email
 * @return true, if is valid
 */
public boolean isValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&-]+(?:\\." + "[a-zA-Z0-9_+&-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";

		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

	/**
	 * Gets the day cell factory.
	 *
	 * @return the day cell factory
	 */
	private Callback<DatePicker, DateCell> getDayCellFactory() {
		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {

			@Override
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						// Disable all dates before today
						if (item.isBefore(LocalDate.now())) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}
					}
				};

			}

		};
		return dayCellFactory;
	}
}
