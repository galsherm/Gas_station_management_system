package gui;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Optional;
import java.util.ResourceBundle;
import client.ChatClient;
import client.ClientController;
import client.ClientUI;
import entities.clients;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.util.Callback;

/**
 * The Class HomeFuelingController.
 */
public class HomeFuelingController implements Initializable {

	/** The client user name. */
	public static String clientUserName;
	
	/** The dis. */
	private double dis = 0;
	
	/** The full res calc. */
	private double fullResCalc = 0; //price
	
	/** The subs. */
	private String subs = "";

	/** The Fuel 95 price. */

	@FXML
	private Text Fuel_95Price;

	/** The Soler price. */
	@FXML
	private Text SolerPrice;

	/** The Mini bike price. */
	@FXML
	private Text Mini_bikePrice;

	/** The Home heating price. */
	@FXML
	private Text Home_heatingPrice;

	/** The clientcontroller. */
	public static ClientController clientcontroller;

	/** The Main page. */
	@FXML
	private AnchorPane MainPage;

	/** The Home fueling page. */
	@FXML
	private AnchorPane HomeFuelingPage;

	/** The acceptance window. */
	@FXML
	private AnchorPane acceptanceWindow;

	/** The btn order. */
	@FXML
	private Button btnOrder;

	/** The status track. */
	@FXML
	private Text statusTrack;

	/** The btb tracking. */
	@FXML
	private Button btbTracking;

	/** The Ok track. */
	@FXML
	private Button OkTrack;

	/** The ID field for track. */
	@FXML
	private TextField IDFieldForTrack;

	/** The tracking details. */
	@FXML
	private TextArea trackingDetails;

	/** The timer. */
	@FXML
	private Text timer;

	/** The Fuel 95 window. */
	@FXML
	private AnchorPane Fuel95Window;

	/**
	 * Gasoline controller.
	 *
	 * @param event the event
	 */
	@FXML
	void GasolineController(ActionEvent event) {
		Fuel95Window.setVisible(true);
	}

	/** The full mon sub win. */
	@FXML
	private AnchorPane fullMonSubWin;
	

	/** The No full. */
	@FXML
	private Button NoFull;
	
	/** The Yes full. */
	@FXML
	private Button YesFull;
	
	/** The ok bye. */
	@FXML
	private Button okBye;
	
	/** The mounthly payment. */
	@FXML
	private Button mounthlyPayment;
	
	/**
	 * Connect pressed func.
	 *
	 * @param event the event
	 */
	@FXML
	void  connectPressedFunc(ActionEvent event) {
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("11");
		if(IDField.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error window");
			alert.setHeaderText("Attention!");
			alert.setContentText("Fill the ID field!");
			alert.showAndWait();
		}else {
			list.add(IDField.getText());
			
			if(LocalDate.now().toString().substring(8,10).equals("21")) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Calendar c = Calendar.getInstance();
				String date2 = LocalDate.now().toString();
				try {
					c.setTime(sdf.parse(date2));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				c.add(Calendar.MONTH ,-1);
				
				String newDate = sdf.format(c.getTime());
				
				list.add(newDate);
				
				ClientUI.chat.client.handleMessageFromClientUI(list);
				if(ChatClient.ret.get(0).equals("Error")){
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("Error window");
					alert.setHeaderText("Attention!");
					alert.setContentText("The ID is not in the appropriate subscription");
					alert.showAndWait();
				}else if(Double.parseDouble(ChatClient.ret.get(0)) == 0){
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("Error window");
					alert.setHeaderText("Attention!");
					alert.setContentText("The ID is not purchase nothing!");
					alert.showAndWait();
				}
				EndPrice.setText(ChatClient.ret.get(0));
			}else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Error window");
				alert.setHeaderText("Attention!");
				alert.setContentText("You need to pay just in day 21");
				alert.showAndWait();
			}
			
			
		}
		
		
	}
	
	/**
	 * Ok bye func, presses ok on the screen.
	 *
	 * @param event the event
	 */
	@FXML
	void okByeFunc(ActionEvent event) {
		byeWindow.setVisible(false);
		chooseGas.setVisible(false);
		txtGasType.setVisible(false);
		red5.setVisible(false);
		txtCarNum.setVisible(false);
		carNumberChoose.setVisible(false);
		txtFullName.setVisible(false);
		txtFullName.setVisible(false);
		txtSurname.setVisible(false);
		txtPhoneNum.setVisible(false);
		btnNAD.setVisible(false);
		firstNameCor.setVisible(false);
		surnameCor.setVisible(false);
		phoneNumCor.setVisible(false);
		DateField.setVisible(false);
		txtSchedule.setVisible(false);
		txtImmidiacy.setVisible(false);
		TypeBox.setVisible(false);
		HighLevelBox.setVisible(false);
		amount.setVisible(false);
		txtAmountGas.setVisible(false);
		OKBtn.setVisible(false);
		btnComplete.setVisible(false);
		red1.setVisible(false);
		red2.setVisible(false);
		red3.setVisible(false);
		red4.setVisible(false);
		red6.setVisible(false);
		redXbutt.setVisible(false);
		signV.setVisible(false);
		IDField.setDisable(false);
		checkAgain.setVisible(false);
		
		
	}
	
	/**
	 * No full func.
	 *
	 * @param event the event
	 */
	@FXML
	void NoFullFunc(ActionEvent event) {
		fullMonSubWin.setVisible(false);
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
		byeWindow.setVisible(true);
	}
	
	/**
	 * Yes full func.
	 *
	 * @param event the event
	 */
	@FXML
	void YesFullFunc(ActionEvent event) {
		fullMonSubWin.setVisible(false);
		String forSum = null;
		String text = amount.getText();
		double discount;
		
		if(checkDiscount(chooseGas.getValue())) {
			discount = this.dis/100;
		}else {
			discount = 0;
		}
		
		ArrayList<String> list = new ArrayList<String>();

		list.add("3");

		switch (chooseGas.getValue()) {

		case "Fuel 95":
			list.add("Fuel_95");
			forSum = "Fuel_95";
			break;
		case "Soler":
			list.add("Soler");
			forSum = "Soler";
			break;

		case "Fuel mini bike":
			list.add("Fuel_mini_bike");
			forSum = "Fuel_mini_bike";
			break;

		case "Fuel Home Heating":
			list.add("Fuel_Home_Heating");
			forSum = "Fuel_Home_Heating";
			break;

		default:
			break;
		}

		list.add(text);
		
		ClientUI.chat.client.handleMessageFromClientUI(list);
		if (ChatClient.check == false) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error window");
			alert.setHeaderText("Attention!");
			alert.setContentText("There is no inventory!");
			alert.showAndWait();
		} else {
			ChatClient.check = true;
			if (text.equals("")) {
				EndPrice.setText("Please write amount inside the field.");
				return;
			} else {
				for (int i = 0; i < text.length(); i++) {
					if (text.charAt(i) < 48 || text.charAt(i) > 57) {
						EndPrice.setText("You put wrong value.\nPlease put amount again.");
						return;
					}
				}
			}
			flag = true;

			if (chooseGas.getValue().equals("Fuel Home Heating")) {
				double numOfAmount = Double.parseDouble(text);
				double calc, deliveryPrice = 30, gasPricePerLiter;

				list.clear();
				list.add("4");
				list.add("Fuel_Home_Heating");
				ClientUI.chat.client.handleMessageFromClientUI(list);

				gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
				ChatClient.ret.clear();

				if (HighLevelBox.isSelected()) {
					calc = numOfAmount * gasPricePerLiter + (gasPricePerLiter*numOfAmount * 0.02) + deliveryPrice;
					EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount + "\nType Of delivery: High level\n"
							+ "Delivery price: 30\n" + "End Price: " + calc);
				} else if (TypeBox.isSelected()) {
					if (numOfAmount < 600) {
						calc = (numOfAmount * gasPricePerLiter)-discount*(numOfAmount * gasPricePerLiter) + deliveryPrice;
						EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount
								+ "\nType Of delivery: Regular delivery no discount\n" + "Delivery price: 30\n"
								+ "End Price: " + calc);
					} else if (numOfAmount >= 600 && numOfAmount <= 800) {
						calc = (numOfAmount * gasPricePerLiter - (numOfAmount *gasPricePerLiter * 0.03)) - discount*(numOfAmount * gasPricePerLiter - (numOfAmount * 0.03)) + deliveryPrice;
						EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount
								+ "\nType Of delivery: Regular delivery 3% discount\n" + "Delivery price: 30\n"
								+ "End Price: " + calc);
					} else if (numOfAmount > 800) {
						calc = (numOfAmount * gasPricePerLiter - (numOfAmount *gasPricePerLiter * 0.04))-discount*(numOfAmount * gasPricePerLiter - (numOfAmount * 0.04)) + deliveryPrice;
						EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount
								+ "\nType Of delivery: Regular delivery 4% discount\n" + "Delivery price: 30\n"
								+ "End Price: " + calc);
					}
				}
			} else {
				double numOfAmount = Double.parseDouble(text);
				double calc, gasPricePerLiter,deliveryPrice = 30;

				list.clear();
				list.add("4");
				list.add(forSum);
				ClientUI.chat.client.handleMessageFromClientUI(list);

				gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
				ChatClient.ret.clear();

				calc = numOfAmount * gasPricePerLiter;
				list.clear();
				list.add("9");
				list.add(IDField.getText());
				ClientUI.chat.client.handleMessageFromClientUI(list);
				subs = ChatClient.c1.getSubscription();
				if(subs.equals("fullMonSub")) {
					calc = calcOrderPrice("regMonSubSevVeh",calc,gasPricePerLiter);
					calc -= calc*discount;
					calc += deliveryPrice;
				}else {
					calc = calcOrderPrice(subs,calc,gasPricePerLiter);
					calc -= calc*discount;
					calc += deliveryPrice;
				}
				
				fullResCalc = calc;
				
				EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount + "\nType of gas: " + forSum
						+ "\nDelivery price: 30\n" + "End Price: " + calc + "\nSubscription: " + subs + "\nDate purchase: " + DateField.getValue() + "\nTime purchase: " + LocalTime.now());
			}
			btnComplete.setVisible(true);
		}
	}
	
	/** The bye window. */
	@FXML
	private AnchorPane byeWindow;

	/**
	 * Open button order.
	 *
	 * @param event the event
	 */
	@FXML
	void openBtnOrder(ActionEvent event) {
		MainPage.setVisible(false);
		HomeFuelingPage.setVisible(true);
		OkTrack.setVisible(false);// �����
		trackingDetails.clear();
		trackingDetails.setVisible(false);
		statusTrack.setVisible(false);
		carNumberChoose.setVisible(false);
		txtCarNum.setVisible(false);
		red6.setVisible(false);
		EndPrice.clear();

	}

	/**
	 * Tracking func.
	 *
	 * @param event the event
	 */
	@FXML
	void trackingFunc(ActionEvent event) {
		IDFieldForTrack.setVisible(true);
		OkTrack.setVisible(true);

	}

	/**
	 * Open tracking window.
	 *
	 * @param event the event
	 */
	@FXML
	void OpenTrackingWindow(ActionEvent event) {// �����
		trackingDetails.setVisible(true);
		statusTrack.setVisible(true);
		ArrayList<String> list = new ArrayList<String>();
		list.add("5");
		list.add(IDFieldForTrack.getText());

		ClientUI.chat.client.handleMessageFromClientUI(list);

		list = ChatClient.ret;
		if (!list.get(1).equals("Error")) {
			trackingDetails
					.setText("Order number: " + list.get(1) + "\nID: " + list.get(2) + "\nName: " + list.get(3) + "\n");
			trackingDetails.setText(
					trackingDetails.getText() + "Phone number: " + list.get(4) + "\nOrder date: " + list.get(5) + "\n");
			if (list.get(6).equals("1")) {
				String[] parts = list.get(12).split(":");
				int time = Integer.parseInt(parts[0]) + 6;
				parts[0] = Integer.toString(time);
				trackingDetails.setText(trackingDetails.getText() + "Order type: Urgent level\n" + "Time expectation: "
						+ parts[0] + ":" + parts[1] + "\n");
			} else if (list.get(7).equals("1")) {
				trackingDetails.setText(trackingDetails.getText() + "Order type: Normal level\n");
			}

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Calendar c = Calendar.getInstance();
			String date2 = list.get(5);
			try {
				c.setTime(sdf.parse(date2));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			c.add(Calendar.DAY_OF_MONTH, 14);
			String newDate = sdf.format(c.getTime());

			trackingDetails.setText(trackingDetails.getText() + "Date expectation: " + newDate + "\nAmount of gas: "+ list.get(8) + "\nOrder price: "+ list.get(9) + "\nFour numbers credit card: "+ list.get(10) + "\nGas type: "+ list.get(11) +"\nTime order: " + list.get(12) + "\nCarNumber: " + list.get(13));
			
			
			
		} else {
			trackingDetails.setText("No order number!");
		}

	}

	/**
	 * Gets the day cell factory.
	 *
	 * @return the day cell factory
	 */
	// Factory to create Cell of DatePicker
	private Callback<DatePicker, DateCell> getDayCellFactory() {

		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {

			@Override
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						// Disable Monday, Tueday, Wednesday.
						if (item.isBefore(LocalDate.now())) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}
					}
				};

			}

		};
		return dayCellFactory;
	}

	/** The flag. */
	boolean flag = false;


	/** The Date field. */
	@FXML
	private DatePicker DateField;

	/** The no existing window. */
	@FXML
	private AnchorPane noExistingWindow;

	/** The price list window. */
	@FXML
	private AnchorPane priceListWindow;

	/** The txt schedule. */
	@FXML
	private Text txtSchedule;

	/** The txt immidiacy. */
	@FXML
	private Text txtImmidiacy;

	/** The txt gas type. */
	@FXML
	private Text txtGasType;

	/** The red 1. */
	@FXML
	private Text red1;

	/** The red 2. */
	@FXML
	private Text red2;

	/** The red 3. */
	@FXML
	private Text red3;

	/** The red 4. */
	@FXML
	private Text red4;

	/** The red 5. */
	@FXML
	private Text red5;

	/** The red 6. */
	@FXML
	private Text red6;// �����

	/** The txt car num. */
	@FXML
	private Text txtCarNum;// �����

	/** The choose gas. */
	@FXML
	private ComboBox<String> chooseGas;

	/** The car number choose. */
	@FXML
	private ComboBox<String> carNumberChoose;// �����

	/** The txt surname. */
	@FXML
	private Text txtSurname;

	/** The txt full name. */
	@FXML
	private Text txtFullName;

	/** The txt phone num. */
	@FXML
	private Text txtPhoneNum;

	/** The sign V. */
	@FXML
	private ImageView signV;

	/** The red xbutt. */
	@FXML
	private ImageView redXbutt;

	/** The F nfield. */
	@FXML
	private TextField FNfield;

	/** The ID field. */
	@FXML
	private TextField IDField;

	/** The surname cor. */
	@FXML
	private Text surnameCor;

	/** The first name cor. */
	@FXML
	private Text firstNameCor;

	/** The phone num cor. */
	@FXML
	private Text phoneNumCor;

	/** The surname field. */
	@FXML
	private TextField surnameField;

	/** The P nfield. */
	@FXML
	private TextField PNfield;

	/** The amount. */
	@FXML
	private TextField amount;

	/** The High level box. */
	@FXML
	private CheckBox HighLevelBox;

	/** The txt amount gas. */
	@FXML
	private Text txtAmountGas;

	/** The Type box. */
	@FXML
	private CheckBox TypeBox;

	/** The check again. */
	@FXML
	private Button checkAgain;

	/** The OK btn. */
	@FXML
	private Button OKBtn;

	/** The btn F 1. */
	@FXML
	private Button btnF1;

	/** The check client. */
	@FXML
	private Button checkClient;

	/** The btn complete. */
	@FXML
	private Button btnComplete;

	/** The End price. */
	@FXML
	private TextArea EndPrice;

	/** The Back B. */
	@FXML
	private Button BackB;

	/** The btn NAD. */
	@FXML
	private Button btnNAD;

	/**
	 * Car number choose func.
	 *
	 * @param event the event
	 */
	@FXML
	void carNumChooseFunc(ActionEvent event) {

		firstNameCor.setVisible(true);
		surnameCor.setVisible(true);
		phoneNumCor.setVisible(true);
		btnNAD.setVisible(true);
		IDField.setDisable(true);
		txtFullName.setVisible(true);
		txtPhoneNum.setVisible(true);
		DateField.setVisible(true);
		txtSchedule.setVisible(true);
		OKBtn.setVisible(true);
		txtSurname.setVisible(true);
		checkClient.setVisible(false);
		red4.setVisible(true);
		DateField.setDisable(true);
		txtAmountGas.setVisible(true);
		amount.setVisible(true);

	}

	/** The list cars. */
	ObservableList<String> listCars;
	
	/**
	 * Choose gas box.
	 *
	 * @param event the event
	 */
	@FXML
	void chooseGasBox(ActionEvent event) {
		clients tc;

		ArrayList<String> list = new ArrayList<String>();

		tc = ChatClient.c1;
		if (!ChatClient.c1.getFirstName().equals("Error")) {
			firstNameCor.setText(tc.getFirstName());
			surnameCor.setText(tc.getSurname());
			phoneNumCor.setText(tc.getPhoneNum());

			list.add("6");
			list.add(IDField.getText());
			ClientUI.chat.client.handleMessageFromClientUI(list);

			ChatClient.ret.remove(0);
			listCars = FXCollections.observableArrayList(ChatClient.ret);

			if (!chooseGas.getValue().equals("Fuel Home Heating")) {
				carNumberChoose.setValue("Click to choose");
				carNumberChoose.setItems(listCars);
				carNumberChoose.setVisible(true);
				txtCarNum.setVisible(true);
				btnComplete.setVisible(false);
				OKBtn.setVisible(false);
				amount.setVisible(false);
				txtAmountGas.setVisible(false);
				TypeBox.setVisible(false);
				HighLevelBox.setVisible(false);
				red3.setVisible(false);
				txtImmidiacy.setVisible(false);
				DateField.setVisible(false);
				red1.setVisible(false);
				red4.setVisible(false);
				txtSchedule.setVisible(false);
				btnNAD.setVisible(false);
				PNfield.setVisible(false);
				red2.setVisible(false);
				txtPhoneNum.setVisible(false);
				txtSurname.setVisible(false);
				surnameCor.setVisible(false);
				phoneNumCor.setVisible(false);
				txtFullName.setVisible(false);
				firstNameCor.setVisible(false);
				red6.setVisible(true);
				DateField.setDisable(true);

			} else {

				btnComplete.setVisible(false);
				OKBtn.setVisible(false);
				amount.setVisible(false);
				txtAmountGas.setVisible(false);
				TypeBox.setVisible(false);
				HighLevelBox.setVisible(false);
				red3.setVisible(false);
				txtImmidiacy.setVisible(false);
				DateField.setVisible(false);
				red1.setVisible(false);
				red4.setVisible(false);
				txtSchedule.setVisible(false);
				btnNAD.setVisible(false);
				PNfield.setVisible(false);
				red2.setVisible(false);
				txtPhoneNum.setVisible(false);
				txtSurname.setVisible(false);
				surnameCor.setVisible(false);
				phoneNumCor.setVisible(false);
				txtFullName.setVisible(false);
				firstNameCor.setVisible(false);
				firstNameCor.setVisible(true);
				surnameCor.setVisible(true);
				phoneNumCor.setVisible(true);
				red6.setVisible(false);
				carNumberChoose.setVisible(false);
				txtCarNum.setVisible(false);
				if (chooseGas.getValue().equals("Fuel Home Heating"))
				{
					EndPrice.setText("Choose 'Urgent order' Or 'Normal order'.");
					txtImmidiacy.setVisible(true);
					HighLevelBox.setVisible(true);
					TypeBox.setVisible(true);
				} else {
					amount.setVisible(true);
					txtImmidiacy.setVisible(false);
					HighLevelBox.setVisible(false);
					TypeBox.setVisible(false);
					txtAmountGas.setVisible(true);
					red1.setVisible(true);
				}
				btnNAD.setVisible(true);//
				IDField.setDisable(true);//
				txtFullName.setVisible(true);//
				txtPhoneNum.setVisible(true);//
				DateField.setVisible(true);//
				txtSchedule.setVisible(true);//
				OKBtn.setVisible(true);//
				txtSurname.setVisible(true);//
				checkClient.setVisible(false);//
				red4.setVisible(true);
				DateField.setDisable(true);
			}

		}

	}

	/**
	 * Ok price list, close screen.
	 *
	 * @param event the event
	 */
	@FXML
	void OkPriceList(ActionEvent event) {
		priceListWindow.setVisible(false);
	}

	/**
	 * Next after details.
	 *
	 * @param event the event
	 */
	@FXML
	void nextAfetDetails(ActionEvent event) {///////////////////

		ArrayList<String> list2 = getGasPrice();

		Fuel_95Price.setText(list2.get(0));
		SolerPrice.setText(list2.get(1));
		Mini_bikePrice.setText(list2.get(2));
		Home_heatingPrice.setText(list2.get(3));
		priceListWindow.setVisible(true);

	}

	/**
	 * Gets the gas price.
	 *
	 * @return the gas price
	 */
	public ArrayList<String> getGasPrice() {
		ArrayList<String> p = new ArrayList<String>(); // (fuel95 + soler + minibike + homeheating)

		ArrayList<String> list2 = new ArrayList<String>();
		list2.add("4");
		list2.add("Fuel_95");
		ClientUI.chat.client.handleMessageFromClientUI(list2);
		p.add(ChatClient.ret.get(1));
		ChatClient.ret.clear();
		list2.clear();

		list2.add("4");
		list2.add("Fuel_Home_Heating");
		ClientUI.chat.client.handleMessageFromClientUI(list2);
		p.add(ChatClient.ret.get(1));
		ChatClient.ret.clear();
		list2.clear();

		list2.add("4");
		list2.add("Fuel_mini_bike");
		ClientUI.chat.client.handleMessageFromClientUI(list2);
		p.add(ChatClient.ret.get(1));
		ChatClient.ret.clear();
		list2.clear();

		list2.add("4");
		list2.add("Soler");
		ClientUI.chat.client.handleMessageFromClientUI(list2);
		p.add(ChatClient.ret.get(1));
		ChatClient.ret.clear();
		list2.clear();

		return p;
	}

	/**
	 * Back button.
	 *
	 * @param event the event
	 */
	@FXML
	void BackButton(ActionEvent event) {
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
		CVVField.clear();
		cashWindow.setVisible(false);
		IDField.setDisable(false);
		signV.setVisible(false);
		redXbutt.setVisible(false);
		txtFullName.setVisible(false);
		FNfield.setVisible(false);
		txtPhoneNum.setVisible(false);
		PNfield.setVisible(false);
		txtSchedule.setVisible(false);
		DateField.setVisible(false);
		txtImmidiacy.setVisible(false);
		HighLevelBox.setVisible(false);
		TypeBox.setVisible(false);
		red1.setVisible(false);
		red2.setVisible(false);
		red3.setVisible(false);
		red4.setVisible(false);
		surnameField.setVisible(false);
		txtSurname.setVisible(false);
		checkClient.setVisible(true);
		checkAgain.setVisible(false);
		phoneNumCor.setVisible(false);
		surnameCor.setVisible(false);
		firstNameCor.setVisible(false);
		btnNAD.setVisible(false);
		OKBtn.setVisible(false);
		amount.setVisible(false);
		txtAmountGas.setVisible(false);
		btnComplete.setVisible(false);
		HighLevelBox.setSelected(false);
		TypeBox.setSelected(false);
		amount.clear();
		chooseGas.setVisible(false);
		txtGasType.setVisible(false);
		red5.setVisible(false);
		CVVField.clear();
		IDField.clear();
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
		txtCarNum.setVisible(false);
		carNumberChoose.setVisible(false);
		IDFieldForTrack.clear();
		IDFieldForTrack.setVisible(false);
		acceptanceWindow.setVisible(false);
		


	}

	/** The Main btn. */
	@FXML
	private Button MainBtn;

	/**
	 * Back main btn.
	 *
	 * @param event the event
	 */
	@FXML
	void BackMainBtn(ActionEvent event) {
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
	}

	/**
	 * High level box acc.
	 *
	 * @param event the event
	 */
	@FXML
	void HighLevBoxAcc(ActionEvent event) {// �����
		if (HighLevelBox.isSelected()) {
			TypeBox.setSelected(false);
			amount.setVisible(true);
			OKBtn.setVisible(true);
			red1.setVisible(true);
			txtAmountGas.setVisible(true);
		} else if (!TypeBox.isSelected()) {
			amount.setVisible(false);
			OKBtn.setVisible(false);
			txtAmountGas.setVisible(false);
			red1.setVisible(false);
		}
	}

	/**
	 * Type acc.
	 *
	 * @param event the event
	 */
	@FXML
	void TypeAcc(ActionEvent event) {// �����
		if (TypeBox.isSelected()) {
			HighLevelBox.setSelected(false);
			amount.setVisible(true);
			OKBtn.setVisible(true);
			txtAmountGas.setVisible(true);
			red1.setVisible(true);
		} else if (!HighLevelBox.isSelected()) {
			amount.setVisible(false);
			OKBtn.setVisible(false);
			txtAmountGas.setVisible(false);
			red1.setVisible(false);
		}
	}

	/**
	 * Show price after O kbtn.
	 *
	 * @param event the event
	 */
	@FXML
	void ShowPriceAfterOKbtn(ActionEvent event) {
		String forSum = null;
		String text = amount.getText();
		double discount;
		
		
		ArrayList<String> list = new ArrayList<String>(), list2 = new ArrayList<String>();

		list.add("3");

		switch (chooseGas.getValue()) {

		case "Fuel 95":
			list.add("Fuel_95");
			forSum = "Fuel_95";
			break;
		case "Soler":
			list.add("Soler");
			forSum = "Soler";
			break;

		case "Fuel mini bike":
			list.add("Fuel_mini_bike");
			forSum = "Fuel_mini_bike";
			break;

		case "Fuel Home Heating":
			list.add("Fuel_Home_Heating");
			forSum = "Fuel_Home_Heating";
			break;

		default:
			break;
		}

		if(checkDiscount(chooseGas.getValue())) {
			discount = this.dis/100;
		}else {
			discount = 0;
		}
		
		list.add(text);

		if (amount.getText().equals("")) {
			EndPrice.setText("Put amount of liter and then try again.");
			return;
		}

		list2.add("9");
		list2.add(IDField.getText());
		ClientUI.chat.client.handleMessageFromClientUI(list2);
		String res = ChatClient.c1.getSubscription();
		
		if(res.equals("fullMonSub")) {
			fullMonSubWin.setVisible(true);
		}else {
			ClientUI.chat.client.handleMessageFromClientUI(list);
			if (ChatClient.check == false) {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Error window");
				alert.setHeaderText("Attention!");
				alert.setContentText("There is no inventory!");
				alert.showAndWait();
			} else {
				if (text.equals("")) {
					EndPrice.setText("Please write amount inside the field.");
					return;
				} else {
					for (int i = 0; i < text.length(); i++) {
						if (text.charAt(i) < 48 || text.charAt(i) > 57) {
							EndPrice.setText("You put wrong value.\nPlease put amount again.");
							return;
						}
					}
				}
				flag = true;

				if (chooseGas.getValue().equals("Fuel Home Heating")) {
					double numOfAmount = Double.parseDouble(text);
					double calc, deliveryPrice = 30, gasPricePerLiter;

					list.clear();
					list.add("4");
					list.add("Fuel_Home_Heating");
					ClientUI.chat.client.handleMessageFromClientUI(list);

					gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
					ChatClient.ret.clear();

					if (HighLevelBox.isSelected()) {
						calc = (numOfAmount * gasPricePerLiter + (numOfAmount*gasPricePerLiter* 0.02)) - discount*(numOfAmount * gasPricePerLiter + (numOfAmount*gasPricePerLiter* 0.02)) + deliveryPrice;
						EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount + "\nType Of delivery: High level\n"
								+ "Delivery price: 30\n" + "End Price: " + calc);
					} else if (TypeBox.isSelected()) {
						if (numOfAmount < 600) {
							calc = (numOfAmount * gasPricePerLiter) - discount*(numOfAmount * gasPricePerLiter) + deliveryPrice;
							EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount
									+ "\nType Of delivery: Regular delivery no discount\n" + "Delivery price: 30\n"
									+ "End Price: " + calc);
						} else if (numOfAmount >= 600 && numOfAmount <= 800) {
							calc = (numOfAmount * gasPricePerLiter - (numOfAmount * gasPricePerLiter*  0.03)) - discount*(numOfAmount * gasPricePerLiter - (numOfAmount * gasPricePerLiter * 0.03)) + deliveryPrice;
							EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount
									+ "\nType Of delivery: Regular delivery 3% discount\n" + "Delivery price: 30\n"
									+ "End Price: " + calc);
						} else if (numOfAmount > 800) {
							calc = (numOfAmount * gasPricePerLiter - (numOfAmount * gasPricePerLiter * 0.04)) - discount*(numOfAmount * gasPricePerLiter - (numOfAmount * gasPricePerLiter *0.04)) + deliveryPrice;
							
							EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount
									+ "\nType Of delivery: Regular delivery 4% discount\n" + "Delivery price: 30\n"
									+ "End Price: " + calc);
						}
					}
				} else {
					double numOfAmount = Double.parseDouble(text);
					double calc, gasPricePerLiter,deliveryPrice = 30;

					list.clear();
					list.add("4");
					list.add(forSum);
					ClientUI.chat.client.handleMessageFromClientUI(list);

					gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
					ChatClient.ret.clear();

					calc = numOfAmount * gasPricePerLiter;
					list.clear();
					list.add("9");
					list.add(IDField.getText());
					ClientUI.chat.client.handleMessageFromClientUI(list);
					subs = ChatClient.c1.getSubscription();
					calc = calcOrderPrice(subs,calc,gasPricePerLiter);
					fullResCalc = calc;

					
					if(checkDiscount(chooseGas.getValue())) {
						fullResCalc -= fullResCalc*discount;
						fullResCalc += deliveryPrice;
					}else {
						fullResCalc += deliveryPrice;
					}
					
					EndPrice.setText("Order summary:\n\nAmount: " + numOfAmount + "\nType of gas: " + forSum
							+ "\nDelivery price: 30\n" + "End Price: " + fullResCalc);
				}
				btnComplete.setVisible(true);
			}

		}
		
	}
	
	/**
	 * Calculate order price.
	 *
	 * @param subscription the subscription
	 * @param price the price
	 * @param pricePerLiter the price per liter
	 * @return the double
	 */
	public double calcOrderPrice(String subscription,double price, double pricePerLiter) {

		ArrayList<String> fullPrice = new ArrayList<String>();
		double res = 0.0;
		switch(subscription) {
		
		case "Ocassionaly":
			res = price;
			break;
			
		case "regMonSubSinVeh":
			res = price - (0.04 * price);
			break;
			
		case "regMonSubSevVeh": 
			res = (price - (0.04 * price*listCars.size()))*0.9;
			break;
			
		case "fullMonSub":
			fullPrice.add("fuelingCalculate");
			fullPrice.add(IDField.getText());
			ClientUI.chat.client.handleMessageFromClientUI(fullPrice);
			res = (((ChatClient.fullMonSubPrice*pricePerLiter) - (0.04 * (ChatClient.fullMonSubPrice*pricePerLiter)*listCars.size()))*0.9)*0.97;
			break;
		}
		return res;
	}

	/**
	 * Complete payments sql controll.
	 *
	 * @param event the event
	 */
	@FXML
	void completePaymentsSqlControll(ActionEvent event) {// 316541549
		if (phoneNumCor.isVisible() && surnameCor.isVisible() && firstNameCor.isVisible()) {
			if (flag == false) {
				EndPrice.setText("Click OK button and than press this button again.");
				return;
			} else {
				acceptanceWindow.setVisible(true);
			}
		}
	}

	/**
	 * Check if client exist.
	 *
	 * @param event the event
	 */
	@FXML
	void checkIfClientExist(ActionEvent event) {
		String ID = IDField.getText();

		ArrayList<String> list = new ArrayList<String>();

		list.add("0");
		list.add(ID);

		if (!checkIfIDCorrect(ID)) {
			EndPrice.setText("Wrong ID number, please put correct number");
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error window");
			alert.setHeaderText("Attention!");
			alert.setContentText("Incorrect ID!!");
			alert.showAndWait();
		} else {
			ClientUI.chat.client.handleMessageFromClientUI(list);
			if (!ChatClient.c1.getFirstName().equals("Error")) {
				signV.setVisible(true);
				checkAgain.setVisible(true);
				chooseGas.setVisible(true);
				txtGasType.setVisible(true);
				red5.setVisible(true);
			} else {
				redXbutt.setVisible(true);
				noExistingWindow.setVisible(true);
			}
			IDField.setDisable(true);
		}
	}

	/**
	 * Check again btn.
	 *
	 * @param event the event
	 */
	@FXML
	void checkAgainBtn(ActionEvent event) {
		IDField.setDisable(false);
		signV.setVisible(false);
		redXbutt.setVisible(false);
		txtFullName.setVisible(false);
		FNfield.setVisible(false);
		txtPhoneNum.setVisible(false);
		PNfield.setVisible(false);
		txtSchedule.setVisible(false);
		DateField.setVisible(false);
		txtImmidiacy.setVisible(false);
		HighLevelBox.setVisible(false);
		TypeBox.setVisible(false);
		red1.setVisible(false);
		red2.setVisible(false);
		red3.setVisible(false);
		red4.setVisible(false);
		surnameField.setVisible(false);
		txtSurname.setVisible(false);
		checkClient.setVisible(true);
		checkAgain.setVisible(false);
		phoneNumCor.setVisible(false);
		surnameCor.setVisible(false);
		firstNameCor.setVisible(false);
		btnNAD.setVisible(false);
		OKBtn.setVisible(false);
		amount.setVisible(false);
		txtAmountGas.setVisible(false);
		btnComplete.setVisible(false);
		HighLevelBox.setSelected(false);
		TypeBox.setSelected(false);
		amount.clear();
		chooseGas.setVisible(false);
		txtGasType.setVisible(false);
		red5.setVisible(false);
		carNumberChoose.setVisible(false);// �����
		txtCarNum.setVisible(false);
		CVVField.clear();
		red6.setVisible(false);
	}

	/**
	 * Check if ID correct.
	 *
	 * @param ID the id
	 * @return true, if successful
	 */
	public boolean checkIfIDCorrect(String ID) {
		int sum = 0, id, arr[] = new int[9], arr2[] = { 1, 2, 1, 2, 1, 2, 1, 2, 1 }, cal;
		if (ID.length() != 9) {
			return false;
		}
		id = Integer.parseInt(ID);
		for (int i = 0; i < 9; i++) {
			arr[i] = id % 10;
			id /= 10;
		}

		for (int i = 0; i < 9; i++) {
			cal = (arr[i] * arr2[i]);
			if (cal > 9) {
				sum += cal % 10;
				cal /= 10;
				sum += cal;
			} else {
				sum += cal;
			}
		}

		if ((sum % 10) == 0)
			return true;
		else
			return false;
	}


	/** The YE sbtn. */
	@FXML
	private Button YESbtn;

	/** The N obtn. */
	@FXML
	private Button NObtn;

	/**
	 * Btn no.
	 *
	 * @param event the event
	 */
	@FXML
	void btnNo(ActionEvent event) {
		acceptanceWindow.setVisible(false);
		cashWindow.setVisible(true);

		ArrayList<String> list = new ArrayList<String>();
		@SuppressWarnings("unused")
		ArrayList<String> list2 = new ArrayList<String>();
		String forSum = null;
		boolean HL = false, NL = false;

		switch (chooseGas.getValue()) {

		case "Fuel 95":
			forSum = "Fuel_95";
			break;
		case "Soler":
			forSum = "Soler";
			break;

		case "Fuel mini bike":
			forSum = "Fuel_mini_bike";
			break;

		case "Fuel Home Heating":
			forSum = "Fuel_Home_Heating";
			break;

		default:
			break;
		}

		if (HighLevelBox.isSelected()) {
			HL = true;
			NL = false;
		} else if (TypeBox.isSelected()) {
			HL = false;
			NL = true;
		}
		double numOfAmount = Double.parseDouble(amount.getText());
		double calc = 0, deliveryPrice = 30;
		list2 = getGasPrice();
		double gasPricePerLiter;
		list.clear();
		list.add("4");
		list.add(forSum);
		ClientUI.chat.client.handleMessageFromClientUI(list);

		if (chooseGas.getValue().equals("Fuel Home Heating")) {
			gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
			ChatClient.ret.clear();
			if (HighLevelBox.isSelected()) {
				calc = numOfAmount * 4.79 + (numOfAmount * 0.02) + deliveryPrice;
			} else if (TypeBox.isSelected()) {
				if (numOfAmount < 600) {
					calc = numOfAmount * gasPricePerLiter + deliveryPrice;
				} else if (numOfAmount >= 600 && numOfAmount <= 800) {
					calc = numOfAmount * gasPricePerLiter - (numOfAmount * 0.03) + deliveryPrice;
				} else if (numOfAmount > 800) {
					calc = numOfAmount * gasPricePerLiter - (numOfAmount * 0.04) + deliveryPrice;
				}
			}
		} else {
			gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
			ChatClient.ret.clear();

			calc = numOfAmount * gasPricePerLiter + deliveryPrice;
		}
		list.clear();
		list.add("1");
		list.add(IDField.getText());
		list.add(firstNameCor.getText());
		list.add(surnameCor.getText());
		list.add(phoneNumCor.getText());
		list.add(DateField.getValue().toString());
		list.add(String.valueOf(HL));
		list.add(String.valueOf(NL));
		if(subs.equals("fullMonSub")) {
			list.add(String.valueOf(ChatClient.fullMonSubPrice));//amount
			list.add(String.valueOf(fullResCalc)); //price
		}
		else {
			list.add(amount.getText());
			list.add(String.valueOf(calc));
		}
		list.add(forSum);
		if (chooseGas.getValue().equals("Fuel Home Heating")) {
			list.add("No car");
		} else {
			list.add(carNumberChoose.getValue());
		}

		if (forSum.equals("Fuel_Home_Heating") && (!FNfield.getText().equals("") || !PNfield.getText().equals("")
				|| (!HighLevelBox.isSelected() && !TypeBox.isSelected()) || !amount.getText().equals(""))) {
			if (flag == false) {
				EndPrice.setText("Click OK button and than press this button again.");
				return;
			} else if (flag == true) {
				if (signV.isVisible()) {
					list.add("cash");
					ClientUI.chat.client.handleMessageFromClientUI(list);
					flag = false;

				}
			}

		} else if (!FNfield.getText().equals("") || !PNfield.getText().equals("") || !amount.getText().equals("")) {
			if (flag == false) {
				EndPrice.setText("Click OK button and than press this button again.");
				return;
			} else if (flag == true) {
				if (signV.isVisible()) {
					list.add("cash");
					ClientUI.chat.client.handleMessageFromClientUI(list);
					flag = false;
					EndPrice.setText("Thank you " + FNfield.getText() + "!\n"
							+ "Your order as been added\nPlease complete your payments.\n");

					acceptanceWindow.setVisible(true);

				}
			}
		}

		cashWindow.setVisible(false);
		IDField.setDisable(false);
		signV.setVisible(false);
		redXbutt.setVisible(false);
		txtFullName.setVisible(false);
		FNfield.setVisible(false);
		txtPhoneNum.setVisible(false);
		PNfield.setVisible(false);
		txtSchedule.setVisible(false);
		DateField.setVisible(false);
		txtImmidiacy.setVisible(false);
		HighLevelBox.setVisible(false);
		TypeBox.setVisible(false);
		red1.setVisible(false);
		red2.setVisible(false);
		red3.setVisible(false);
		red4.setVisible(false);
		surnameField.setVisible(false);
		txtSurname.setVisible(false);
		checkClient.setVisible(true);
		checkAgain.setVisible(false);
		phoneNumCor.setVisible(false);
		surnameCor.setVisible(false);
		firstNameCor.setVisible(false);
		btnNAD.setVisible(false);
		OKBtn.setVisible(false);
		amount.setVisible(false);
		txtAmountGas.setVisible(false);
		btnComplete.setVisible(false);
		HighLevelBox.setSelected(false);
		TypeBox.setSelected(false);
		amount.clear();
		chooseGas.setVisible(false);
		txtGasType.setVisible(false);
		red5.setVisible(false);
		IDField.clear();
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
		finishWindow.setVisible(true);
		acceptanceWindow.setVisible(false);
		
		list.clear();
		list.add("7");
		ClientUI.chat.client.handleMessageFromClientUI(list);
		orderNumtxt.setText(ChatClient.ret.get(1));
		IDFieldForTrack.setVisible(false);
		
		
		

	}

	/**
	 * Btn yes.
	 *
	 * @param event the event
	 */
	@FXML
	void btnYes(ActionEvent event) {
		acceptanceWindow.setVisible(false);
		ConfirmationCVVWindow.setVisible(true);
	}

	// Confrimation CVV number

	/** The Confirmation CVV window. */
	@FXML
	private AnchorPane ConfirmationCVVWindow;

	/** The btn OKCVV. */
	@FXML
	private Button btnOKCVV;

	/** The CVV field. */
	@FXML
	private TextField CVVField;

	/**
	 * Confirm CVV.
	 *
	 * @param event the event
	 */
	@FXML
	void confirmCVV(ActionEvent event) {
		ArrayList<String> list = new ArrayList<String>();
		String id = IDField.getText();
		@SuppressWarnings("unused")
		ArrayList<String> list2 = new ArrayList<String>();
		String forSum = null;
		boolean HL = false, NL = false;
		double discount;	
		list.clear();
		list.add("2");
		list.add(id);
		if (CVVField.getText().equals("")) {
			EndPrice.setText("Put CVV numbers inside the field.");
			list.clear();
			return;
		} else {
			list.add(CVVField.getText());
			list.add(chooseGas.getValue());
			if(subs.equals("fullMonSub")) 
				list.add(String.valueOf(fullResCalc)); //price
			else 
				list.add(amount.getText());

			switch (chooseGas.getValue()) {

			case "Fuel 95":
				list.add("Fuel_95");
				break;
			case "Soler":
				list.add("Soler");
				break;

			case "Fuel mini bike":
				list.add("Fuel_mini_bike");
				break;

			case "Fuel Home Heating":
				list.add("Fuel_Home_Heating");
				break;

			default:
				break;

			}
			ClientUI.chat.client.handleMessageFromClientUI(list);//send to decrease fuel
		}

		if (ChatClient.c1.getFirstName().equals("Error")) {
			EndPrice.setText("Wrong CVV number!");
		} else {
			switch (chooseGas.getValue()) {

			case "Fuel 95":
				forSum = "Fuel_95";
				break;
			case "Soler":
				forSum = "Soler";
				break;

			case "Fuel mini bike":
				forSum = "Fuel_mini_bike";
				break;

			case "Fuel Home Heating":
				forSum = "Fuel_Home_Heating";
				break;

			default:
				break;
			}

			if(checkDiscount(chooseGas.getValue())) {
				discount = this.dis/100;
			}else {
				discount = 0;
			}
			
			if (HighLevelBox.isSelected()) {
				HL = true;
				NL = false;
			} else if (TypeBox.isSelected()) {
				HL = false;
				NL = true;
			}
			double numOfAmount = Double.parseDouble(amount.getText());
			double calc = 0, deliveryPrice = 30;
			list2 = getGasPrice();
			double gasPricePerLiter;
			list.clear();
			list.add("4");
			list.add(forSum);
			ClientUI.chat.client.handleMessageFromClientUI(list);

			if (chooseGas.getValue().equals("Fuel Home Heating")) {
				gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
				ChatClient.ret.clear();
				if (HighLevelBox.isSelected()) {
					calc = (numOfAmount * gasPricePerLiter + (numOfAmount * gasPricePerLiter * 0.02)) - discount*(numOfAmount * gasPricePerLiter + (numOfAmount * gasPricePerLiter * 0.02)) + deliveryPrice;
				} else if (TypeBox.isSelected()) {
					if (numOfAmount < 600) {
						calc = (numOfAmount * gasPricePerLiter) - discount*(numOfAmount * gasPricePerLiter) + deliveryPrice;
					} else if (numOfAmount >= 600 && numOfAmount <= 800) {
						calc = (numOfAmount * gasPricePerLiter - (numOfAmount*gasPricePerLiter * 0.03)) - discount*(numOfAmount * gasPricePerLiter - (numOfAmount *gasPricePerLiter* 0.03)) + deliveryPrice;
					} else if (numOfAmount > 800) {
						calc = (numOfAmount * gasPricePerLiter - (numOfAmount * gasPricePerLiter * 0.04)) - discount*(numOfAmount * gasPricePerLiter - (numOfAmount*gasPricePerLiter * 0.04)) + deliveryPrice;
						
					}
				}
			} else {
				gasPricePerLiter = Double.parseDouble(ChatClient.ret.get(1));
				ChatClient.ret.clear();

				calc = (numOfAmount * gasPricePerLiter) - discount*(numOfAmount * gasPricePerLiter) + deliveryPrice;
			}
			
			list.clear();
			list.add("1");
			list.add(IDField.getText());
			list.add(firstNameCor.getText());
			list.add(surnameCor.getText());
			list.add(phoneNumCor.getText());
			list.add(DateField.getValue().toString());
			list.add(String.valueOf(HL));
			list.add(String.valueOf(NL));
			list.add(amount.getText());
			if(ChatClient.c1.getSubscription().equals("fullMonSub")) {
				list.add(String.valueOf(fullResCalc));
			}else{
				list.add(String.valueOf(calc));
			}
			
			list.add(forSum);
			if (chooseGas.getValue().equals("Fuel Home Heating")) {
				list.add("No car");
			} else {
				list.add(carNumberChoose.getValue());
			}

			if (forSum.equals("Fuel_Home_Heating") && (!FNfield.getText().equals("") || !PNfield.getText().equals("")
					|| (!HighLevelBox.isSelected() && !TypeBox.isSelected()) || !amount.getText().equals(""))) {
				if (flag == false) {
					EndPrice.setText("Click OK button and than press this button again.");
					return;
				} else if (flag == true) {
					if (signV.isVisible()) {
						list.add("card");
						ClientUI.chat.client.handleMessageFromClientUI(list);
						flag = false;

					}
				}

			} else if (!FNfield.getText().equals("") || !PNfield.getText().equals("") || !amount.getText().equals("")) {
				if (flag == false) {
					EndPrice.setText("Click OK button and than press this button again.");
					return;
				} else if (flag == true) {
					if (signV.isVisible()) {
						list.add("card");
						ClientUI.chat.client.handleMessageFromClientUI(list);
						flag = false;
						EndPrice.setText("Thank you " + FNfield.getText() + "!\n"
								+ "Your order as been added\nPlease complete your payments.\n");

						acceptanceWindow.setVisible(true);

					}
				}
			}

			ConfirmationCVVWindow.setVisible(false);
			CVVField.clear();
			cashWindow.setVisible(false);
			IDField.setDisable(false);
			signV.setVisible(false);
			redXbutt.setVisible(false);
			txtFullName.setVisible(false);
			FNfield.setVisible(false);
			txtPhoneNum.setVisible(false);
			PNfield.setVisible(false);
			txtSchedule.setVisible(false);
			DateField.setVisible(false);
			txtImmidiacy.setVisible(false);
			HighLevelBox.setVisible(false);
			TypeBox.setVisible(false);
			red1.setVisible(false);
			red2.setVisible(false);
			red3.setVisible(false);
			red4.setVisible(false);
			surnameField.setVisible(false);
			txtSurname.setVisible(false);
			checkClient.setVisible(true);
			checkAgain.setVisible(false);
			phoneNumCor.setVisible(false);
			surnameCor.setVisible(false);
			firstNameCor.setVisible(false);
			btnNAD.setVisible(false);
			OKBtn.setVisible(false);
			amount.setVisible(false);
			txtAmountGas.setVisible(false);
			btnComplete.setVisible(false);
			HighLevelBox.setSelected(false);
			TypeBox.setSelected(false);
			amount.clear();
			chooseGas.setVisible(false);
			txtGasType.setVisible(false);
			red5.setVisible(false);
			CVVField.clear();
			IDField.clear();
			HomeFuelingPage.setVisible(false);
			MainPage.setVisible(true);
			finishWindow.setVisible(true);
			acceptanceWindow.setVisible(false);
			list.clear();
			list.add("7");
			ClientUI.chat.client.handleMessageFromClientUI(list);
			orderNumtxt.setText(ChatClient.ret.get(1));
			IDFieldForTrack.setVisible(false);
		}

	}

	/** The cash window. */
	// Cash window
	@FXML
	private AnchorPane cashWindow;

	/** The btn ok 1. */
	@FXML
	private Button btnOk1;

	/**
	 * Btn ok cash.
	 *
	 * @param event the event
	 */
	@FXML
	void btnOkCash(ActionEvent event) {
		cashWindow.setVisible(false);
		IDField.setDisable(false);
		signV.setVisible(false);
		redXbutt.setVisible(false);
		txtFullName.setVisible(false);
		FNfield.setVisible(false);
		txtPhoneNum.setVisible(false);
		PNfield.setVisible(false);
		txtSchedule.setVisible(false);
		DateField.setVisible(false);
		txtImmidiacy.setVisible(false);
		HighLevelBox.setVisible(false);
		TypeBox.setVisible(false);
		red1.setVisible(false);
		red2.setVisible(false);
		red3.setVisible(false);
		red4.setVisible(false);
		surnameField.setVisible(false);
		txtSurname.setVisible(false);
		checkClient.setVisible(true);
		checkAgain.setVisible(false);
		phoneNumCor.setVisible(false);
		surnameCor.setVisible(false);
		firstNameCor.setVisible(false);
		btnNAD.setVisible(false);
		OKBtn.setVisible(false);
		amount.setVisible(false);
		txtAmountGas.setVisible(false);
		btnComplete.setVisible(false);
		HighLevelBox.setSelected(false);
		TypeBox.setSelected(false);
		amount.clear();
		chooseGas.setVisible(false);
		txtGasType.setVisible(false);
		red5.setVisible(false);
		CVVField.clear();
		IDField.clear();
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
	}

	// Finish window

	/** The finish window. */
	@FXML
	private AnchorPane finishWindow;

	/** The order numtxt. */
	@FXML
	private Text orderNumtxt;

	/** The btn F. */
	@FXML
	private Button btnF;

	/**
	 * Finish btn.
	 *
	 * @param event the event
	 */
	@FXML
	void finishBtn(ActionEvent event) {// �����
		finishWindow.setVisible(false);
		noExistingWindow.setVisible(false);
		HomeFuelingPage.setVisible(false);
		MainPage.setVisible(true);
		IDField.clear();
		IDField.setDisable(false);
		redXbutt.setVisible(false);
		chooseGas.setValue("Click to choose");
		IDField.setDisable(false);
		checkClient.setVisible(true);
	}

	/** The list. */
	ObservableList<String> list = FXCollections.observableArrayList("Fuel 95", "Soler", "Fuel mini bike",
			"Fuel Home Heating");

	/**
	 * Initialize.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		DateField.setValue(LocalDate.now());
		// Factory to create Cell of DatePicker
		Callback<DatePicker, DateCell> dayCellFactory = this.getDayCellFactory();
		DateField.setDayCellFactory(dayCellFactory);

		chooseGas.setValue("Click to choose");
		chooseGas.setItems(list);

	}


	/**
	 * Handle disconnect button.
	 *
	 * @param event the event
	 */
	public void handleDisconnectButton(ActionEvent event) {
		Platform.runLater(() -> {
        	Alert alert = new Alert(AlertType.CONFIRMATION);
        	alert.setTitle("Before You GO");
        	alert.setContentText("Are You Sure?");

        	Optional<ButtonType> result = alert.showAndWait();
        	if (result.get() == ButtonType.CANCEL){
        	    alert.close();  
        	}
        	else {
        		Login_Page_Boundary.handleSignOut("Client");		        	
        		((Node) (event.getSource())).getScene().getWindow().hide();  
        	}
        });	
	}
	
	/**
	 * Check discount.
	 *
	 * @param type the type
	 * @return true, if successful
	 */
	public boolean checkDiscount(String type) {
		ArrayList<Object> nl = new ArrayList<Object>();
		
		String t = returnGasType(type);

		
		nl.add("10");
		nl.add(t);
		ClientUI.chat.client.handleMessageFromClientUI(nl);
		
		if(!ChatClient.ret.get(0).equals("Error"))
		{
			this.dis = Double.parseDouble(ChatClient.ret.get(0));
			return true;
		}
		return false;
	}
	
	/**
	 * Return gas type.
	 *
	 * @param comboChoose the combo choose
	 * @return the string
	 */
	public String returnGasType(String comboChoose) {
		String forSum = null;
		switch (comboChoose) {

		case "Fuel 95":
			forSum = "Fuel_95";
			break;
		case "Soler":
			forSum = "Soler";
			break;

		case "Fuel mini bike":
			forSum = "Fuel_mini_bike";
			break;

		case "Fuel Home Heating":
			forSum = "Fuel_Home_Heating";
			break;

		default:
			break;
		}
		
		return forSum;
	}
	

}
