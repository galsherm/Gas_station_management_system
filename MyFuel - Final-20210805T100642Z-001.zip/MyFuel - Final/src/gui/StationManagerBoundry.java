package gui;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javax.mail.MessagingException;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import logic.NFC;
import sms.SMSSender;
import client.*;

/**
 * The Class StationManagerBoundry.
 */
public class StationManagerBoundry implements Initializable {

	/** The station manager user name. */
	public static String stationManagerUserName = "";
	
	/** The station manager. */
	public static Stage stationManager;
	
	/** The refuse. */
	@FXML
	private Button refuse = new Button();
	
	/** The exit. */
	boolean exit = false;
	
	/** The t 1. */
	Thread t1;
	
	/** The Check incoming btn. */
	@FXML
	private Button CheckIncomingBtn;
	
	/** The textfield. */
	@FXML
	private TextField textfield;
	
	/** The Check purchases btn. */
	@FXML
	private Button CheckPurchasesBtn;
	
	/** The Check inventory btn. */
	@FXML
	private Button CheckInventoryBtn;
	
	/** The succes update message. */
	@FXML
	private Text successupdatemessage;

	/** The Need for renwell inventory. */
	@FXML
	private AnchorPane NeedForRenwellInventory;
	
	/** The Show data page. */
	@FXML
	private AnchorPane ShowDataPage;
	
	/** The Quaterly reports. */
	@FXML
	private Button QuaterlyReports;

	/** The Update inventory. */
	@FXML
	private Button UpdateInventory;

	/** The Update threshold inventory page. */
	@FXML
	private AnchorPane UpdateThresHoldInventoryPage;

	/** The New inventory value. */
	@FXML
	private TextField NewInventoryValue;

	/** The Set new inventory btn. */
	@FXML
	private Button SetNewInventoryBtn;

	/** The Choose fuel type. */
	@FXML
	private ChoiceBox<String> ChooseFuelType;

	/** The Go back. */
	@FXML
	private Button GoBack;

	/** The Station manager main page. */
	@FXML
	private Button StationManagerMainPage;

	/** The Quaterly reports page. */
	@FXML
	private AnchorPane QuaterlyReportsPage;

	/** The Station manager main page 1. */
	@FXML
	private AnchorPane StationManagerMainPage1 = new AnchorPane();
	
	/** The Fuel supply by supplier. */
	@FXML
	private AnchorPane FuelSuppliyBySupplier = new AnchorPane();

	/** The Go back 1. */
	@FXML
	private Button GoBack1;

	/** The Incoming reports. */
	@FXML
	private Button IncomingReports;

	/** The Purchases reports. */
	@FXML
	private Button PurchasesReports;

	/** The Show data btn. */
	@FXML
	private Button ShowDataBtn;

	/** The Inventory reports. */
	@FXML
	private Button InventoryReports;

	/** The Path incoming file. */
	@FXML
	private Text PathIncomingFile;

	/** The Path purchases file. */
	@FXML
	private Text PathpurchasesFile;

	/** The Path inventory file. */
	@FXML
	private Text PathInventoryFile;
	
	/** The success update message 1. */
	@FXML
	private Text successupdatemessage1;

	/** The Send to network manager. */
	@FXML
	private Button SendToNetworkManager;

	/** The show data text area. */
	@FXML
	public TextArea showdataTextArea;

	/** The You must choose 3 files text. */
	@FXML
	private Text YouMustChoose3FilesText;
	
	/** The al.arratlist */
	public ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object

	/** The fuel type list. */
	ObservableList<String> fuelTypeList = FXCollections.observableArrayList("Fuel_95", "Soler", "Fuel_mini_bike",
			"Fuel_HomelHeating");// "fuelTypeList"!
	
	/** The fuel liter. */
	public String fuelLiter = null;
	
	/** The Fuel type. */
	public String FuelType = null;


	/**
	 * Press choose incoming file.
	 *
	 * @param event the event
	 */
	@FXML
	void PressChooseIncomingFile(ActionEvent event) {
		YouMustChoose3FilesText.setVisible(false);
		FileChooser fc = new FileChooser();
		File f = fc.showOpenDialog(null);
		if (f != null) {
			al.add(f.getAbsolutePath());
			PathIncomingFile.setText("Selected File:" + f.getAbsolutePath());
		}

	}

	/**
	 * Press choose purchases file.
	 *
	 * @param event the event
	 */
	@FXML
	void PressChoosePurchasesFile(ActionEvent event) {
		YouMustChoose3FilesText.setVisible(false);
		FileChooser fc = new FileChooser();
		File f = fc.showOpenDialog(null);
		if (f != null) {
			al.add(f.getAbsolutePath());
			PathpurchasesFile.setText("Selected File:" + f.getAbsolutePath());
		}
	}

	/**
	 * Press choose inventory file.
	 *
	 * @param event the event
	 */
	@FXML
	void PressChooseInventoryFile(ActionEvent event) {
		YouMustChoose3FilesText.setVisible(false);

		FileChooser fc = new FileChooser();
		File f = fc.showOpenDialog(null);
		if (f != null) {
			al.add(f.getAbsolutePath());
			PathInventoryFile.setText("Selected File:" + f.getAbsolutePath());
		}

	}

	/**
	 * Press send to network manager btn.
	 *
	 * @param event the event
	 * @throws InterruptedException the interrupted exception
	 */
	@FXML
	void PressSendToNetworkManagerBtn(ActionEvent event) throws InterruptedException {
		// check if the 2 array list are equal
		ArrayList<String> newList = removeDuplicates(al); /// create arraylist without duplicate
		Collections.sort(al);
		Collections.sort(newList);

		boolean isEqual = al.equals(newList); // Compare unequal lists example

		if ((al.size() < 3 || isEqual == false)) {// check if the files are not identical and the amount of files is
													// less form 3

			YouMustChoose3FilesText.setVisible(true);
			resetQaterlyReportsScreen();
			al.clear();
			newList.clear();
			return;
		}
		funcFiles(newList);/// make the file to seriazlible and send the to the server
		showmessage();
	}

	/**
	 * Initialize.
	 */
		@FXML
	public void initialize() {
		ChooseFuelType.setValue(fuelTypeList.get(0)); // first value set to the fisrt word in the ObservableList
		ChooseFuelType.setItems(fuelTypeList);

	}

	/**
	 * Press set new inventory.
	 *
	 * @param event the event
	 */
	@FXML
	void PressSetNewInventory(ActionEvent event) {
		successupdatemessage1.setVisible(false);

		FuelType = ChooseFuelType.getValue(); // get status of choiseBox ChooseFuelType

		String fuelLiter = NewInventoryValue.getText();
		NewInventoryValue.setText("");

		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object gal task4

		al.add("StationManager_InventoryThreshold");
		al.add(FuelType);
		al.add(fuelLiter);
		ClientUI.chat.client.handleMessageFromClientUI(al);
		try {
			showmessage1();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}



	/**
 * Press check purchases.
 *
 * @param event the event
 */
@FXML
	void pressCheckPurchases(ActionEvent event) {

		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object gal
		al.add("StationManager_ShowData_CheckPurchases");

		ClientUI.chat.client.handleMessageFromClientUI(al);
		showPurchases();
	}

	/**
	 * Press check inventory.
	 *
	 * @param event the event
	 */
	@FXML
	void PressCheckInventory(ActionEvent event) {
		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object gal
		al.add("StationManager_ShowData_CheckInventory");
		ClientUI.chat.client.handleMessageFromClientUI(al);
		showInventory();

	}

	/**
	 * Press check incoming.
	 *
	 * @param event the event
	 */
	@FXML
	void presscheckIncoming(ActionEvent event) {
		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object gal
		al.add("StationManager_ShowData_checkIncoming");
		ClientUI.chat.client.handleMessageFromClientUI(al);
		showIncoming();
	}

	////////

	/**
	 * Press station manager main page.
	 *
	 * @param event the event
	 */
	@FXML
	void PressStationManagerMainPage(ActionEvent event) {/// go back to main menu
		StationManagerMainPage1.setVisible(true);
		UpdateThresHoldInventoryPage.setVisible(false);
		QuaterlyReportsPage.setVisible(false);
		ShowDataPage.setVisible(false);
		YouMustChoose3FilesText.setVisible(false);
		successupdatemessage.setVisible(false);
		resetQaterlyReportsScreen();
		FuelSuppliyBySupplier.setVisible(false);
		showdataTextArea.clear();
	}

	/**
	 * Press update inventory.
	 *
	 * @param event the event
	 */
	@FXML
	void PressUpdateInventory(ActionEvent event) {
		StationManagerMainPage1.setVisible(false);
		UpdateThresHoldInventoryPage.setVisible(true);
		QuaterlyReportsPage.setVisible(false);
		ShowDataPage.setVisible(false);
		successupdatemessage1.setVisible(false);

		initialize();

	}
	
	

	/**
	 * Press create quaterly reports.
	 *
	 * @param event the event
	 */
	@FXML
	void PressCreateQuaterlyReports(ActionEvent event) {
		StationManagerMainPage1.setVisible(false);
		UpdateThresHoldInventoryPage.setVisible(true);
		QuaterlyReportsPage.setVisible(true);
		ShowDataPage.setVisible(false);
	}

	/**
	 * Press show data btn.
	 *
	 * @param event the event
	 */
	@FXML
	void PressShowDataBtn(ActionEvent event) {/// 6.6.20
		StationManagerMainPage1.setVisible(false);
		UpdateThresHoldInventoryPage.setVisible(false);
		QuaterlyReportsPage.setVisible(false);
		ShowDataPage.setVisible(true);

	}

	/**
	 * Initialize.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		StationManagerMainPage1.setVisible(true);
		UpdateThresHoldInventoryPage.setVisible(false);
		QuaterlyReportsPage.setVisible(false);
		ShowDataPage.setVisible(false);
		successupdatemessage.setVisible(false);
		
		
		t1 = new Thread(new Runnable() {
		ArrayList<String> renewal = new ArrayList<String>();
		  
		
			@Override
			public void run() {

					while(!exit){
					try {
						Thread.sleep(10000);
						checkRenewal();	
						checkSupplied();
						exit = true;
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
									
				}
			}
			
			
			
			
			
			private void checkSupplied() {
				renewal.clear();
				renewal.add("Check Supplied");
				ClientUI.chat.client.handleMessageFromClientUI(renewal);
				if(ChatClient.supplied == true) {
					exit = true;
					Platform.runLater(()->{	
						Alert alert = new Alert(AlertType.WARNING, "Inventory Supplied" + "\n", ButtonType.OK, ButtonType.NO,

								ButtonType.CANCEL);
						alert.setTitle("Supplier Message");
						alert.setHeaderText("All Inventory has been supplied");
						alert.showAndWait();
					
				});
			}
			}
			
			private void checkRenewal() {
				renewal.clear();
				renewal.add("Check Renewal");
				ClientUI.chat.client.handleMessageFromClientUI(renewal);
				if(ChatClient.renwall.toString().equals("")) {
					return;
					
				}
				else
				{
					Platform.runLater(()->{
						if(ChatClient.renwall.toString().equals(""))
							return;
						Alert alert = new Alert(AlertType.WARNING, ChatClient.renwall.toString() + "\n", ButtonType.OK, ButtonType.NO,

								ButtonType.CANCEL);
						alert.setTitle("Need for renwell Inventory");
						alert.setHeaderText("Do you approve??");
						Optional<ButtonType> result = alert.showAndWait();

						if (result.get() == ButtonType.OK) {
							al.clear();
							al.add("Send To Supplier");
							al.add("Yes");
							ChatClient.renwall.clear();;
							ClientUI.chat.client.handleMessageFromClientUI(al);
							exit = true;
						}
						if (result.get() == ButtonType.NO) {
							al.clear();
							al.add("Send To Supplier");
							al.add("no");
							ClientUI.chat.client.handleMessageFromClientUI(al);


						}

					});
				}
			}
			
		});	
		
		if(!exit)
			t1.start();
	}
	
	
	

	/**
	 * Reset qaterly reports screen.
	 */
	public void resetQaterlyReportsScreen() {
		PathIncomingFile.setText("");
		PathInventoryFile.setText("");
		PathpurchasesFile.setText("");
		successupdatemessage.setVisible(false);
	}

	/**
	 * Removes the duplicates.
	 *
	 * @param <T> the generic type
	 * @param list the list
	 * @return the array list
	 */
	public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list) {

		// Create a new ArrayList
		ArrayList<T> newList = new ArrayList<T>();

		// Traverse through the first list
		for (T element : list) {

			// If this element is not present in newList
			// then add it
			if (!newList.contains(element)) {

				newList.add(element);
			}
		}

		// return the new list
		return newList;
	}

	/**
	 * Func files.
	 *
	 * @param newList the new list
	 */
	////
	public static void funcFiles(ArrayList<String> newList) {//the files should locate in c directly
		int numOfFiles=3;
		String[] fileName=new String[numOfFiles];
		String[] LocalfilePath=new String[numOfFiles];
		byte[][] mybytearray = new byte[numOfFiles][];  // This is idiomatic Java //this help to creates an array of arrays.		
		FileInputStream[] fis=new FileInputStream[numOfFiles];
		BufferedInputStream[] bis=new BufferedInputStream[numOfFiles];

		
		for(int i=0;i<numOfFiles;i++) {
			fileName[i] = newList.get(i).replace("C:\\", "");
			LocalfilePath[i]=newList.get(i);	

		}
	
		MyFile[] msg=new MyFile[numOfFiles];
		File[] newFile=new File[numOfFiles];
		
		for(int i=0;i<numOfFiles;i++) {
			msg[i] = new MyFile(LocalfilePath[i]);
			newFile[i]=new File(LocalfilePath[i]);
		}
		


		try {
			for(int i=0;i<numOfFiles;i++) {

				mybytearray[i]=new byte[(int) newFile[i].length()];
				fis[i] = new FileInputStream(newFile[i]);
			}
			for(int i=0;i<numOfFiles;i++) {

				 bis[i] = new BufferedInputStream(fis[i]);
				 msg[i].initArray(mybytearray[i].length);
				msg[i].setSize(mybytearray[i].length);
				bis[i].read(msg[i].getMybytearray(), 0, mybytearray[i].length);


			}
			ArrayList<MyFile> Bytearrays = new ArrayList<MyFile>();
			for(int i=0;i<numOfFiles;i++) {
				Bytearrays.add(msg[i]);
							

			}
			
			ClientUI.chat.client.handleMessageFromClientUI(Bytearrays);

		} catch (Exception e) {
		}

	}
	

	/**
	 * Mouse click choose fuel type.
	 *
	 * @param event the event
	 */
	@FXML
	void mouseclickchooseDuelType(MouseEvent event) {
		successupdatemessage1.setVisible(false);

	}


	/**
 * Show inventory.
 */
public void showInventory() {

		showdataTextArea.setText(fuelTypeList.get(0) + ":  " + ChatClient.msgg.get(0) + "\n" + fuelTypeList.get(1)
				+ ": " + ChatClient.msgg.get(1) + "\n" + fuelTypeList.get(2) + ": " + ChatClient.msgg.get(2) + "\n"
				+ fuelTypeList.get(3) + " :" + ChatClient.msgg.get(3));
		ChatClient.msgg.clear();

	}

	/**
	 * Show purchases.
	 */
	public void showPurchases() {
		showdataTextArea.setText(ChatClient.msgg.get(1) + "\n" + ChatClient.msgg.get(2) + "\n" + ChatClient.msgg.get(3)
				+ "\n" + ChatClient.msgg.get(4));

		ChatClient.msgg.clear();


	}

	/**
	 * Show incoming.
	 */
	public void showIncoming() {
		showdataTextArea.setText(ChatClient.msgg.get(1) + "\n" + ChatClient.msgg.get(2) + "\n" + ChatClient.msgg.get(3)
				+ "\n" + ChatClient.msgg.get(4) + "\n\n" + ChatClient.msgg.get(5));
		ChatClient.msgg.clear();


	}

	/**
	 * Show message.
	 *
	 * @throws InterruptedException the interrupted exception
	 */
	public void showmessage() throws InterruptedException {
		successupdatemessage.setVisible(true);
	}

	/**
	 * Show message 1.
	 *
	 * @throws InterruptedException the interrupted exception
	 */
	public void showmessage1() throws InterruptedException {
		successupdatemessage1.setVisible(true);
		successupdatemessage1.setText(ChatClient.msgg.get(0));
		ChatClient.msgg.clear();

	}
	
	/**
	 * Handle disconnect button.
	 *
	 * @param event the event
	 */
	public void handleDisconnectButton(ActionEvent event) {
		exit = true;
		Platform.runLater(() -> {
        	Alert alert = new Alert(AlertType.CONFIRMATION);
        	alert.setTitle("Before You GO");
        	alert.setContentText("Are You Sure?");

        	Optional<ButtonType> result = alert.showAndWait();
        	if (result.get() == ButtonType.CANCEL){
        	    alert.close();  
        	}
        	else {
        		Login_Page_Boundary.handleSignOut("Station Manager");		        	
        		((Node) (event.getSource())).getScene().getWindow().hide();  
        	}
        });	
}

}
