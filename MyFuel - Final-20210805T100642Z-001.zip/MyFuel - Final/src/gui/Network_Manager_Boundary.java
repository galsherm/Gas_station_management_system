package gui;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import entities.GasType;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

/**
 * The Class Network_Manager_Boundary that implements Initializable.
 */
public class Network_Manager_Boundary implements Initializable{
	
	/** One show of gas. */
	GasType gas = new GasType(null, null, null, null);
	
	/** The network manager user name. */
	public static String networkManagerUserName;
	
	/** The res. */
	ArrayList<String> res = new ArrayList<String>();
    
    /** The Apane. */
    @FXML
    private AnchorPane Apane;
    
    /** The Menu apane. */
    @FXML
    private AnchorPane MenuApane;

    /** The Disconnect 1. */
    @FXML
    private Button Disconnect1;
    
    /** The Disconnect 11. */
    @FXML
    private Button Disconnect11;
    
    /** The Disconnect 12. */
    @FXML
    private Button Disconnect12;
    
    /** The Menu rate confirmation. */
    @FXML
    private Button MenuRateConfirmation;

    /** The Menu reports. */
    @FXML
    private Button MenuReports;

    /** The Administrator menu 3. */
    @FXML
    private Button AdministratorMenu3;

    /** The reports apane. */
    @FXML
    private AnchorPane reportsApane;

    /** The Menu rate confirmation 1. */
    @FXML
    private Button MenuRateConfirmation1;

    /** The Menu reports 1. */
    @FXML
    private Button MenuReports1;

    /** The Reports. */
    @FXML
    private Button Reports;

    /** The Administrator menu 32. */
    @FXML
    private Button AdministratorMenu32;

    /** The quarterly revenue report. */
    @FXML
    private Button quarterlyRevenueReport;

    /** The al. */
    public ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object

    
    /** The Rate confirmation apane. */
    @FXML
    private AnchorPane RateConfirmationApane;

    /** The Administrator menu 31. */
    @FXML
    private Button AdministratorMenu31;

    /** The Rate confirmation. */
    @FXML
    private Button RateConfirmation;

    /** The back 1. */
    @FXML
    private Button back1;
    
    /** The back. */
    @FXML
    private Button back;

    /** The Approve. */
    @FXML
    private Button Approve;

    /** The Dont approve. */
    @FXML
    private Button DontApprove;
    
    /** The Rate text. */
    @FXML
    private TextArea RateText;
    
    /** The Rate text 1. */
    @FXML
    private TextArea RateText1;

    /** The Rate text 2. */
    @FXML
    private TextArea RateText2;

    /** The Rate text 3. */
    @FXML
    private TextArea RateText3;
    
    /** The Approve 1. */
    @FXML
    private Button Approve1;

    /** The Dont approve 1. */
    @FXML
    private Button DontApprove1;

    /** The Approve 2. */
    @FXML
    private Button Approve2;

    /** The Dont approve 2. */
    @FXML
    private Button DontApprove2;
    
    /** The Approve 3. */
    @FXML
    private Button Approve3;

    /** The Dont approve 3. */
    @FXML
    private Button DontApprove3;
    
    /** The textreport 1. */
    @FXML
    private Text textreport1;


    /**
     * Administrator menu function 3.
     *
     * @param event the event
     */
    @FXML
    void AdministratorMenuFunction3(ActionEvent event) {
    	reportsApane.setVisible(false);
    	RateConfirmationApane.setVisible(false);
    	}

    /**
     * Approve the price function.
     *
     * @param event the event
     */
    @FXML
    void ApproveFunction(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_fuel95_update1");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Approve the price function 1.
     *
     * @param event the event
     */
    @FXML
    void ApproveFunction1(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_mini_bike_update1");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Approve the price function 2.
     *
     * @param event the event
     */
    @FXML
    void ApproveFunction2(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_soler_update1");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Approve the price function 3.
     *
     * @param event the event
     */
    @FXML
    void ApproveFunction3(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_home_heating_update1");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Dont approve the price function.
     *
     * @param event the event
     */
    @FXML
    void DontApproveFunction(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_fuel95_update0");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Dont approve the price function 1.
     *
     * @param event the event
     */
    @FXML
    void DontApproveFunction1(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_homeheating_update0");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    	
    }

    /**
     * Dont approve the price function 2.
     *
     * @param event the event
     */
    @FXML
    void DontApproveFunction2(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_soler_update0");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Dont approve the price function 3.
     *
     * @param event the event
     */
    @FXML
    void DontApproveFunction3(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_mini_bike_update0");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }

    /**
     * Menu rate confirmation function.
     *
     * @param event the event
     */
    @FXML
    void MenuRateConfirmationFunction(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    	res.add("Check New Price");
    	ClientUI.chat.client.handleMessageFromClientUI(res);
    	if(ChatClient.msgg.get(1).equals("0.0")) {
        	ChatClient.msgg.remove(0);
        	ChatClient.msgg.remove(0);
    	}
    	else {
    		RateText.setText(ChatClient.msgg.get(0) + ": " + ChatClient.msgg.get(1));
    		ChatClient.msgg.remove(0);
    		ChatClient.msgg.remove(0);
    	}
    	if(ChatClient.msgg.get(1).equals("0.0")) {
        	ChatClient.msgg.remove(0);
        	ChatClient.msgg.remove(0);
    	}
    	else {
    		RateText1.setText(ChatClient.msgg.get(0) + ": " + ChatClient.msgg.get(1));
    		ChatClient.msgg.remove(0);
    		ChatClient.msgg.remove(0);
    	}
    	if(ChatClient.msgg.get(1).equals("0.0")) {
        	ChatClient.msgg.remove(0);
        	ChatClient.msgg.remove(0);
    	}
    	else {
    		RateText2.setText(ChatClient.msgg.get(0) + ": " + ChatClient.msgg.get(1));
    		ChatClient.msgg.remove(0);
    		ChatClient.msgg.remove(0);
    	}
    	if(ChatClient.msgg.get(1).equals("0.0")) {
        	ChatClient.msgg.remove(0);
        	ChatClient.msgg.remove(0);
    	}
    	else {
    		RateText3.setText(ChatClient.msgg.get(0) + ": " + ChatClient.msgg.get(1));
    		ChatClient.msgg.remove(0);
    		ChatClient.msgg.remove(0);
    	}
   	
    }

    /**
     * Menu reports function.
     *
     * @param event the event
     */
    @FXML
    void MenuReportsFunction(ActionEvent event) {
    	reportsApane.setVisible(true);
    	RateConfirmationApane.setVisible(false);
    }


    /**
     * Rate confirmation function.
     *
     * @param event the event
     */
    @FXML
    void RateConfirmationFunction(ActionEvent event) {
    	RateConfirmationApane.setVisible(true);
    }

    /**
     * Reports function.
     *
     * @param event the event
     */
    @FXML
    void ReportsFunction(ActionEvent event) {
    	reportsApane.setVisible(true);
    }

    /**
     * Quarterly revenue function.
     *
     * @param event the event
     */
    @FXML
    void quarterlyRevenueFunction(ActionEvent event) {
    	ArrayList <String> al = new ArrayList<String>();
    	al.add("AdministorMenuPage_Incaming_Report");
    	ClientUI.chat.client.handleMessageFromClientUI(al);
    }
    
    /**
     * Back function.
     *
     * @param event the event
     */
    @FXML
    void BackFunction(ActionEvent event) {
    	reportsApane.setVisible(false);
    	RateConfirmationApane.setVisible(false);
    }

	/**
	 * Handle disconnect button.
	 *
	 * @param event the event
	 */
	public void handleDisconnectButton(ActionEvent event) {		
		Platform.runLater(() -> {
        	Alert alert = new Alert(AlertType.CONFIRMATION);
        	alert.setTitle("Before You GO");
        	alert.setContentText("Are You Sure?");

        	Optional<ButtonType> result = alert.showAndWait();
        	if (result.get() == ButtonType.CANCEL){
        	    alert.close();  
        	}
        	else {
        		Login_Page_Boundary.handleSignOut("Network Manager");		        	
        		((Node) (event.getSource())).getScene().getWindow().hide();  
        	}
        });	
}

	/**
	 * Initialize.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	reportsApane.setVisible(false);
    	RateConfirmationApane.setVisible(false);
    	
	}

	/**
	 * Func files that open files and creates a directory.
	 *
	 * @param newList the new list
	 * @return the boolean
	 */
	public static Boolean funcFiles(ArrayList<MyFile> newList) {
		
		int numOfFiles = 3;
		String Filestype = "docx";
		File directory = new File("C:\\NoyFilesReports");/// create directory if not exist in E!!
		if (!directory.exists()) {
			directory.mkdir();

		}

		String[] LocalfilePath = { directory + "\\IncomingReportNoy." + Filestype,
				directory + "\\PurchaseReportNoy." + Filestype, directory + "\\InventoryReportNoy." + Filestype };/// file
																											/// that
																											/// save
																											/// in
																											/// the
																											/// server
		byte[][] mybytearray = new byte[numOfFiles][]; // This is idiomatic Java //this help to creates an
														// array of arrays.
		FileOutputStream[] fos = new FileOutputStream[numOfFiles];
		BufferedOutputStream[] bos = new BufferedOutputStream[numOfFiles];
		File[] newFile = new File[numOfFiles];
		int[] filesize = new int[numOfFiles];

		for (int i = 0; i < numOfFiles; i++) {

			newFile[i] = new File(LocalfilePath[i]);
		}
		try {
			for (int i = 0; i < numOfFiles; i++) {
				mybytearray[i] = new byte[(int) newFile[i].length()];

				fos[i] = new FileOutputStream(newFile[i]);
				bos[i] = new BufferedOutputStream(fos[i]);
				filesize[i] = newList.get(i).getSize();
			}
			try {
				for (int i = 0; i < numOfFiles; i++) {

					bos[i].write(newList.get(i).getMybytearray(), 0, filesize[i]);
				}
			} catch (IOException e) {
				
				e.printStackTrace();
				return false;
			}

		} catch (IOException e) {
			return false;
		}
		try {
			for (int i = 0; i < numOfFiles; i++) {

				bos[i].flush();
				bos[i].close();
			}
		} catch (IOException e) {
			return false;
		}

		try {
			for (int i = 0; i < numOfFiles; i++) {

				fos[i].flush();
			}
		} catch (IOException e) {
			return false;
		}
		return true;
	}
	

}
