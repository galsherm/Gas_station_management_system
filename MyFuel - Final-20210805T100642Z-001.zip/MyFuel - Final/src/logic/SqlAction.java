package logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Arrays;

import entities.GasType;
import entities.Employees;

/**
 * The Class SqlAction is responsible for the connection with the server and calculation functions..
 */
public class SqlAction {

	/** The total. */
	public static double total;

	/**
	 * Adds the new client to the table.
	 *
	 * @param client the client
	 * @param con the connection with the driver.
	 */
	public void addNewClient(List<Object> client, Connection con) {
		// function to add new client!
		try {
			String query = "INSERT INTO employees (ID,firstName,surName,userName,password,role,email,isConnected,phoneNumber,creditCardNum,creditCardCVV,creditCardExpirationDate,numOfCars,purchasePlan)"
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, (String) client.get(0));
			ps.setString(2, (String) client.get(1));
			ps.setString(3, (String) client.get(2));
			ps.setString(4, (String) client.get(3));
			ps.setString(5, (String) client.get(4));
			ps.setString(6, (String) client.get(5));
			ps.setString(7, (String) client.get(6));
			ps.setBoolean(8, (Boolean) client.get(7));
			ps.setString(9, (String) client.get(8));
			ps.setString(10, (String) client.get(9));
			ps.setString(11, (String) client.get(10));
			ps.setString(12, (String) client.get(11));
			ps.setString(13, (String) client.get(12));
			ps.setString(14, "No Plan");
			ps.execute();
			ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Gets the employees details, shows the employees details from the table.
	 *
	 * @param con the connection with the driver.
	 * @return the employees details
	 */
	public Employees[] getEmployeesDetails(Connection con) {

		Employees emp[] = null;
		Statement stmt;
		int size = 0;
		try {

			String query = "SELECT count(*) FROM employees";
			stmt = con.prepareStatement(query);
			ResultSet rs1 = stmt.executeQuery(query);
			rs1.next();
			size = rs1.getInt(1);
			emp = new Employees[size];
		} catch (SQLException e) {
			e.printStackTrace();
		}
		;
		try {
			stmt = con.createStatement();
			int i = 0;
			ResultSet rs = stmt.executeQuery("SELECT * FROM employees;");
			while (rs.next()) {
				emp[i] = new Employees(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getBoolean(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14));
				i++;
			}
			rs.close();
			return emp; // return all employees table
		} catch (SQLException e) {
			e.printStackTrace();
			return null;

		}
	}

	/**
	 * Sets the employee connection true.
	 *
	 * @param emp the emp
	 * @param con the connection with the server.
	 * @throws SQLException the SQL exception
	 */
	public void setEmployeeConnectionTrue(Employees emp, Connection con) throws SQLException {

		try {
			PreparedStatement ps = con.prepareStatement("UPDATE employees SET isConnected = ? WHERE userName = ?");

			ps.setBoolean(1, true);
			ps.setString(2, emp.getUsername());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException se) {
			throw se;
		}
	}

	/**
	 * Sets the employee connection false.
	 *
	 * @param emp the emp
	 * @param con the connection with the server.
	 * @throws SQLException the SQL exception
	 */
	public void setEmployeeConnectionFalse(Employees emp, Connection con) throws SQLException {

		try {
			PreparedStatement ps = con.prepareStatement("UPDATE employees SET isConnected = ? WHERE userName = ?");

			ps.setBoolean(1, false);
			ps.setString(2, emp.getUsername());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException se) {
			throw se;
		}
	}

	/**
	 * Checks if is connected.
	 *
	 * @param userName the emploee that we want to see user name.
	 * @param con the connection with the server.
	 * @return true, if is connected
	 * @throws SQLException the SQL exception
	 */
	public boolean isConnected(String userName, Connection con) throws SQLException {
		
		PreparedStatement ps = con.prepareStatement("SELECT * FROM employees WHERE userName = ?;");
		ps.setString(1, userName);
		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) {
			if(rs.getBoolean(8))
				return true;
		}
		rs.close();
		return false; // return all employees table
	}
	
	/**
	 * Sets the new car in the vehicles table.
	 *
	 * @param list the list
	 * @param con the connection with the server.
	 */
	public void setNewCar(List<Object> list, Connection con) {
		PreparedStatement ps = null;
		String ID = (String) list.get(0);
		list.remove(0);
		while(!list.isEmpty()) {
		String query = "INSERT INTO vehicles (vehicleNumber,clientId)" + "VALUES (?,?);";		
		try {
			ps = con.prepareStatement(query);
			ps.setString(1, (String) list.get(0));
			ps.setString(2, ID);
			list.remove(0);
			ps.execute();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		}

	}

	/**
	 * Sets the new purchase plan in the table.
	 *
	 * @param list the list
	 * @param con the connection with the server.
	 */
	public void setPurchasePlan(List<Object> list, Connection con) {
		String query = "UPDATE employees SET purchasePlan = ? WHERE ID = ?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);
			switch ((String) list.get(1)) {
			case "Ocassionaly Client":
				ps.setString(1, "Ocassionaly");
				break;
			case "Regular Monthly Subscription Single Vehicle":
				ps.setString(1, "regMonSubSinVeh");
				break;
			case "Regular Monthly Subscription Several Vehicle":
				ps.setString(1, "regMonSubSevVeh");
				break;
			case "Full Monthly Subscription Single Vehicle":
				ps.setString(1, "fullMonSub");
				break;
			}
			ps.setString(2, (String) list.get(0));
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.out.println("ERROR");
			e.printStackTrace();
		}
	}

	/**
	 * Verify client id,checks if the client already exist.
	 *
	 * @param list the list
	 * @param con the connection to the server.
	 * @return true, if already exist else, false.
	 */
	public boolean verifyClientId(List<Object> list, Connection con) {

		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM employees;");
			while (rs.next()) {
				if (list.get(0).equals(rs.getString(1)))
					return true;
			}
			rs.close();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}
	
	/**
	 * Creates the new order.
	 *
	 * @param con the connection with the server.
	 * @param orderNum the number of the order.
	 * @param ID the id
	 * @param CName the client name
	 * @param Csurname the client last name
	 * @param PhoneNum the client phone number
	 * @param ODate the order date
	 * @param highLevel the high level
	 * @param normalLevel the normal level
	 * @param amount the amount
	 * @param orderSum the order sum
	 * @param fourNum the four num
	 * @param gasType the gas type
	 * @param carNum the vehicle number
	 */
	public void createNewOrder(Connection con, int orderNum, String ID, String CName, String Csurname, String PhoneNum,
			String ODate, boolean highLevel, boolean normalLevel, int amount, double orderSum, String fourNum,
			String gasType, String carNum) {
		Statement stmt;
		ArrayList<String> list = new ArrayList<>();
		list.add(Integer.toString(orderNum));
		list.add(ID);
		list.add(CName);
		list.add(Csurname);
		list.add(PhoneNum);
		list.add(ODate);
		list.add(Boolean.toString(highLevel));
		list.add(Boolean.toString(normalLevel));
		list.add(Integer.toString(amount));
		list.add(Double.toString(orderSum));
		list.add(fourNum);
		list.add(LocalTime.now().toString().substring(0, 5));
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(
					"INSERT INTO clientOrder(orderNum,ID,CName,PhoneNum,ODate,highLevel,normalLevel,amountOfGas,orderPrice,fourNumCreditCard,gasType,timeOrder,carNum) "// change
							+ "VALUES (" + orderNum + ",'" + ID + "','" + CName + " " + Csurname + "','" + PhoneNum
							+ "','" + ODate + "'," + highLevel + "," + normalLevel + "," + amount + "," + orderSum
							+ ",'" + fourNum + "','" + gasType + "','" + list.get(11) + "','" + carNum + "')");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gets the percentage.
	 *
	 * @param Type the type purchase.
	 * @param con the connection to the server.
	 * @return the percentage of discount
	 */
	public double getPercentage(String Type,Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT Percent FROM discount WHERE gasname = '" + Type + "';");
			rs.next();
			if(rs.getDouble(1) != 0)
				return rs.getDouble(1);
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}

	/**
	 * Check if client exists.
	 *
	 * @param ID the id of the employee we search for.
	 * @param con the connection with the server.
	 * @return true, if he does else, false.
	 */
	public boolean checkIfClientExists(String ID, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID FROM employees;");
			while (rs.next()) {
				if (ID.equals(rs.getString(1)))
					return true;
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Take the credit card numbers.
	 *
	 * @param ID the id of the employee we search for
	 * @param con the connection with the server.
	 * @return the id string
	 */
	public String take4CreditCardNum(String ID, Connection con) {
		Statement stmt;
		int length;
		String ret = "Error";
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID,creditCardNum FROM employees;");
			while (rs.next()) {
				if (ID.equals(rs.getString(1))) {
					length = rs.getString(2).length();
					return rs.getString(2).substring(length - 4);
				}
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * this functuin Confirmed CVV check.
	 *
	 * @param list the list
	 * @param con the connection with the server.
	 * @return true, if confirmed, else false.
	 */
	public boolean confirmationCVVCheck(Object list, Connection con) {
		Statement stmt;
		@SuppressWarnings("unchecked")
		ArrayList<String> list2 = (ArrayList<String>) list;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID,creditCardCVV FROM employees;");
			while (rs.next()) {
				if (list2.get(1).equals(rs.getString(1))) {
					if (list2.get(2).equals(rs.getString(2))) {
						return true;
					}

				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Delete the last order from the table.
	 *
	 * @param con the connection with the server.
	 */
	public void deleteLastOrder(Connection con) {
		int lastOrder = checkLastQuery(con) - 1;
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate("DELETE FROM clientorder WHERE orderNum = " + Integer.toString(lastOrder));

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Check what is the last order from the table.
	 *
	 * @param con the connection with the server.
	 * @return the int
	 */
	public int checkLastQuery(Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT orderNum FROM clientOrder ORDER BY orderNum DESC LIMIT 1;");
			if (rs.next() == false)
				return 1;
			else
				return Integer.parseInt(rs.getString(1)) + 1;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 1;
	}

	/**
	 * Gets the first name of the employee we want.
	 *
	 * @param ID the id of the employee w want
	 * @param con the connection with the server
	 * @return the first name of the employee.
	 */
	public String getFirstName(String ID, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT firstName FROM employees WHERE ID = '" + ID + "'");
			rs.next();
			return rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Gets the last name of the employee we want.
	 *
	 * @param ID the id of the employee.
	 * @param con the connection with the server.
	 * @return the last name of the employee.
	 */
	public String getSurname(String ID, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT surName FROM employees WHERE ID = '" + ID + "'");
			rs.next();
			return rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Gets the phone number of employee from the table.
	 *
	 * @param ID the id of the employee.
	 * @param con the connection with the server.
	 * @return the phone number of the employee.
	 */
	public String getPhoneNum(String ID, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT phoneNumber FROM employees WHERE ID = '" + ID + "'");
			rs.next();
			return rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Gets the suscription of the employee.
	 *
	 * @param ID the id of the employee
	 * @param con the connection to the server
	 * @return the suscription
	 */
	public String getSuscription(String ID, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT purchasePlan FROM employees WHERE ID = '" + ID + "'");
			rs.next();
			return rs.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Check the inventory.
	 *
	 * @param Type the type of fuel
	 * @param con the connection to the server
	 * @return the double amount
	 */
	public double checkInventory(String Type, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT " + Type + " FROM fuelinventory");
			rs.next();
			return Double.parseDouble(rs.getString(1));

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	/**
	 * Decrease fuel amount.
	 *
	 * @param list the list
	 * @param con the connection to the server
	 */
	public void decreaseFuel(Object list, Connection con) {
		@SuppressWarnings("unchecked")
		ArrayList<String> sqlStrings = (ArrayList<String>) list;
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate("UPDATE fuelinventory SET " + sqlStrings.get(5) + " = " + sqlStrings.get(5) + " - "
					+ Double.parseDouble(sqlStrings.get(4)));// update fuelinventory set Soler = Soler - 200
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Gets the gas price from the table.
	 *
	 * @param list the list
	 * @param con the connection to the server
	 * @return the gas price
	 */
	public double getGasPrice(Object list, Connection con) {
		@SuppressWarnings("unchecked")
		ArrayList<String> sqlStrings = (ArrayList<String>) list;
		double gasPrice = 0;
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT pricePerLiter FROM gasprices WHERE gasType = '" + sqlStrings.get(1) + "'");
			rs.next();
			gasPrice = Double.parseDouble(rs.getString(1));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return gasPrice;
	}

	/**
	 * Check if got discount for the purchase.
	 *
	 * @param type the type of fuel
	 * @param con the connection to the server
	 * @return true, if there is else ,false
	 */
	public boolean checkIfGotDiscount(String type, Connection con) {
		Statement stmt;
		
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM discount WHERE gasname = '" + type + "';");
			while (rs.next()) {
				if (rs.getString(1).equals("0")) {
					rs.close();
					return false;
				} else {
					String[] parts = LocalTime.now().toString().substring(0, 5).split(":"), parts2 = rs.getString(6).split(":"),
							parts3 = rs.getString(7).split(":");
					int hoursOrder = Integer.parseInt(parts[0]), hoursStart = Integer.parseInt(parts2[0]),
							hoursEnd = Integer.parseInt(parts3[0]);
					int minOrder = Integer.parseInt(parts[1]);
							

					Date dateStart;
					try {
						dateStart = new SimpleDateFormat("yyyy-MM-dd").parse(LocalDate.now().toString());
						if ((rs.getDate(4).compareTo(dateStart) < 0 && rs.getDate(5).compareTo(dateStart) > 0)
								|| (rs.getDate(4).compareTo(dateStart) == 0 && hoursOrder >= hoursStart)
								|| (rs.getDate(5).compareTo(dateStart) == 0 && hoursOrder <= hoursEnd
										&& !((hoursOrder == hoursEnd) && minOrder > 0)))// after/before
						{
							return true;
						}
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	
	/**
	 * Gets the all vehicles.
	 *
	 * @param ID the id of the vehicle
	 * @param con the connection to the server
	 * @return the all vehicles
	 */
	public ArrayList<Object> getAllVehicles(String ID, Connection con) {
		Statement stmt;
		ArrayList<Object> list = new ArrayList<Object>();
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT vehicleNumber FROM vehicles WHERE clientId = '" + ID + "';");
			list.add("6");
			while (rs.next()) {
				list.add(rs.getString(1));
			}

			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Check if order number have order.
	 *
	 * @param orderNum the order number
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<Object> checkIfOrderNumHaveOrder(String orderNum, Connection con) {
		Statement stmt;
		ArrayList<Object> list = new ArrayList<Object>();
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM clientorder;");
			while (rs.next()) {
				if (orderNum.equals(rs.getString(1))) {

					list.add("5");
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					list.add(rs.getString(8));
					list.add(rs.getString(9));
					list.add(rs.getString(10));
					list.add(rs.getString(11));
					list.add(rs.getString(12));
					list.add(rs.getString(13));
					return list;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Station manager update inventory threshold.
	 *
	 * @param msg the message
	 * @param con the connection to the server
	 */
	@SuppressWarnings("unchecked")
	public void StationManager_InventoryThreshold(Object msg, Connection con) {
		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object
		if (msg instanceof List) {
			al = (ArrayList<String>) msg;
			PreparedStatement preparedStatement;
			try {
				switch (al.get(1)) { // check the fuel type
				case "Fuel_95":
					preparedStatement = con
							.prepareStatement("UPDATE  myfuel.fuelthresholdinventory set Fuel_95=? WHERE Fuel_95;");
					preparedStatement.setString(1, al.get(2));
					preparedStatement.execute();
					break;
				case "Soler":
					preparedStatement = con
							.prepareStatement("UPDATE  myfuel.fuelthresholdinventory set Soler=? WHERE Soler;");
					preparedStatement.setString(1, al.get(2));
					preparedStatement.execute();
					break;
				case "Fuel_mini_bike":
					preparedStatement = con.prepareStatement(
							"UPDATE  myfuel.fuelthresholdinventory set Fuel_mini_bike=? WHERE Fuel_mini_bike;");
					preparedStatement.setString(1, al.get(2));
					preparedStatement.execute();
					break;
				case "Fuel_HomelHeating":
					preparedStatement = con.prepareStatement(
							"UPDATE  myfuel.fuelthresholdinventory set Fuel_Home_Heating=? WHERE Fuel_Home_Heating;");
					preparedStatement.setString(1, al.get(2));
					preparedStatement.execute();
					break;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

	/**
	 * Station manager show data for checking inventory.
	 *
	 * @param all the all ArrayList
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<String> StationManager_ShowData_CheckInventory(ArrayList<?> all, Connection con) {
		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object
		Statement stmt;
		try {

			stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery("SELECT * FROM myfuel.fuelinventory;\r\n" + ";");

			while (rs.next()) {
				al.add(rs.getString(1));
				al.add(rs.getString(2));
				al.add(rs.getString(3));
				al.add(rs.getString(4));

			}

			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return al;

	}

	/**
	 * Station manager show data for checking purchases.
	 *
	 * @param all the all ArrayList
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<Object> StationManager_ShowData_CheckPurchases(ArrayList<?> all, Connection con) {
		ArrayList<Object> al = new ArrayList<Object>(); // Create an ArrayList object
		int num = 0;
		int sum = 0;
		Statement stmt;
		ResultSet[] rs = new ResultSet[4];
		ArrayList<String> straray = new ArrayList<String>(); // Create an ArrayList object
		straray.add("'Fuel_95'");
		straray.add("'Soler'");
		straray.add("'Fuel_mini_bike'");
		straray.add("'Fuel_Home_Heating'");

		try {
			stmt = con.createStatement();
			for (int i = 0; i < 4; i++) {
				rs[i] = stmt.executeQuery(
						"select amountofgas,gasType FROM myfuel.clientorder where gasType=" + straray.get(i) + ";");

				while (rs[i].next()) {
					num = Integer.parseInt(rs[i].getString(1));
					sum += num;

				}

				al.add(straray.get(i).replaceAll("'", "") + ":" + sum);
				sum = 0;
				rs[i].close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return al;
	}

	/**
	 * Station manager show data for checking incoming.
	 *
	 * @param all the all ArayList
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<Object> StationManager_ShowData_checkIncoming(ArrayList<?> all, Connection con) {
		ArrayList<Object> al = new ArrayList<Object>(); // Create an ArrayList object
		double num = 0;
		double sum = 0;
		double total = 0;
		Statement stmt;
		ResultSet[] rs = new ResultSet[4];
		ArrayList<String> straray = new ArrayList<String>(); // Create an ArrayList object
		straray.add("'Fuel_95'");
		straray.add("'Soler'");
		straray.add("'Fuel_mini_bike'");
		straray.add("'Fuel_Home_Heating'");
		String[] Newstr = { "Fuel_95: ", "Soler: ", "Fuel_mini_bike: ", "Fuel_Home_Heating: " };
		try {
			stmt = con.createStatement();
			for (int i = 0; i < 4; i++) {
				sum = 0;

				rs[i] = stmt.executeQuery("select orderPrice,gasType FROM myfuel.clientorder where gastype="
						+ straray.get(i) + ";");

				while (rs[i].next()) {
					num = Double.parseDouble(rs[i].getString(1));
					sum += num;

				}

				al.add(Newstr[i] + "" + sum);
				rs[i].close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < 4; i++) {

			total += Double.parseDouble(al.get(i).toString().replaceAll(Newstr[i], ""));

		}
		al.add("Total of incoming is:  " + total);

		return al;
	}

	/**
	 * Send renwel inventory message.
	 *
	 * @param con the connection to the server
	 * @return the array list
	 * @throws SQLException the SQL exception
	 */
	public ArrayList<String> sendrenwelInventoryMessage(Connection con) throws SQLException {/// compare between the


		ArrayList<String> al = new ArrayList<String>(); // Create an ArrayList object
		al.add("Server_sendrenwelInventoryMessage");
		ArrayList<String> straray = new ArrayList<String>(); // Create an ArrayList object
		straray.add("");

		straray.add("'Fuel_95'");
		straray.add("'Soler'");
		straray.add("'Fuel_mini_bike'");
		straray.add("'Fuel_Home_Heating'");

		Statement stmtInventoryTable, stmtThresholdTable;

		stmtInventoryTable = con.createStatement(); /// InventoryTable
		stmtThresholdTable = con.createStatement(); /// ThresholdTable
		ResultSet rsInventoryTable;
		ResultSet rsThresholdTable;
		double maxValue;

		rsInventoryTable = stmtInventoryTable.executeQuery("SELECT * FROM myfuel.fuelinventory;");
		rsThresholdTable = stmtThresholdTable.executeQuery("SELECT * FROM myfuel.fuelthresholdinventory;");

		while (rsInventoryTable.next() && rsThresholdTable.next()) {
			maxValue=rsInventoryTable.getDouble(5)/4;
			for (int i = 1; i <= 4; i++) {
				if (rsInventoryTable.getDouble(i) < rsThresholdTable.getDouble(i)
						|| rsInventoryTable.getDouble(i) == rsThresholdTable.getDouble(i)) {
					maxValue-=rsInventoryTable.getDouble(i);
					al.add(straray.get(i).replaceAll("'", ""));
					al.add(String.valueOf(maxValue));
				} else {
				}
			}
		}
		rsInventoryTable.close();
		rsThresholdTable.close();

		if (al.size() == 1) {
			al.add("no");
		}
		return al;

	}
	
	
	/**
	 * Station manager prepare ID.
	 *
	 * @param all the all ArayList
	 * @param con the connection to the server
	 * @return the array list
	 * @throws SQLException the SQL exception
	 */
	public ArrayList<String> StationManager_PrepareID(ArrayList<?> all, Connection con) throws SQLException {
		Statement stmID;
		
		stmID = con.createStatement();
		ArrayList<String> alID = new ArrayList<String>(); // Create an ArrayList object
		

		
		ResultSet rs;
		
		rs=stmID.executeQuery( "SELECT distinct ID FROM myfuel.clientorder;"); 
  
		while(rs.next()) {
			alID.add(rs.getString(1));


		}
		rs.close();
		return alID; 
		

	}

	/**
	 * Station manager prepare data to analitical system.
	 *
	 * @param all the all ArayList
	 * @param con the connection to the server
	 * @return the array list
	 * @throws SQLException the SQL exception
	 */
	public ArrayList<String> StationManager_PrepareDataToAnaliticalSystem(String all, Connection con) throws SQLException {
		Statement stmtTypeFuel,stmtTimeFuel,stmtTCustomerType;
		ArrayList<String> alToanaliticalSys = new ArrayList<String>(); // Create an ArrayList object

		stmtTypeFuel = con.createStatement(); 
		stmtTimeFuel = con.createStatement(); 
		stmtTCustomerType=con.createStatement();

		ResultSet rs1,rs2,rs3;
		rs1=stmtTypeFuel.executeQuery("select DISTINCT  gasType FROM myfuel.clientorder where  ID="+all+" and( gasType='Fuel_95' or gasType= 'Soler' or gasType='Fuel_mini_bike' or gastype='Fuel_Home_Heating');");
		rs2=stmtTimeFuel.executeQuery( "select DISTINCT  timeOrder FROM myfuel.clientorder where  ID="+all+";");   
		rs3=stmtTCustomerType.executeQuery("SELECT purchasePlan FROM myfuel.employees where ID="+all+";");
		

		alToanaliticalSys.add("FuelType");

		while(rs1.next()) {
			alToanaliticalSys.add(rs1.getString(1));


		}
		rs1.close();

		alToanaliticalSys.add("End");
		
		alToanaliticalSys.add("timeOrder");

		while(rs2.next()) {
			alToanaliticalSys.add(rs2.getString(1));


		}
		rs2.close();

		alToanaliticalSys.add("End");
		
		alToanaliticalSys.add("CustomerType");

		while(rs3.next()) {
			alToanaliticalSys.add(rs3.getString(1));


		}
		rs3.close();

		alToanaliticalSys.add("End");

		return alToanaliticalSys = (ArrayList<String>)alToanaliticalSys;
	}

	/**
	 * Gets the details from the employees table.
	 *
	 * @param con the connection to the server
	 * @return the details
	 */
	public ArrayList<String> getDetails(Connection con) {
		ArrayList<String> details = new ArrayList<String>();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT email,phoneNumber FROM employees WHERE role = 'Station Manager';\r\n");
			while(rs.next()){
			details.add(rs.getString(1));//email
			details.add(rs.getString(2));//phone number
			}
			rs.close();
			return details; // return all employees table
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets the rates.
	 *
	 * @param con the connection to the server
	 * @return the rates
	 */
	public GasType[] getRates(Connection con){
		int i = 0;
		Statement stmt;
		GasType gas[] = new GasType[4];
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM gasnewprice;");
			while(rs.next()) {
				gas[i] = new GasType(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
				i++;
			}
			rs.close();
			return gas; //return all employees table
		} catch (SQLException e) {
		e.printStackTrace();
		return null;
	}
}
	
	/**
	 * Update rate fuel 95.
	 *
	 * @param gas the gas name
	 * @param con the connection to server
	 * @throws SQLException the SQL exception
	 */
	public void UpdateRateFuel95(String gas, Connection con) throws SQLException {

		  try
		  {
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, true);
		    ps.setString(2,gas);
		    
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}

	/**
	 * Update rate soler.
	 *
	 * @param gas the gas name
	 * @param con the connection to server
	 * @throws SQLException the SQL exception
	 */
	public void UpdateRateSoler(String gas, Connection con) throws SQLException {

		  try
		  { 
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, true);
		    ps.setString(2,gas);
		    
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}

	/**
	 * Update rate home heating.
	 *
	 * @param gas the gas name
	 * @param con the connection to the server
	 * @throws SQLException the SQL exception
	 */
	public void UpdateRateHomeHeating(String gas, Connection con) throws SQLException {

		  try
		  { 
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept =? WHERE gasname= ?;");
		    ps.setBoolean(1, true);
		    ps.setString(2,gas);
		    
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();

		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}
	
	/**
	 * Update rate mini bike.
	 *
	 * @param gas the gas name
	 * @param con the connection to rhe server
	 * @throws SQLException the SQL exception
	 */
	public void UpdateRateMiniBike(String gas, Connection con) throws SQLException {

		  try
		  {
			
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, true);
		    ps.setString(2,gas); 
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();  
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}

	/**
	 * Dont update rate fuel 95.put 0
	 *
	 * @param gas the gas name
	 * @param con the connection to the server
	 * @throws SQLException the SQL exception
	 */
	public void DontUpdateRateFuel95(String gas, Connection con) throws SQLException {

		  try
		  {
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, false);
		    ps.setString(2,gas);
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}

	/**
	 * Dont update rate soler.put 0
	 *
	 * @param gas the gas name
	 * @param con the connection to the server
	 * @throws SQLException the SQL exception
	 */
	public void DontUpdateRateSoler(String gas, Connection con) throws SQLException {

		  try
		  {
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, false);
		    ps.setString(2,gas);
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}
	
	/**
	 * Dont update rate home heating.put 0
	 *
	 * @param gas the gas name
	 * @param con the connection to the server
	 * @throws SQLException the SQL exception
	 */
	public void DontUpdateRateHomeHeating(String gas, Connection con) throws SQLException {

		  try
		  {
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, false);
		    ps.setString(2,gas);
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}
	
	/**
	 * Dont update rate mini bike.put 0
	 *
	 * @param gas the gas name
	 * @param con the connection to the server
	 * @throws SQLException the SQL exception
	 */
	public void DontUpdateRateMiniBike(String gas, Connection con) throws SQLException {

		  try
		  {
		    PreparedStatement ps = con.prepareStatement(
		      "UPDATE gasnewprice SET accept = ? WHERE gasname= ?;");
		    ps.setBoolean(1, false);
		    ps.setString(2,gas);
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();
		  }  catch (SQLException se)
		  {
			    // log the exception
			    throw se;
			  }
	}
	
	/**
	 * Creates the sql table values.
	 *
	 * @param con the connection to the server
	 */
	public void createSql(Connection con)
	{
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate("INSERT INTO noy(ID,age) VALUES('203955299','28')");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Updating inventory in the inventory table.
	 *
	 * @param msg the message
	 * @param con the connection to the server
	 * @throws SQLException the SQL exception
	 */
	public void UpdatingInventory (ArrayList<String> msg,Connection con) throws SQLException 
	{
		ArrayList<Double> res = new ArrayList<Double>();
			Statement stmt;
			String query = "SELECT * FROM fuelinventory";
			stmt = con.prepareStatement(query);
			ResultSet rs1 = stmt.executeQuery(query);
			while(rs1.next()) {
				res.add(rs1.getDouble(1));
				res.add(rs1.getDouble(2));
				res.add(rs1.getDouble(3));
				res.add(rs1.getDouble(4));
			}
			rs1.close();
	List<String> al = new ArrayList<String>();
	al = msg;
	while(al.size() > 0) {
	switch(al.get(0)) {
	
	case "Fuel_95":		
	    PreparedStatement ps1 = con.prepareStatement(
			      "UPDATE fuelInventory SET Fuel_95 = ?");
			    ps1.setDouble(1, Double.parseDouble(al.get(1)) + res.get(0));
			    ps1.executeUpdate();
			    ps1.close();
			    al.remove(0);
			    al.remove(0);
			    break;
	case "Soler":
	    PreparedStatement ps2 = con.prepareStatement(
			      "UPDATE fuelInventory SET Soler = ?");
			    ps2.setDouble(1, Double.parseDouble(al.get(1)) + res.get(1));
			    ps2.executeUpdate();
			    ps2.close();
			    al.remove(0);
			    al.remove(0);
			    break;
	case "Fuel_mini_bike":
	    PreparedStatement ps3 = con.prepareStatement(
			      "UPDATE fuelInventory SET Fuel_mini_bike = ?");
			    ps3.setDouble(1, Double.parseDouble(al.get(1)) + res.get(2));
			    ps3.executeUpdate();
			    ps3.close();
			    al.remove(0);
			    al.remove(0);
			    break;
	case "Fuel_Home_Heating":
    PreparedStatement ps4 = con.prepareStatement(
		      "UPDATE fuelInventory SET Fuel_Home_Heating = ?");
		    ps4.setDouble(1, Double.parseDouble(al.get(1)) + res.get(3));
		    ps4.executeUpdate();
		    ps4.close();
		    al.remove(0);
		    al.remove(0);
		    break;
}	
	}
	}
	
	/**
	 * Prints the request on the screen.
	 *
	 * @param con the connection to the server
	 */
	public void printRequest(Connection con)
	  {
		Statement stmt;	
		try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM gasnewprice;");
		rs.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}	
}
	
	/**
	 * Calculate price.
	 *
	 * @param all the all ArrayList
	 * @param con the connection to the server
	 * @return the double result
	 * @throws SQLException the SQL exception
	 */
	public double Calculate(ArrayList<?> all, Connection con) throws SQLException {
		Statement stmt;
		
		ArrayList<Double> al = new ArrayList<Double>(); // Create an ArrayList object
		Map<Integer, ArrayList<Double>> map = new HashMap<Integer, ArrayList<Double>>();
		ArrayList<Double> sum = new ArrayList<Double>(); // Create an ArrayList object


		stmt = con.createStatement(); 
		int maxMounth=0;
		
		ResultSet rs;
		rs=stmt.executeQuery("SELECT oDate,amountofGas  FROM myfuel.clientorder where ID="+all.get(0)+" ;");

		while(rs.next()) {
			
			String[] parts = ((rs.getString(1).toString().split("-")));

			int mounth = Integer.parseInt(parts[1]);
			
			if(mounth>maxMounth) {
			maxMounth=mounth;
			}
	
			
			if(map.containsKey(mounth)||map.isEmpty()){
				al.add(rs.getDouble(2));
				map.put(mounth, al); 
			}
			if(!map.containsKey(mounth)){
				al.clear();
				al.add(rs.getDouble(2));
				map.put(mounth, al); 
			}

		
		}
		rs.close();

       if(map.containsKey(maxMounth)) {
    	  sum= map.get(maxMounth-1) ;  
       }
        
       double res = 0;
       for(int i = 0; i < sum.size(); i++) {
    	   res+=sum.get(i);
       }

		return res;
	
}
	

	
	
	/**
	 * Check clients.
	 *
	 * @param ID the id
	 * @param type the type of fuel
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<String> checkClients(String ID, String type, Connection con) {

		ArrayList<String> list2 = new ArrayList<String>();
		try {
			Statement stmt = con.createStatement();
			Statement stmt2 = con.createStatement();
			Statement stmt3 = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM discount WHERE gasname = '" + type + "';");
			while (rs.next()) {
				ResultSet rs2 = stmt2.executeQuery("SELECT * FROM clientorder WHERE ID = '" + ID + "'");
				while (rs2.next()) {
					String[] parts = rs2.getString(13).split(":"), parts2 = rs.getString(6).split(":"),
							parts3 = rs.getString(7).split(":");
					int hoursOrder = Integer.parseInt(parts[0]), hoursStart = Integer.parseInt(parts2[0]),
							hoursEnd = Integer.parseInt(parts3[0]);

					if ((rs.getDate(4).compareTo(rs2.getDate(5)) <= 0 && rs.getDate(5).compareTo(rs2.getDate(5)) >= 0)
							|| (rs.getDate(4).compareTo(rs2.getDate(5)) == 0 && hoursOrder >= hoursStart)
							|| (rs.getDate(5).compareTo(rs2.getDate(5)) == 0 && hoursOrder <= hoursEnd))// after/before
					{
						ResultSet rs3 = stmt3.executeQuery("select * from clientorder where ID = '" + rs2.getString(2)
								+ "' and ODate = '" + rs2.getDate(5) + "';");
						while (rs3.next()) {
							

						}

					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list2;
	}

	/**
	 * Check report.
	 *
	 * @param type the type of fuel
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<String> checkReport(String type, Connection con) {////////// ���� ������ ���� 

		ArrayList<String> list = new ArrayList<String>();
		ArrayList<String> listforsplit = new ArrayList<String>();
		ArrayList<String> listId = new ArrayList<String>();

		HashMap<String, ArrayList<Double>> map = new HashMap<>();

		Statement stmt, stmt2, stmt3;

		double sumAll = 0, sumPerClient = 0;
		int i = 0;
		try {
			stmt = con.createStatement();
			stmt2 = con.createStatement();
			stmt3 = con.createStatement();

			ResultSet rs = stmt.executeQuery("select * from discount where gasname = " + "'" + type + "';");
			while (rs.next()) {
				if (rs.getString(1).equals("0"))
					return null;
				ResultSet rs2 = stmt2.executeQuery("select * from clientorder where gasType = " + "'" + type + "';");
				while (rs2.next()) {
					String[] parts = rs2.getString(12).split(":"), parts2 = rs.getString(6).split(":"),
							parts3 = rs.getString(7).split(":");
					int hoursOrder = Integer.parseInt(parts[0]), hoursStart = Integer.parseInt(parts2[0]),
							hoursEnd = Integer.parseInt(parts3[0]);
					int minOrder = Integer.parseInt(parts[1]), minStart = Integer.parseInt(parts2[1]),
							minEnd = Integer.parseInt(parts3[1]);
					if ((rs.getDate(4).compareTo(rs2.getDate(5)) < 0 && rs.getDate(5).compareTo(rs2.getDate(5)) > 0)
							|| (rs.getDate(4).compareTo(rs2.getDate(5)) == 0 && hoursOrder >= hoursStart)
							|| (rs.getDate(5).compareTo(rs2.getDate(5)) == 0 && hoursOrder <= hoursEnd
									&& !((hoursOrder == hoursEnd) && minOrder > 0)))// after/before
					{
						ArrayList<Double> temp = new ArrayList<Double>();
						if (map.containsKey(rs2.getString(2))) {
							temp = map.get(rs2.getString(2));
							double counter, sumPrice;
							counter = temp.get(0);
							sumPrice = temp.get(1);
							counter += 1;
							sumPrice += rs2.getDouble(9);
							temp.clear();
							temp.add(counter);
							temp.add(sumPrice);
							map.put(rs2.getString(2), temp);
						} else {
							temp.add((double) 1);
							temp.add(rs2.getDouble(9));
							map.put(rs2.getString(2), temp);
						}
						i++;
						sumAll += Double.parseDouble(rs2.getString(9));

					}
				}
				rs2.close();
			}
			rs.close();
			list.add("Fuel type:" + type);
			list.add("\nSum of all purchase for this type:" + Double.toString(sumAll));
			list.add("\nAmount of all purchase:" + Integer.toString(i));
			list.add("\nId's of the clients that bought with amount and total sum :");

			for (Entry<String, ArrayList<Double>> entry : map.entrySet()) {
				listforsplit.add("" + entry.getValue() + "");
				String formattedString = listforsplit.toString().replace(" ", " \ntotal sum :") // remove the commas
						.trim(); // remove trailing spaces from partially initialized arrays
				list.add("\nFor this ID " + entry.getKey() + "--->number of purchase and total sum:" + entry.getValue());
			}

			list.add("\n---------------------------------------------\n");
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}


	/**
	 * Change price for each fuel type.
	 *
	 * @param msg the message
	 * @param con the connection to the server
	 * @return true, if successful
	 */
	public boolean changeprice(Object msg, Connection con) {
		Statement stmt;
		String gasType, Price;
		ArrayList<String> list = (ArrayList<String>) msg;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM gasnewprice WHERE gasname = '" + list.get(1) + "';");

			rs.next();
			if (rs.getBoolean(3)) {

				gasType = rs.getString(1);
				Price = rs.getString(2);
				rs.close();
				stmt.executeUpdate(
						"UPDATE gasprices SET pricePerLiter = " + Price + " WHERE gasType = '" + gasType + "';");
				return true;

			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Add to sales.
	 *
	 * @param list the list
	 * @param con the connection to the server
	 */
	public void addtosales(ArrayList list, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(
					"UPDATE gasnewprice SET newprice = " + list.get(2) + "WHERE gasname = '" + list.get(1) + "'");
			stmt.executeUpdate("UPDATE gasnewprice SET accept = null WHERE gasname = '" + list.get(1) + "';");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Add discount to the price.
	 *
	 * @param list the list
	 * @param con the connection to the server
	 */
	public void addtodiscount(ArrayList<String> list, Connection con)	{
		Statement stmt;
		try {
			stmt = con.createStatement();

			stmt.executeUpdate("UPDATE discount SET Percent=" + list.get(2) + "WHERE gasname='" + list.get(1) + "'");
			stmt.executeUpdate(
					"UPDATE discount SET Purpose='" + list.get(3) + "'" + "WHERE gasname='" + list.get(1) + "'");
			stmt.executeUpdate(
					"UPDATE discount SET StartDate = '" + list.get(4) + "'" + "WHERE gasname='" + list.get(1) + "'");
			stmt.executeUpdate(
					"UPDATE discount SET EndDate = '" + list.get(5) + "'" + "WHERE gasname='" + list.get(1) + "'");
			stmt.executeUpdate(
					"UPDATE discount SET StartTime = '" + list.get(6) + "'" + "WHERE gasname='" + list.get(1) + "'");
			stmt.executeUpdate(
					"UPDATE discount SET EndTime = '" + list.get(7) + "'" + "WHERE gasname='" + list.get(1) + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Update renewal for each fuel type.
	 *
	 * @param needRenewal the need renewal
	 * @param approve the approve of the network manager
	 * @param con the connection to the server
	 */
	public void updateRenewal(ArrayList<String> needRenewal,boolean approve, Connection con) {	
		
		ArrayList<String> al = new ArrayList<String>();
		al = needRenewal;
			while(al.size() > 0) {
			switch(al.get(0).toString()) {			
			case "Fuel_95":
			    PreparedStatement ps1;
				try {
					ps1 = con.prepareStatement(
						      "UPDATE renewal SET Fuel_95 = ?");
					ps1.setDouble(1, Double.parseDouble(al.get(1)));
					    ps1.executeUpdate();
					    ps1.close();
					    al.remove(0);
					    al.remove(0);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}

					    break;
			case "Soler":
			    PreparedStatement ps2;
				try {
					ps2 = con.prepareStatement(
						      "UPDATE renewal SET Soler = ?");
					ps2.setDouble(1, Double.parseDouble(al.get(1)));
					    ps2.executeUpdate();
					    ps2.close();
					    al.remove(0);
					    al.remove(0);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					    break;
			case "Fuel_mini_bike":
			    PreparedStatement ps3;
				try {
					ps3 = con.prepareStatement(
						      "UPDATE renewal SET Fuel_mini_bike = ?");
					ps3.setDouble(1, Double.parseDouble(al.get(1)));
					    ps3.executeUpdate();
					    ps3.close();
					    al.remove(0);
					    al.remove(0);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

					    break;
			case "Fuel_Home_Heating":
				PreparedStatement ps4;
				try {
					ps4 = con.prepareStatement(
						      "UPDATE renewal SET Fuel_Home_Heating = ?");
					ps4.setDouble(1, Double.parseDouble(al.get(1)));
				    ps4.executeUpdate();
				    ps4.close();
				    al.remove(0);
				    al.remove(0);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				    break;
		}	
		    PreparedStatement ps;
			try {
			ps = con.prepareStatement(
				  "UPDATE renewal SET approve = ?;");
			ps.setBoolean(1,approve);
		    // call executeUpdate to execute our sql update statement
		    ps.executeUpdate();
		    ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	}
	
	/**
	 * Gets the renewal from the tables for each fuel.
	 *
	 * @param con the connection to the server
	 * @return the array list
	 */
	public ArrayList<String> GetRenewal(Connection con) {	
		
		Statement stmt;
		ArrayList<String> al = new ArrayList<String>();
		al.add("Need");
		try {
			stmt = con.createStatement();		
			ResultSet rs = stmt.executeQuery("SELECT * FROM renewal;");
		while (rs.next()) {
			if(Double.parseDouble(rs.getString(1)) != 0) {
				al.add("Fuel_95");
				al.add(rs.getString(1));				
			}
			if(Double.parseDouble(rs.getString(2)) != 0) {
				al.add("Soler");
				al.add(rs.getString(2));				
			}
			if(Double.parseDouble(rs.getString(3)) != 0) {
				al.add("Fuel_mini_bike");
				al.add(rs.getString(3));
			}
				
			if(Double.parseDouble(rs.getString(4)) != 0) {
				al.add("Fuel_Home_Heating");
				al.add(rs.getString(4));
			}			
			
		}
		rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;
}
	
	
/**
 * Update renewal -the supplier.
 *
 * @param con the connection to the server
 */
public void updateRenewalSupplier(Connection con) {	
		
	  try
	  {
		
	    PreparedStatement ps = con.prepareStatement(
	      "UPDATE renewal SET Fuel_95 = ? , Soler = ? , Fuel_mini_bike = ? , Fuel_Home_Heating = ? , approve = ?;");
	    ps.setDouble(1,0);
	    ps.setDouble(2,0); 
	    ps.setDouble(3,0);
	    ps.setDouble(4,0);
	    ps.setBoolean(5, false);
	    // call executeUpdate to execute our sql update statement
	    ps.executeUpdate();
	    ps.close();  
	  }  catch (SQLException se)
	  {
		  	se.printStackTrace();
		  }
}

/**
 * Sets the approval in the table.
 *
 * @param approve the approve
 * @param con the connection to the server
 */
public void setApproval(boolean approve, Connection con) {
	
    PreparedStatement ps;
	try {
	ps = con.prepareStatement(
		  "UPDATE renewal SET approve = ?;");
	if(approve == true)
		ps.setBoolean(1,true);
    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
    ps.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	
/**
 * Gets the approval from the table.
 *
 * @param con the connection
 * @return the approval
 */
public ArrayList<String> getApproval(Connection con) {
	
	int flag = 0;
	Statement stmt;
	ArrayList<String> al = new ArrayList<String>();
	
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM renewal;");
			while (rs.next()) {
		if(rs.getBoolean(5)) {
			al.add("Approve"); 
			flag = 1;
				if(Double.parseDouble(rs.getString(1)) != 0) {
					al.add("Fuel_95");
					al.add(rs.getString(1));				
				}
				if(Double.parseDouble(rs.getString(2)) != 0) {
					al.add("Soler");
					al.add(rs.getString(2));				
				}
				if(Double.parseDouble(rs.getString(3)) != 0) {
					al.add("Fuel_mini_bike");
					al.add(rs.getString(3));
				}
					
				if(Double.parseDouble(rs.getString(4)) != 0) {
					al.add("Fuel_Home_Heating");
					al.add(rs.getString(4));
				}
			}		
	}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	if(flag == 0) {
			al.clear();
			al.add("Not Approve");			
	}
	return al;
}

/**
 * Check the supplied from the table.
 *
 * @param con the connection to the server
 * @return true, if successful
 */
public boolean checkSupplied(Connection con) {
	
	ArrayList<Double> res = new ArrayList<Double>();
	Statement stmt;
	int cnt = 0;
	String query = "SELECT * FROM fuelinventory";
	try {
		stmt = con.prepareStatement(query);
		ResultSet rs1 = stmt.executeQuery(query);
	while(rs1.next()) {
		if(rs1.getDouble(1) == 4000)
			cnt++;
		if(rs1.getDouble(2) == 4000)
			cnt++;
		if(rs1.getDouble(3) == 4000)
			cnt++;
		if(rs1.getDouble(4) == 4000)
			cnt++;

	}
	rs1.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	if(cnt == 4)
		return true;
	return false;
}

/**
 * Gets the all fuel types.
 *
 * @param con the connection to the server
 * @return the all fuel types
 */
public ArrayList<String> getAllFuelTypes(Connection con) {
	Statement stmt;
	ArrayList<String> list = new ArrayList<String>();
	try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select gasType from gasprices;");
		while (rs.next()) {
			list.add(rs.getString(1));
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return list;
}

/**
 * Chara.
 *
 * @param con the connection to the server
 * @return the array list
 */
public ArrayList<String> chara(Connection con) {
	int cnt = 0;
	ArrayList<String> al = new ArrayList<String>();
	HashMap<String, Integer> map = new HashMap<>();
	boolean found = false;
	Statement stmt;
	try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select ID  from clientorder order by ID;\r\n" + ";");
		while (rs.next()) {
			{
				if (map.containsKey(rs.getString(1))) {
					cnt = map.get(rs.getString(1));
					cnt++;
					map.put(rs.getString(1), cnt);
				} else {
					cnt = 0;
					map.put(rs.getString(1), ++cnt);
				}
			}

		}
		rs.close();

	} catch (SQLException e) {
		e.printStackTrace();
	}
	map = (HashMap<String, Integer>) sortByValue(map);

	for (Map.Entry<String, Integer> entry : map.entrySet())
		al.add("Activity Level :" + entry.getValue() + "  ,Client ID :" + entry.getKey() + "\n");
	return al;
}

/**
 * Sort by value by comparing.
 *
 * @param <K> the key type of the map
 * @param <V> the value type of the map
 * @param map the map
 * @return the map
 */
public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {// map sort
	List<Entry<K, V>> list = new ArrayList<>(map.entrySet());
	list.sort(Entry.comparingByValue());

	Map<K, V> result = new LinkedHashMap<>();
	for (Entry<K, V> entry : list) {
		result.put(entry.getKey(), entry.getValue());
	}

	return result;
}

/**
 * Gets the all ID from the table.
 *
 * @param con the connection to the server
 * @return the all ID
 */
public ArrayList<String> getAllID(Connection con) {
	Statement stmt;
	ArrayList<String> list = new ArrayList<String>();
	try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT DISTINCT ID FROM clientorder");
		while (rs.next()) {
			list.add(rs.getString(1));
		}
		rs.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return list;
}

/**
 * Gets the new price fron the table.
 *
 * @param con the connection to the server
 * @return the new price
 */
public ArrayList<String> getNewPrice(Connection con) {
	
	Statement stmt;
	ArrayList<String> list = new ArrayList<String>();
	try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM gasnewprice");
		while (rs.next()) {
			list.add(rs.getString(1));
			list.add(String.valueOf(rs.getDouble(2)));	
		}
		rs.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return list;
}

/**
 * Charched client.
 *
 * @param ID the id of the client
 * @param date the dateof the order
 * @param con the connection to the server
 * @return the double charge
 */
public double CharchedClient(String ID,Date date,Connection con)
{
	Statement stmt;
	double sumPerID = 0;
	try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select ID,orderPrice,ODate from clientorder where ID = '" + ID + "';");
		while(rs.next())
		{
			if(date.compareTo(rs.getDate(3)) <= 0)
				sumPerID += rs.getDouble(2);
		}
		rs.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return sumPerID;
}
}