package logic;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;

/**
 * The Class alertClass.
 */
public class alertClass {
	
	
	/**
	 * Alert message.
	 *
	 * @param msg the msg
	 */
	public static void alertMessage(String msg){
		
	    Platform.runLater(() -> {	    
	    Alert errorAlert = new Alert(AlertType.ERROR);
	    Alert confirmAlert = new Alert(AlertType.CONFIRMATION);
		switch (msg) {		
		case "Password Not Correct":			
			errorAlert.setTitle("ERROR Window");
			errorAlert.setHeaderText("Attention!");
			errorAlert.setContentText("You entered incorrect password, please try again.");
			errorAlert.showAndWait();
			break;
		case "UserName Not Correct":
			errorAlert.setTitle("ERROR Window");
			errorAlert.setHeaderText("Attention!");
			errorAlert.setContentText("You entered incorrect username, please try again.");
			errorAlert.showAndWait();
			break;
		case "Already Connected":
			errorAlert.setTitle("ERROR Window");
			errorAlert.setHeaderText("Attention!");
			errorAlert.setContentText("User already connected!");
			errorAlert.showAndWait();
			break;
		case "Files Succeeded":
			confirmAlert = new Alert(AlertType.INFORMATION, "Files Created Successfuly", ButtonType.OK);
			confirmAlert.setTitle("Files Confirmation");
			confirmAlert.showAndWait();
			break;
		case "File Not Succeeded":
			confirmAlert = new Alert(AlertType.INFORMATION, "Files Doesn't Exist", ButtonType.OK);
			confirmAlert.setTitle("Files Confirmation");
			confirmAlert.showAndWait();
			break;
			
		default:
			break;
		}
	    });
	}
}
