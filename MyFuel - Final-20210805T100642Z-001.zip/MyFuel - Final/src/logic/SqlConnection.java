package logic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 * The Class SqlConnection.
 */
public class SqlConnection {

	
	/** The Constant DATABASE_DRIVER-Initialize database constants. */
    private static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
	    
    /** The Constant DATABASE_URL. */
    private static final String DATABASE_URL = "jdbc:mysql://localhost/MyFuel?serverTimezone=Asia/Jerusalem"; // URL requires Update
    
    /** The Constant USERNAME. */
    private static final String USERNAME = "root";  // UserName requires update
    
    /** The Constant PASSWORD. */
    private static final String PASSWORD = "root";		// Password requires update
    
  
    
    /** The connection. */
  
    private Connection connection;

    /**
     * Connect.
     *
     * @return the connection
     */
    /* Public methods */
	 public Connection connect() 
	    {
	        if (connection == null)
	        {
	            try 
	            {
	                Class.forName(DATABASE_DRIVER).newInstance();
	            } 
	            catch (Exception ex)
	            {
	                ex.printStackTrace();
	            }
	            
	            try 
	            {
	            	connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
	            } 
	            catch (SQLException ex)
	            {
	            	/* handle any errors*/
	                System.out.println("SQLException: " + ex.getMessage());
	                System.out.println("SQLState: " + ex.getSQLState());
	                System.out.println("VendorError: " + ex.getErrorCode());
	            }
	        }
	        return connection;
	    }
	 
	    /**
	     * Disconnect.
	     */
	    public void disconnect() {
	        if (connection != null) {
	            try {
	                connection.close();
	                connection = null;
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
}
