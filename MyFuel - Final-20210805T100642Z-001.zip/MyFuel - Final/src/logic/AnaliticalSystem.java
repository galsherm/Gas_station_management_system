package logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class AnaliticalSystem.
 */
/*X+Y+Z=10

X=0.5+1.2+1.3+1.5=--->max x=4.5
Y=max(0.25,0.5,2.5,1.5)=2.5--->max x=2.5
Z=3(1.5+0.2+1.3)=3*1=3--->max x=3

max=10;
*/
public class AnaliticalSystem {

	/**
	 * Calculate.
	 *
	 * @param all the all
	 * @return the string
	 */
	public static String Calculate(ArrayList<?> all) {


		boolean stopSearch = false;
		float rate = 0;
		ArrayList<String> rateReturn = new ArrayList<String>();

		Map<String, Float> fuelTypeMap = new HashMap<String, Float>();
		fuelTypeMap.put("Fuel_95", (float) 0.5);
		fuelTypeMap.put("Soler", (float) 1.2);
		fuelTypeMap.put("Fuel_mini_bike", (float) 1.3);
		fuelTypeMap.put("Fuel_Home_Heating", (float) 1.5);

		Map<String, Float> CustomerType = new HashMap<String, Float>();
		CustomerType.put("Ocassionaly", (float) 0.25);
		CustomerType.put("regMonSubSevVeh", (float) 0.50);
		CustomerType.put("fullMonSub", (float) 2.5);
		CustomerType.put("regMonSubSinVeh", (float) 1.5);

		/// time rate form

		if (all.get(0).equals("FuelType")) {
			for (int i = 0; i < all.size(); i++) {
				if (stopSearch == false) {
				if (!(all.get(i).equals("End"))) {
					if (fuelTypeMap.containsKey(all.get(i))) {

						rate += fuelTypeMap.get(all.get(i));
						 }
					}
				if(all.get(i).equals("End")) {
					stopSearch =true;
				}
				}
			}
			for (int j = 0; j < all.size(); j++) {
				if (!(all.get(0).equals("End")))
					all.remove(0);

			}

			if (all.get(0).equals("End")) {
				all.remove(0);
				stopSearch=false;
			}
		}
///time
			int minutesTime = 0;
			//// Time present as HH:MM ///
			/*
			 * 
			 */
			all.remove(0);

			int count = 0;
			int updateTimeRate = 0;

			for (int i = 0; i < all.size(); i++) {
				if (stopSearch == false) {

					
					if (!all.get(i).equals("End")) {
						String[] parts = ((all.get(i).toString().split(":")));

						int hours = Integer.parseInt(parts[0]);
						int minutes = Integer.parseInt(parts[1]);

						minutesTime = hours * 60 + minutes;
						if (minutesTime == 0) {// if the time was 00:00 should write 24:00 ==1440 minutes
							minutesTime = 1440;
						}

						if (updateTimeRate < 3) {
							if (minutesTime < 360) { // before 6 am  add to the rate 0.5
								rate += 1.5;
								updateTimeRate++;
							}
							if (minutesTime > 360 && minutesTime < 1200) { // after 6 before 20:00  add to the rate 0.5
								rate += 0.2;
								updateTimeRate++;

							}
							if (minutesTime > 1200 && minutesTime < 1440) { // after 20 am before 24:00  add to the rate 0.5
								rate +=1.3;
								updateTimeRate++;

							}
						}

						minutesTime = 0;
						parts = null;
						count++;
					}
					
					if (all.get(i).equals("End")) {
						stopSearch = true;

						for (int j = 0; j < count + 1; j++) {
							all.remove(0);

							stopSearch = true;
						}
					}

				}
			}
			stopSearch=false;
			all.remove(0);
			for (int i1 = 0; i1 < all.size(); i1++) {

				if (CustomerType.containsKey(all.get(i1)) && !(all.get(i1).equals("End"))&&stopSearch==false) {

					rate += CustomerType.get(all.get(i1));
					stopSearch = true;
				}
			}
			stopSearch = false;
			for (int j1 = 0; j1 < all.size(); j1++) {
				if (!all.get(j1).equals("End") && stopSearch == false)
					all.remove(0);
				if (all.get(0).equals("End")) {
					all.remove(0);
					stopSearch = true;
				}
			}

		
		if(rate<1) {////if the rate of customer is less then 1 set the rate to 1!
			rate=1;
		}
		String sSelectivityRate = String.valueOf(rate);
	

	
		return sSelectivityRate;


	}}

