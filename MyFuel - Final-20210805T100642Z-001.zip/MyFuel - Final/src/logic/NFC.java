package logic;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NFC extends Thread implements Initializable {

	private List<String> NFCList = new ArrayList<String>();
	
	public static double fullResCalc = 0;

	public static int flag = 0;

	public static String NFCID = "";
	
	public ObservableList<String> listCars;

	Stage NFC;

	@FXML
	private TextField idText;

	@FXML
	private Button checkIdBtn;

	@FXML
	private RadioButton limitYes;


	@FXML
	private RadioButton limitNo;

	@FXML
	private AnchorPane amountPane;

	@FXML
	private TextField amountText;

	@FXML
	private Button okAmountBtn = new Button();

    @FXML
    private AnchorPane limitPane;

    @FXML
    private AnchorPane choosePane;
    
    @FXML
    private ComboBox<String> fuelType;
    

    @FXML
    private ComboBox<String> carList;
    

    @FXML
    private AnchorPane fuelTypePane;

    @FXML
    private ImageView gasFilling;
    
	@Override
	public void run() {

		for (;;) {
			try {
				if (flag == 1)
					return;
				Thread.sleep(10000);
				Platform.runLater(() -> {
					Parent root;
					try {
						if (flag == 1)
							return;
						root = FXMLLoader.load(getClass().getResource("NFCFxml.fxml"));
						Scene Scene = new Scene(root);
						Stage NFC = new Stage();
						NFC.setScene(Scene);
						NFC.setTitle("NFCPage");
						NFC.show();
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
	}

	@FXML
	public void startNFC() {
		Platform.runLater(() -> {
			if (idText.getText().equals("")) {
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Please Enter ID");
				errorAlert.showAndWait();
			} else {
				choosePane.setVisible(true);
				NFCList = new ArrayList<String>();
				NFCList.add("Check NFC");
				NFCList.add(idText.getText());
				ClientUI.chat.client.handleMessageFromClientUI(NFCList);//check id
				NFCList.removeAll(NFCList);
				NFCList.add("6");
				NFCList.add(idText.getText());
				ClientUI.chat.client.handleMessageFromClientUI(NFCList);//get car list
				carList.setValue("Choose");
	    		ChatClient.ret.remove(0);
	    		listCars = FXCollections.observableArrayList(ChatClient.ret); //get car list
	    		carList.setItems(listCars);
				if (NFCID.equals("Good")) {
					choosePane.setDisable(false);
					limitPane.setVisible(true);
					fuelTypePane.setDisable(false);;
				}

				else {
					Alert errorAlert = new Alert(AlertType.ERROR);
					errorAlert.setTitle("ERROR Window");
					errorAlert.setHeaderText("Attention!");
					errorAlert.setContentText("Wrong id please try again");
					errorAlert.showAndWait();
				}
			}
		});
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		idText.setText("");
		choosePane.setDisable(true);
		amountPane.setVisible(false);
		fuelTypePane.setDisable(true);
		limitPane.setVisible(false);
		gasFilling.setVisible(false);
		ObservableList<String> fuelTypeList = FXCollections.observableArrayList("Fuel_95" , "Soler", "Fuel_mini_bike");
		fuelType.setItems(fuelTypeList);
		//ClientUI.chat.client.= new ClientController("localhost",5555);
		limitYes.setOnAction(e->{
			amountPane.setVisible(true);
		});
	}
	
	@FXML
	private void getFuel() {
			NFCList = new ArrayList<String>();
			NFCList.add("3");
			NFCList.add(fuelType.getSelectionModel().getSelectedItem());
			if(limitYes.isSelected())
				NFCList.add(amountText.getText());
			else 
				NFCList.add("30");
			ClientUI.chat.client.handleMessageFromClientUI(NFCList);
			if(ChatClient.check) {
				ChatClient.check = false;
				double res = 0;
				double totalPrice = 0;
				double pricePerLiter = 0;
				List<String> resList = new ArrayList<String>();
				/*If there is enough fuel, decrease the amount of full
				 * that has been ordered*/
				gasFilling.setVisible(true);
				NFCList.clear();
				NFCList.add("8");
				NFCList.add("");
				NFCList.add("");
				NFCList.add("");
				if(limitYes.isSelected())
					NFCList.add(amountText.getText());
				else 
					NFCList.add("30");
				NFCList.add(fuelType.getSelectionModel().getSelectedItem());
				ClientUI.chat.client.handleMessageFromClientUI(NFCList);
				//Add new order to orders table
				
				//get Client details
				NFCList.clear();
				NFCList.add("0");
				NFCList.add(idText.getText());	
				ClientUI.chat.client.handleMessageFromClientUI(NFCList);
				//new order
				NFCList.clear();
				NFCList.add("1");
				NFCList.add(idText.getText());
				NFCList.add(ChatClient.c1.getFirstName());
				NFCList.add(ChatClient.c1.getSurname());
				NFCList.add(ChatClient.c1.getPhoneNum());
				NFCList.add(LocalDate.now().toString());
				NFCList.add("false");
				NFCList.add("false");
				if(limitYes.isSelected())
					NFCList.add(amountText.getText());
				else 
					NFCList.add("30");
				
				resList.clear();
				resList.add("4");
				resList.add(fuelType.getSelectionModel().getSelectedItem());
				ClientUI.chat.client.handleMessageFromClientUI(resList); //decrease fuel
				System.out.println("IM HERE");
    			if(limitYes.isSelected())
    				totalPrice = Integer.parseInt(amountText.getText());
    			else 
    				totalPrice = Integer.parseInt("30");    
        		pricePerLiter = Double.valueOf(ChatClient.ret.get(1));
        		resList.clear();
        		resList.add("9");
        		resList.add(idText.getText());
        		ClientUI.chat.client.handleMessageFromClientUI(resList);
        		res = calcOrderPrice(ChatClient.c1.getSubscription(),(pricePerLiter*totalPrice),pricePerLiter);
        		NFCList.add(Double.toString(res));
        		NFCList.add(fuelType.getSelectionModel().getSelectedItem());
        		NFCList.add(carList.getValue());
        		NFCList.add("card");
        		//System.out.println(NFCList);
        		System.out.println(NFCList + "IM HERE");
        		ClientUI.chat.client.handleMessageFromClientUI(NFCList);
			}
			else {				
				Alert errorAlert = new Alert(AlertType.ERROR);
				errorAlert.setTitle("ERROR Window");
				errorAlert.setHeaderText("Attention!");
				errorAlert.setContentText("Not enough gas, sorry");
				errorAlert.showAndWait();
			}
		
		
	}
	
	public double calcOrderPrice(String subscription,double price,double pricePerLiter) {

		ArrayList<String> fullPrice = new ArrayList<String>();
		double res = 0.0;
		switch(subscription) {
		
		case "Ocassionaly":
			res = price;
			break;
		case "regMonSubSinVeh":
			res = price - (0.04 * price);
			break;
			
		case "regMonSubSevVeh": 
			res = (price - (0.04 * price*listCars.size()))*0.9;
			break;
		case "fullMonSub":
			/* ���� ������ ����� ���� = ���� ��� ���� ���� ��� ���
			 * ���� 3
			 * ���� ����� �� 3 ����
			 * */
			fullPrice.add("NFCCalculate");
			fullPrice.add(idText.getText());
			ClientUI.chat.client.handleMessageFromClientUI(fullPrice);
			res = (((fullResCalc*pricePerLiter) - (0.04 * (fullResCalc*pricePerLiter)*listCars.size()))*0.9)*0.97;
			break;
		}
		return res;
	}
}