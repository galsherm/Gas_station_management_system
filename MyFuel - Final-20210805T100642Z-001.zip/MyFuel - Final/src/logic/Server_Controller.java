package logic;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 * The Class Server_Controller.
 */
public class Server_Controller
{
	
	/** The sqlaction. */
	SqlAction sqlaction = new SqlAction();
	
	/** The sqlconnection. */
	SqlConnection sqlconnection = new SqlConnection();
	
	/** The primary stage. */
	Stage primaryStage;
	
	/** The renewal message. */
	ArrayList<String> renewalMessage = new ArrayList<String>();
  
  /** The server log text area. */
  @FXML
  public TextArea server_log_textArea;

  /** The connect button. */
  @FXML
  private Button connectButton;

  /** The stop server button. */
  @FXML
  private Button stopServerButton;
  
  /** The sv. */
  private EchoServer sv;
  
  /**
   * Connect pressed to server.
   *
   * @param event the event
   */
  @FXML
  void connectPressed(ActionEvent event) 
  {
    int port = 0;
    port = 5555;
    this.sv = new EchoServer(port);
    try
    {
      this.sv.listen();
      this.server_log_textArea.setText("Server is listening on port: " + port + "\n" + "Please start client.");
      
 
    }
    catch (Exception ex)
    {
      this.server_log_textArea.setText("ERROR - Could not listen for clients!");
      System.out.println("ERROR - Could not listen for clients!");
      return;
    }
   
  }
  
  /**
   * Stop pressed-stop listening the server.
   *
   * @throws Exception the exception
   */
  @FXML
  void stopPressed() throws Exception
  {	
    this.sv.close();
    System.err.println("Server Closed");
    this.server_log_textArea.setText("Server has stopped listening and closed the port.");
    NFC.flag = 1;
  }
  


 
}