package logic;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;

import entities.Employees;
import entities.GasType;
import gui.MyFile;
import ocsf.server.*;
import sms.Javamailutil;
import sms.SMSSender;


/**
 * The Class EchoServer.
 */
public class EchoServer extends AbstractServer {
	
	/** The main list. */
	ArrayList<Object> mainList = new ArrayList<Object>();
	
	/** The renewal. */
	ArrayList<String> renewal = new ArrayList<String>();
	
	/** The emp table. */
	Employees[] empTable;
	
	/** The msg file. */
	Object msgFile;
	
	/** The msg rate. */
	ArrayList<String> msgRate;
	
	/** The gas. */
	GasType gas = new GasType("fuel_95", "soler","fuel_mini_bike","fuel_homeheating");
	
	/** The con. */
	private Connection con = null;

	/**
	 * Instantiates a new echo server.
	 *
	 * @param port the port
	 */
	public EchoServer(int port) {
		super(port);
	}

	/**
	 * Handle message from client.
	 *
	 * @param msg the msg
	 * @param client the client
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void handleMessageFromClient(Object msg, ConnectionToClient client) { // first method that running from //
									// "SendToServer"
		
SqlConnection sqlconnection = new SqlConnection();
		
		con = sqlconnection.connect(); // connect to sql database
		SqlAction sqlaction = new SqlAction();// a class for dealing with sql commands	
		if (msg instanceof List) { // for the first time, msg contains the list ("Verify,username,password")
			int flag = 0;
			renewal = (ArrayList<String>)msg;
			ArrayList<String> newPrice = new ArrayList<String>();
			String firstName, surname, phoneNum;
			msgRate = (ArrayList<String>)msg; //for analytical
			msgFile = (ArrayList<String>)msg;
			mainList = (ArrayList<Object>)msg;
			empTable = sqlaction.getEmployeesDetails(con); //Get All Employees details
			msgRate = (ArrayList<String>)msg; //contains msg for ANALYTICAL Case	
			msgFile = (ArrayList<String>)msg; //contains msg for FILES Case
			int found = 0;
			int i;
			switch ((mainList.get(0).toString())) {
			case "Verify": //Check if user exist, and get his role.
				mainList.remove(0);
				// get the table of employees from database
				for (i = 0; i < empTable.length; i++) {
					if (mainList.get(0).equals(empTable[i].getUsername())) {
						found = 1;
						if (mainList.get(1).equals(empTable[i].getPassword())) {

							if (empTable[i].getIsConnected().equals(false))
								try {
									sqlaction.setEmployeeConnectionTrue(empTable[i], con); // set isConnected to true!!
									this.sendToAllClients(empTable[i]); // sending a specific employee to client
									break;
								} catch (SQLException e) {
									e.printStackTrace();
								}
							else {
								try {
									client.sendToClient("Already Connected");
								} catch (IOException e) {
									e.printStackTrace();
								}
								break;
							}

						} else {
							try {
								client.sendToClient("Password Not Correct");
							} catch (IOException e) {
								e.printStackTrace();
							}
							break;
						}	
		
					}
					}
			if (found == 0) {
				try {
					client.sendToClient("UserName Not Correct");
				} catch (IOException e) {
					e.printStackTrace();
				}
				}
				found = 0;
				break;

			case "Add":
				mainList.remove(0);
				sqlaction.addNewClient(mainList, con);
				try {
					client.sendToClient("Client Added");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				break;
				
			case "disconnect": //to discconect logged in user
				mainList.remove(0);
				for (i = 0; i < empTable.length; i++)
					if (mainList.get(0).equals(empTable[i].getUsername())) {
						try {
							sqlaction.setEmployeeConnectionFalse(empTable[i], con); // set isConnected to false!!
							client.sendToClient("Connection false set");
							break;
						} catch (SQLException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				break;
			
			case "Add Car":
				mainList.remove(0);
				sqlaction.setNewCar(mainList, con);
				try {

					client.sendToClient("Vehicle add successfuly");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				break;
				

			case "Purchase Plan":
				mainList.remove(0);
				sqlaction.setPurchasePlan(mainList, con);
				try {
					client.sendToClient("Purchase Plan Added Successfuly");
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				break;
			 	
			
			case "Verify Id":
				mainList.remove(0);
				if (sqlaction.verifyClientId(mainList, con)) {
					try {
						client.sendToClient("Id Ok");
					} catch (IOException e) {
						e.printStackTrace();
					}
					break;
				} else
					try {
						client.sendToClient("Id Wrong");
					} catch (IOException e2) {
						e2.printStackTrace();
					}
				break;
				
			
			case "Check NFC": //handle with NFC detection
				mainList.remove(0);
				if (sqlaction.verifyClientId(mainList, con)) {
					try {
						client.sendToClient("Id Good");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
					break;
				} else
					try {
						client.sendToClient("Id Not Good");
					} catch (IOException e2) {
						
						e2.printStackTrace();
					}
				break;
			 	
			
			case "CheckCustomerRating":
				String newall;		
				try {
					ArrayList<String> alID = new ArrayList<String>(); // Create an ArrayList object
					ArrayList<String> clientsReport = new ArrayList<String>();
					
					clientsReport.add("Analitical_System_Msg");
					alID = sqlaction.StationManager_PrepareID(msgRate,con);
					for(i = 0; i < alID.size() ; i++) {
						msgRate = (ArrayList<String>) sqlaction.StationManager_PrepareDataToAnaliticalSystem(alID.get(i), con);				
					newall = AnaliticalSystem.Calculate(msgRate); //get grade for one client
					clientsReport.add(alID.get(i));
					clientsReport.add(newall.toString());
					}
					if(!clientsReport.get(1).equals(null)) {
						client.sendToClient(clientsReport);
					}
					client.sendToClient("donothig"); //Send to screen that there is no clients

				} catch (SQLException e1) {
					
					e1.printStackTrace();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				break;
				
			
			case "StationManager_InventoryThreshold":
				/// thrshold Screen
				if (mainList.get(2).equals("")) {
					try {
						client.sendToClient("donothing");
					} catch (IOException e) {
						e.printStackTrace();
					}
					break;
				}
				sqlaction.StationManager_InventoryThreshold(mainList, con);
				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				break;
				

			case "StationManager_ShowData_CheckInventory":
				mainList.addAll(sqlaction.StationManager_ShowData_CheckInventory(mainList, con)); //Changed from string to object!
				try {
					
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "StationManager_ShowData_CheckPurchases":			
				mainList.addAll(sqlaction.StationManager_ShowData_CheckPurchases(mainList, con));
				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
				
			case "StationManager_ShowData_checkIncoming":
				mainList.addAll(sqlaction.StationManager_ShowData_checkIncoming(mainList, con));
				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
			case "Check Renewal":
				try {
					client.sendToClient(sqlaction.GetRenewal(con));
				} catch (IOException e4) {
					
					e4.printStackTrace();
				}
			break;
			case "Send To Supplier":
				renewal.remove(0);
				if (renewal.get(0).equals("Yes")) {
					renewal.clear();
					sqlaction.setApproval(true,con);
					try {
						client.sendToClient("Changed Succesfully");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				else if (renewal.get(1).equals("no")) {
					try {
						client.sendToClient("Not Approval");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				break;
				
			case "Check Approval":
				ArrayList<String> approve = new ArrayList<String>();
				approve = sqlaction.getApproval(con);
				if(approve.toString().equals("Not Approve")) {
					try {
						client.sendToClient(approve);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				else {
					try {
						client.sendToClient(approve);
					} catch (IOException e) {
						
						e.printStackTrace();
					}					
				}				
				break;
				
			case "Update Renewal":
				ArrayList<String> details = new ArrayList<String>();
				renewal.remove(0); //delete "Update Renewal"
				sqlaction.updateRenewalSupplier(con);
				try {
					sqlaction.UpdatingInventory(renewal, con);
					details = sqlaction.getDetails(con);
					
					Javamailutil.sendmail(details.get(0).toString(),"Renewall Message","Hi, The Following Has Been Supplied:\n" + renewal.toString());
					SMSSender.sendSms("http://10.0.0.18", "8090",details.get(1).toString(),"Hi, The Following Has Been Supplied:\n" + renewal.toString());
				} catch (MessagingException | IOException e) {
					
				} catch (SQLException e) {
					
				}
				try {
					client.sendToClient("Succeeded");
				} catch (IOException e4) {
					
					e4.printStackTrace();
				}
				break;
				
			case "Check Supplied":
				if(sqlaction.checkSupplied(con)) {
					try {
						
						client.sendToClient("Supplied");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
					
				}
				else {
					try {
						client.sendToClient("Not Supplied");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				
				}
				break;

			case "NFCCalculate":
				mainList.remove(0);
				try {
					NFC.fullResCalc = sqlaction.Calculate(mainList, con);
				} catch (SQLException e2) {
					
					e2.printStackTrace();
				}
				this.sendToAllClients("Succeeded");
				break;		
			case "0":
				if (sqlaction.checkIfClientExists(mainList.get(1).toString(), con)) {
					
					firstName = sqlaction.getFirstName(mainList.get(1).toString(), con);
					surname = sqlaction.getSurname(mainList.get(1).toString(), con);
					phoneNum = sqlaction.getPhoneNum(mainList.get(1).toString(), con);
					
					mainList.clear();
					mainList.add("0");
					mainList.add(firstName);
					mainList.add(surname);
					mainList.add(phoneNum);
			
					flag = 1;
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
					
				}
				if (flag != 1) {
					
					mainList.clear();
					mainList.add("1");
					mainList.add("Error");
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				break;
				
			
			
			case "1":
				
				int orderNum = sqlaction.checkLastQuery(con);
				if (mainList.get(12).toString().equals("cash")) {
					sqlaction.createNewOrder(con, orderNum, mainList.get(1).toString(), mainList.get(2).toString(),
							mainList.get(3).toString(), mainList.get(4).toString(), mainList.get(5).toString(),
							Boolean.valueOf(mainList.get(6).toString()), Boolean.valueOf(mainList.get(7).toString()),
							Integer.parseInt(mainList.get(8).toString()), Double.parseDouble(mainList.get(9).toString()),
							"cash", mainList.get(10).toString(), mainList.get(11).toString());
					try {
						client.sendToClient("Create succeeded");
					} catch (IOException e) {
						
						e.printStackTrace();
					} 
				} else {
					String fourNum = sqlaction.take4CreditCardNum(mainList.get(1).toString(), con);//get four last digit of credit card
					sqlaction.createNewOrder(con, orderNum, mainList.get(1).toString(), mainList.get(2).toString(),
							mainList.get(3).toString(), mainList.get(4).toString(), mainList.get(5).toString(),
							Boolean.valueOf(mainList.get(6).toString()), Boolean.valueOf(mainList.get(7).toString()),
							Integer.parseInt(mainList.get(8).toString()), Double.parseDouble(mainList.get(9).toString()),
							fourNum, mainList.get(10).toString(), mainList.get(11).toString());
					try {
						client.sendToClient("Create succeeded");
					} catch (IOException e) {
						
						e.printStackTrace();
					} 
				}
				break;
				
			
			case "2":
				
				if (!sqlaction.confirmationCVVCheck(mainList, con)) {
					mainList.clear();
					mainList.add("2");
					mainList.add("Error");
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				} else {
					ArrayList<String> needRenewal = new ArrayList<String>();
					sqlaction.decreaseFuel(mainList, con);
					try {
						needRenewal = sqlaction.sendrenwelInventoryMessage(con);
						needRenewal.remove(0);
						if(!needRenewal.get(0).equals("no"))
						sqlaction.updateRenewal(needRenewal,false,con);						
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
					try {
						client.sendToClient("Decrease succeeded");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				break;
				

			case "3":
				
				double inv = sqlaction.checkInventory(mainList.get(1).toString(), con);
				double inv2 = Double.parseDouble(mainList.get(2).toString());
				if (inv - inv2 > 0) {
					mainList.add("true");
				} else {
					mainList.add("false");
				}

				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "4":
				
				double gasPrice = sqlaction.getGasPrice(mainList, con); //get gas price!
				mainList.clear();
				mainList.add("4");
				mainList.add(Double.toString(gasPrice));
				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
				
			case "5":
				mainList = sqlaction.checkIfOrderNumHaveOrder(mainList.get(1).toString(), con);//check if there is an order
				if (mainList != null) {
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				} else {
					mainList = new ArrayList<Object>();
					mainList.add("5");
					mainList.add("Error");
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				break;
				
			
			case "6":
				
				mainList = sqlaction.getAllVehicles(mainList.get(1).toString(), con); //get vehicles
				if (mainList != null) {
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				} else {
					mainList = new ArrayList<Object>();
					mainList.add("6");
					mainList.add("Error");
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				break;
				
			
			case "7":
				
				mainList.clear();
				mainList.add("7");
				int lastOrder = sqlaction.checkLastQuery(con) - 1;
				mainList.add(Integer.toString(lastOrder));
				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "8": 
				
				sqlaction.decreaseFuel(mainList, con);
				try {
					client.sendToClient("Decrease success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
				
			case "9":
				
				String subRes = sqlaction.getSuscription(mainList.get(1).toString(), con); //get user role
				mainList.clear();
				mainList.add("8");
				mainList.add(subRes);
				try {
					client.sendToClient(mainList);
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
			case "10": 
			
				String type = mainList.get(1).toString();
				
				if(!sqlaction.checkIfGotDiscount(type,con)) {
					mainList.clear();
					mainList.add("9");
					mainList.add("Error");
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}else {
					
					mainList.clear();
					mainList.add("9");
					mainList.add(Double.toString(sqlaction.getPercentage(type,con)));
					mainList.add("Correct");
					try {
						client.sendToClient(mainList);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}
				try {
					client.sendToClient(mainList);
				} catch (IOException e3) {
					
					e3.printStackTrace();
				}
				break;
				
			case "11":
				if(sqlaction.getSuscription(mainList.get(1).toString(), con).equals("fullMonSub")) {
					
					String sDate=mainList.get(2).toString();  
					Date date1;
					try {
						date1 = new SimpleDateFormat("yyyy-MM-dd").parse(sDate);
						double sumPerID = sqlaction.CharchedClient(mainList.get(1).toString(),date1,con);
						mainList.clear();
						mainList.add("9");
						mainList.add(Double.toString(sumPerID));
					} catch (ParseException e) {
						e.printStackTrace();
					}
					this.sendToAllClients(mainList);
				}else {
					mainList.clear();
					mainList.add("9");
					mainList.add("Error");
					this.sendToAllClients(mainList);
				}
				break;
			case "AdministorMenuPage_fuel95_update1":
				try {
						sqlaction.UpdateRateFuel95(gas.getFuel_95(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("Update success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "AdministorMenuPage_soler_update1":
				try {
						sqlaction.UpdateRateSoler(gas.getSoler(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("Update success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "AdministorMenuPage_home_heating_update1":
				try {
						sqlaction.UpdateRateHomeHeating(gas.getFuel_homeheating(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("Update success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case"AdministorMenuPage_mini_bike_update1":
				try {
						sqlaction.UpdateRateMiniBike(gas.getFuel_mini_bike(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("Update success");
				} catch (IOException e2) {
				
					e2.printStackTrace();
				}
				break;
				
			
			case "AdministorMenuPage_fuel95_update0":
				try {
						sqlaction.DontUpdateRateFuel95(gas.getFuel_95(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "AdministorMenuPage_soler_update0":
				try {
						sqlaction.DontUpdateRateSoler(gas.getSoler(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
				
			case "AdministorMenuPage_mini_bike_update0":
				try {
						sqlaction.DontUpdateRateMiniBike(gas.getFuel_mini_bike(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			case "AdministorMenuPage_homeheating_update0":
				try {
						sqlaction.DontUpdateRateHomeHeating(gas.getFuel_homeheating(), con);
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				try {
					client.sendToClient("success");
				} catch (IOException e2) {
					
					e2.printStackTrace();
				}
				break;
				
			
			
			
			
			case "AdministorMenuPage_Incaming_Report":
				File directory = new File("E:\\ServerFilesReports");/// create directory if not exist in E!!
				if (!directory.exists()) { ///NEED TO CHECK
					try {
						client.sendToClient("File Not Succeeded");
					} catch (IOException e) {
						e.printStackTrace();
					}
					return;
				}
				File IncomingReport = new File("E:\\\\ServerFilesReports\\\\IncomingReport.docx");/// create directory if not exist in E!!
				if (!IncomingReport.exists()) { 
					try {
						client.sendToClient("File Not Succeeded");
					} catch (IOException e) {
						e.printStackTrace();
					}
					return;
				}
				File InventoryReport = new File("E:\\\\ServerFilesReports\\\\InventoryReport.docx");/// create directory if not exist in E!!
				if (!InventoryReport.exists()) { 
					try {
						client.sendToClient("File Not Succeeded");
					} catch (IOException e) {
						e.printStackTrace();
					}
					return;
				}
				File PurchaseReport = new File("E:\\\\ServerFilesReports\\\\InventoryReport.docx");/// create directory if not exist in E!!
				if (!PurchaseReport.exists()) { 
					try {
						client.sendToClient("File Not Succeeded");
					} catch (IOException e) {
						e.printStackTrace();
					}
					return;
				}
				int numOfFiles=3;
				String[] fileName=new String[numOfFiles];
				String[] LocalfilePath=new String[numOfFiles];
		    	ArrayList <String> newList = new ArrayList<String>();
		    	newList.add("E:\\ServerFilesReports\\IncomingReport.docx");
		    	newList.add("E:\\ServerFilesReports\\InventoryReport.docx");
		    	newList.add("E:\\ServerFilesReports\\PurchaseReport.docx");
				byte[][] mybytearray = new byte[numOfFiles][];  // This is idiomatic Java //this help to creates an array of arrays.		
				FileInputStream[] fis=new FileInputStream[numOfFiles];
				BufferedInputStream[] bis=new BufferedInputStream[numOfFiles];
				
				for(i=0;i<numOfFiles;i++) {
					fileName[i] = newList.get(i).replace("E:\\ServerFilesReports\\", "");
					LocalfilePath[i]=newList.get(i);	
				}
			
				MyFile[] messageFile=new MyFile[numOfFiles];
				File[] newFile=new File[numOfFiles];
				
				for(i=0;i<numOfFiles;i++) {
					messageFile[i] = new MyFile(LocalfilePath[i]);
					newFile[i]=new File(LocalfilePath[i]);
				}
				try {
					for(i=0;i<numOfFiles;i++) {

						mybytearray[i]=new byte[(int) newFile[i].length()];
						fis[i] = new FileInputStream(newFile[i]);
						 bis[i] = new BufferedInputStream(fis[i]);
						 messageFile[i].initArray(mybytearray[i].length);
						messageFile[i].setSize(mybytearray[i].length);
						bis[i].read(messageFile[i].getMybytearray(), 0, mybytearray[i].length);
					}
					ArrayList<MyFile> Bytearrays = new ArrayList<MyFile>();
					for(i=0;i<numOfFiles;i++)
						Bytearrays.add(messageFile[i]);
					client.sendToClient(Bytearrays);
				} catch (Exception e) {
					
				
				}
			break;
			
		case "Marketing_Manager_Page_sendtonetworkmanager":
			sqlaction.addtosales(mainList, con);
				try {
					client.sendToClient("Sales added");
				} catch (IOException e1) {
					e1.printStackTrace();
				}			
			break;
			
		case "Marketing_Manager_Page_updateprice":
			if(sqlaction.changeprice(mainList, con))
				try {
					client.sendToClient("Success");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			else
				try {
					client.sendToClient("Failed");
				} catch (IOException e1) {
					e1.printStackTrace();
				}		
			break;		
		case "Marketing_Manager_Page_addtodiscount":
			sqlaction.addtodiscount((ArrayList<String>) msg, con);
				try {
					client.sendToClient("Added succesfuly");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			break;
			
		case "Check New Price":		
			newPrice.add("Check New Price");
			newPrice.addAll(sqlaction.getNewPrice(con));
				try {
					client.sendToClient(newPrice);
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			break;
			
		case "Marketing_Manager_Page_ReportCampain":
			ArrayList<String> list3 = new ArrayList<String>();
			list3.add("Marketing_Manager_Page_ReportCampain");
			for( i=0  ;i < sqlaction.getAllFuelTypes(con).size() ; i++) {
				if (sqlaction.checkReport(sqlaction.getAllFuelTypes(con).get(i),con)!=null)
				list3.addAll(sqlaction.checkReport(sqlaction.getAllFuelTypes(con).get(i),con));
			}
			
				try {
					client.sendToClient(list3);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			break;
			
		case "Marketing_Manager_Page_ReportChar":
			
			ArrayList<String> list2 = new ArrayList<String>();
			
			list2.add("Marketing_Manager_Page_ReportChar");
			list2.addAll(sqlaction.chara( con));
			this.sendToAllClients(list2);
		


		default:
				int j;
				ArrayList<MyFile> al = new ArrayList<MyFile>();
				al = (ArrayList<MyFile>) msgFile;

				numOfFiles = 3;
				String Filestype = "docx";
				
				directory = new File("E:\\ServerFilesReports");/// create directory if not exist in E!!
				if (!directory.exists()) {
					directory.mkdir();

				}

				String[] LocalfilePath1 = { directory + "\\IncomingReport." + Filestype,
						directory + "\\PurchaseReport." + Filestype, directory + "\\InventoryReport." + Filestype };/// file
																													/// that
																													/// save
																													/// in
																													/// the
																													/// server
				byte[][] mybytearray1 = new byte[numOfFiles][]; // This is idiomatic Java //this help to creates an
																// array of arrays.
				FileOutputStream[] fos = new FileOutputStream[numOfFiles];
				BufferedOutputStream[] bos = new BufferedOutputStream[numOfFiles];
				File[] newFile1 = new File[numOfFiles];
				int[] filesize = new int[numOfFiles];

				for (i = 0; i < numOfFiles; i++) {

					newFile1[i] = new File(LocalfilePath1[i]);
				}
				try {
					for (j = 0; j < numOfFiles; j++) {
						mybytearray1[j] = new byte[(int) newFile1[j].length()];

						fos[j] = new FileOutputStream(newFile1[j]);
						bos[j] = new BufferedOutputStream(fos[j]);
						filesize[j] = al.get(j).getSize();

					}
					try {
						for (j = 0; j < numOfFiles; j++) {

							bos[j].write(al.get(j).getMybytearray(), 0, filesize[j]);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}

				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					for (j = 0; j < numOfFiles; j++) {

						bos[j].flush();
						bos[j].close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

				try {
					for (j = 0; j < numOfFiles; j++) {

						fos[j].flush();
					}
					client.sendToClient("Files Succeeded");
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			}		
		

	}
		sqlconnection.disconnect();
	}
	}
