package sms;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.*;
import javax.mail.internet.*;

public class Javamailutil {

	// File Name SendEmail.java

	public static void sendmail(String recepient,String messageSubject,String messageContent) throws MessagingException {

		
		Properties properties = new Properties();
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");
		properties.put("mail.smtp.ssl.trust", "*");
		String myAccountEmail = "myfuelsystembraude@gmail.com";		//sender email
		String Password = "fuel1234";
		Session session = Session.getInstance(properties, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(myAccountEmail, Password);

			}
		});

		Message message = prepareMessage(session, myAccountEmail, recepient, messageSubject, messageContent);
		Transport.send(message);
		System.out.println("Message succesfuly");
	}

	public static Message prepareMessage(Session session, String myAccountEmail, String recepient,String messageSubject,String messageContent) {
		try {

			Message message = new MimeMessage(session);

			message.setFrom(new InternetAddress(myAccountEmail));
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
			//message.setSubject("my first email-myfuel");			//mail Subject
			//message.setText("hey Station manager From Myfuel System");					//mail SetEmailText
			message.setSubject(messageSubject);			//mail Subject
			message.setText(messageContent);					//mail SetEmailText
			return message;

		} catch (Exception ex) {
			Logger.getLogger(Javamailutil.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}
}
