package sms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import javax.mail.MessagingException;

public class SMSSender {


	public static void sendSms(String Address,String port,String recepientPhone,String messageContent) throws MessagingException, IOException {
		//String message = "hello";		
		String phone = recepientPhone;
		String username = "abcd";
		String password = "1234";
		//String address = "http://192.168.1.162";////change it to the server adrres

		//String port = "8090";
		
		URL url = new URL(
				Address+":"+port+"/SendSMS?username="+username+"&password="+password+
				"&phone="+phone+"&message="+URLEncoder.encode(messageContent,"UTF-8"));
		
		URLConnection connection = url.openConnection();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		String inputLine;
		while((inputLine = bufferedReader.readLine()) !=null){
			System.out.println(inputLine);
		}
		bufferedReader.close();
		

	}

	
	}

	
/*
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		//String message = "hello";		
		//String phone="972525895364+";		//reciveingphone
		String username = "abcd";
		String password = "1234";
		String address = "http://192.168.1.162";////change it to the server adrres

		//String port = "8090";
		
		URL url = new URL(
				address+":"+port+"/SendSMS?username="+username+"&password="+password+
				"&phone="+phone+"&message="+URLEncoder.encode(message,"UTF-8"));
		
		URLConnection connection = url.openConnection();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		String inputLine;
		while((inputLine = bufferedReader.readLine()) !=null){
			System.out.println(inputLine);
		}
		bufferedReader.close();
		

	}
}
*/